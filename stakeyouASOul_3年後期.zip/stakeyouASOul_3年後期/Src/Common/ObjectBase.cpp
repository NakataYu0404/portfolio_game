#include "../Manager/InputManager.h"
#include "ObjectBase.h"

ObjectBase::~ObjectBase(void)
{
	InputManager::GetInstance().AddDeleteArray(*this);
}
