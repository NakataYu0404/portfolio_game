#include <DxLib.h>
#include "../Utility/Utility.h"
#include "../Common/Vector2.h"
#include "../Common/ObjectBase.h"
#include "InputManager.h"

InputManager* InputManager::instance_ = nullptr;

void InputManager::CreateInstance(void)
{
	if (instance_ == nullptr)
	{
		instance_ = new InputManager();
	}
	instance_->init();
}

InputManager& InputManager::GetInstance(void)
{
	if (instance_ == nullptr)
	{
		InputManager::CreateInstance();
	}
	return *instance_;
}

void InputManager::AddInputFunction(ObjectBase& point, TYPE_DEVICE device, std::vector<int> keyCode, std::function<void()> func, INPUT_TYPE type, bool canPause, int padNo)
{
	inputFuncMap_.emplace(&point, InputFunc(device, keyCode, func, type, canPause, padNo));
}

void InputManager::AddInputFunction(ObjectBase& point, TYPE_DEVICE device, int keyCode, std::function<void()> func, INPUT_TYPE type, bool canPause,int padNo)
{
	inputFuncMap_.emplace(&point, InputFunc(device, keyCode, func, type, canPause, padNo));
}

void InputManager::AddDeleteArray(ObjectBase& point)
{
	if (inputFuncMap_.find(&point) != inputFuncMap_.end())
	{
		deleteArray_.push_back(&point);
	}
}

void InputManager::init(void)
{
	Add(KEY_INPUT_W);
	Add(KEY_INPUT_A);
	Add(KEY_INPUT_S);
	Add(KEY_INPUT_D);

	Add(KEY_INPUT_UP);
	Add(KEY_INPUT_LEFT);
	Add(KEY_INPUT_DOWN);
	Add(KEY_INPUT_RIGHT);

	Add(KEY_INPUT_SPACE);

}

void InputManager::Update(bool isPause)
{
	//	����ɓo�^���ꂽ�֐��́A�Q�[���̏�ԂɈ˂炸isPause����Ȃ��Ȃ���s�����B�Ȃ̂ŁASTATE�ʂ̃L���������Ƃ��łȂ��āA�Q�[���̃|�[�Y�؂�ւ��Ƃ��Ɏg���ׂ�
	for (auto& inputF : inputFuncMap_)
	{
		//	���݃|�[�Y����Ă��āA�����o�֐������킹�Ď~�܂���
		if (isPause && inputF.second.GetCanPause())
		{
			continue;
		}

		switch (inputF.second.GetDeviceType())
		{
		case InputManager::TYPE_DEVICE::KEYBOARD:
			inputF.second.KeyBoardUpdate();
			break;
		case InputManager::TYPE_DEVICE::MOUSE:
			inputF.second.MouseUpdate();
			break;
		case InputManager::TYPE_DEVICE::XBOX_ONE:
			inputF.second.JoyPadUpdate(inputF.second.GetPadNo());
			break;
		}
	}

	//	�L�[�{�[�h���m
	for (auto& p : keyInfos_)
	{
		p.second.keyOld = p.second.keyNew;
		p.second.keyNew = CheckHitKey(p.second.key);
		p.second.keyTrgDown = p.second.keyNew && !p.second.keyOld;
		p.second.keyTrgUp = !p.second.keyNew && p.second.keyOld;
	}
	
	for (auto& deleteI : deleteArray_)
	{
		inputFuncMap_.erase(deleteI);
	}
	deleteArray_.clear();

	//	�p�b�h���
	SetJPadInState(JOYPAD_NO::KEY_PAD1);
	SetJPadInState(JOYPAD_NO::PAD1);
	SetJPadInState(JOYPAD_NO::PAD2);
	SetJPadInState(JOYPAD_NO::PAD3);
	SetJPadInState(JOYPAD_NO::PAD4);

}

void InputManager::Destroy(void)
{
	keyInfos_.clear();
	inputFuncMap_.clear();
	delete instance_;
}

void InputManager::Clear(void)
{
	keyInfos_.clear();
}

bool InputManager::IsNew(int key) const
{
	return Find(key).keyNew;
}

bool InputManager::IsTrgDown(int key) const
{
	return Find(key).keyTrgDown;
}

bool InputManager::IsTrgUp(int key) const
{
	return Find(key).keyTrgUp;
}

InputManager::JOYPAD_TYPE InputManager::GetJPadType(JOYPAD_NO no)
{
	return static_cast<InputManager::JOYPAD_TYPE>(GetJoypadType(static_cast<int>(no)));
}

DINPUT_JOYSTATE InputManager::GetJPadDInputState(JOYPAD_NO no)
{
	//	�R���g���[�����
	GetJoypadDirectInputState(static_cast<int>(no), &joyDInState_);
	return joyDInState_;
}

XINPUT_STATE InputManager::GetJPadXInputState(JOYPAD_NO no)
{
	//	�R���g���[�����
	GetJoypadXInputState(static_cast<int>(no), &joyXInState_);
	return joyXInState_;
}

void InputManager::SetJPadInState(JOYPAD_NO jpNo)
{

	int no = static_cast<int>(jpNo);
	auto stateNew = GetJPadInputState(jpNo);
	auto& stateNow = padInfos_[no];

	int max = static_cast<int>(JOYPAD_BTN::MAX);
	for (int i = 0; i < max; i++)
	{

		stateNow.ButtonsOld[i] = stateNow.ButtonsNew[i];
		stateNow.ButtonsNew[i] = stateNew.ButtonsNew[i];

		stateNow.IsOld[i] = stateNow.IsNew[i];
		stateNow.IsNew[i] = stateNow.ButtonsNew[i] > 0;

		stateNow.IsTrgDown[i] = stateNow.IsNew[i] && !stateNow.IsOld[i];
		stateNow.IsTrgUp[i] = !stateNow.IsNew[i] && stateNow.IsOld[i];


		stateNow.AKeyLX = stateNew.AKeyLX;
		stateNow.AKeyLY = stateNew.AKeyLY;
		stateNow.AKeyRX = stateNew.AKeyRX;
		stateNow.AKeyRY = stateNew.AKeyRY;

	}

}

InputManager::JOYPAD_IN_STATE InputManager::GetJPadInputState(JOYPAD_NO no)
{

	JOYPAD_IN_STATE ret = JOYPAD_IN_STATE();

	auto type = GetJPadType(no);

	switch (type)
	{
	case InputManager::JOYPAD_TYPE::OTHER:
		break;
	case InputManager::JOYPAD_TYPE::XBOX_360:
	{
	}
	break;
	case InputManager::JOYPAD_TYPE::XBOX_ONE:
	{

		auto d = GetJPadDInputState(no);
		auto x = GetJPadXInputState(no);

		int idx;


		idx = static_cast<int>(JOYPAD_BTN::TOP);
		ret.ButtonsNew[idx] = d.Buttons[3];//	Y

		idx = static_cast<int>(JOYPAD_BTN::LEFT);
		ret.ButtonsNew[idx] = d.Buttons[2];//	X

		idx = static_cast<int>(JOYPAD_BTN::RIGHT);
		ret.ButtonsNew[idx] = d.Buttons[1];//	B

		idx = static_cast<int>(JOYPAD_BTN::DOWN);
		ret.ButtonsNew[idx] = d.Buttons[0];//	A

		idx = static_cast<int>(JOYPAD_BTN::R_TRIGGER);
		ret.ButtonsNew[idx] = x.RightTrigger;//	R_TRIGGER

		idx = static_cast<int>(JOYPAD_BTN::L_TRIGGER);
		ret.ButtonsNew[idx] = x.LeftTrigger; //	L_TRIGGER

		// ���X�e�B�b�N(1000�i�K�̐��l��/100����10�i�K�̓��͎�t��)
		ret.AKeyLX = Utility::ScaleDownHundled(d.X);
		ret.AKeyLY = Utility::ScaleDownHundled(d.Y);

		//	�E�X�e�B�b�N
		ret.AKeyRX = d.Rx;
		ret.AKeyRY = d.Ry;

	}
	break;
	case InputManager::JOYPAD_TYPE::DUAL_SHOCK_4:
		break;
	case InputManager::JOYPAD_TYPE::DUAL_SENSE:
	{

		auto d = GetJPadDInputState(no);
		int idx;

		//	��
		//	��  �Z
		//	�~

		idx = static_cast<int>(JOYPAD_BTN::TOP);
		ret.ButtonsNew[idx] = d.Buttons[3];//	��

		idx = static_cast<int>(JOYPAD_BTN::LEFT);
		ret.ButtonsNew[idx] = d.Buttons[0];//	��

		idx = static_cast<int>(JOYPAD_BTN::RIGHT);
		ret.ButtonsNew[idx] = d.Buttons[2];//	�Z

		idx = static_cast<int>(JOYPAD_BTN::DOWN);
		ret.ButtonsNew[idx] = d.Buttons[1];//	�~

		//	���X�e�B�b�N
		ret.AKeyLX = d.X;
		ret.AKeyLY = d.Y;

		//	�E�X�e�B�b�N
		ret.AKeyRX = d.Z;
		ret.AKeyRY = d.Rz;

	}
	break;
	case InputManager::JOYPAD_TYPE::SWITCH_JOY_CON_L:
		break;
	case InputManager::JOYPAD_TYPE::SWITCH_JOY_CON_R:
		break;
	case InputManager::JOYPAD_TYPE::SWITCH_PRO_CTRL:
		break;
	case InputManager::JOYPAD_TYPE::MAX:
		break;
	}

	return ret;

}

bool InputManager::IsPadBtnNew(JOYPAD_NO no, JOYPAD_BTN btn) const
{
	return padInfos_[static_cast<int>(no)].IsNew[static_cast<int>(btn)];
}

bool InputManager::IsPadBtnNew(std::string playerNo, JOYPAD_BTN btn) const
{
	if (playerNo == Utility::OBJECT_NAME::PLAYER_1)
	{
		return padInfos_[static_cast<int>(1)].IsNew[static_cast<int>(btn)];
	}
	else if (playerNo == Utility::OBJECT_NAME::PLAYER_2)
	{
		return padInfos_[static_cast<int>(2)].IsNew[static_cast<int>(btn)];
	}
	return false;
}

bool InputManager::IsPadBtnTrgDown(JOYPAD_NO no, JOYPAD_BTN btn) const
{
	return padInfos_[static_cast<int>(no)].IsTrgDown[static_cast<int>(btn)];
}

bool InputManager::IsPadBtnTrgDown(std::string playerNo, JOYPAD_BTN btn) const
{
	bool ret = false;
	if (playerNo == Utility::OBJECT_NAME::PLAYER_1)
	{
		ret = padInfos_[static_cast<int>(1)].IsTrgDown[static_cast<int>(btn)];
		return ret;
	}
	else if (playerNo == Utility::OBJECT_NAME::PLAYER_2)
	{
		return padInfos_[static_cast<int>(2)].IsTrgDown[static_cast<int>(btn)];
	}
	return false;
}

bool InputManager::IsPadBtnTrgUp(JOYPAD_NO no, JOYPAD_BTN btn) const
{
	return padInfos_[static_cast<int>(no)].IsTrgUp[static_cast<int>(btn)];
}

bool InputManager::IsPadBtnTrgUp(std::string playerNo, JOYPAD_BTN btn) const
{
	if (playerNo == Utility::OBJECT_NAME::PLAYER_1)
	{
		return padInfos_[static_cast<int>(1)].IsTrgUp[static_cast<int>(btn)];
	}
	else if (playerNo == Utility::OBJECT_NAME::PLAYER_2)
	{
		return padInfos_[static_cast<int>(2)].IsTrgUp[static_cast<int>(btn)];
	}
	return false;
}

InputManager::DIR_FULL InputManager::GetDir(JOYPAD_NO no, int KEY_F, int KEY_B, int KEY_L, int KEY_R)
{
	DIR_FULL ret = DIR_FULL::FIVE5;

	int x = 0; //	X�i-1~1�j
	int y = 0; //	Y�i-1~1�j

	if (IsNew(KEY_F)) y += 1;
	if (IsNew(KEY_B)) y -= 1;
	if (IsNew(KEY_L)) x -= 1;
	if (IsNew(KEY_R)) x += 1;

	//	���o�[�����v�Z
	if (x == 0 && y == 1) ret = DIR_FULL::EIGHT8;		//	��
	else if (x == 0 && y == -1) ret = DIR_FULL::TWO2;	//	��
	else if (x == -1 && y == 0) ret = DIR_FULL::FOUR4;	//	��
	else if (x == 1 && y == 0) ret = DIR_FULL::SIX6;		//	�E
	else if (x == -1 && y == 1) ret = DIR_FULL::SEVEN7;	//	����
	else if (x == 1 && y == 1) ret = DIR_FULL::NINE9;	//	�E��
	else if (x == -1 && y == -1) ret = DIR_FULL::ONE1;	//	����
	else if (x == 1 && y == -1) ret = DIR_FULL::THREE3;	//	�E��

	auto pad = GetJPadInputState(no);

	VECTOR dir = Utility::VECTOR_ZERO;
	dir.x = pad.AKeyLX;
	dir.z = pad.AKeyLY * -1;

	float stickAngle = Utility::Rad2DegF(atan2f(dir.x, dir.z));
	if (stickAngle < 0)
	{
		stickAngle += Utility::CIRCLE;
	}

	// stickAngle �� 0�x�`360�x�ł���O��ŁA�����𔻒�
	auto InRange = [](float angle, const std::pair<float, float>& range) -> bool 
	{
		if (range.first > range.second) {  // ��: ������i337.5���`360��, 0���`22.5���j
			return angle >= range.first || angle < range.second;
		}
		return angle >= range.first && angle < range.second;
	};

	if (dir.x == 0.0f && dir.z == 0.0f) {
		// �������Ȃ�
	}
	else if (InRange(stickAngle, Utility::SEPARETE_STICK8_U)) {
		ret = DIR_FULL::EIGHT8;
	}
	else if (InRange(stickAngle, Utility::SEPARETE_STICK8_UR)) {
		ret = DIR_FULL::NINE9;
	}
	else if (InRange(stickAngle, Utility::SEPARETE_STICK8_R)) {
		ret = DIR_FULL::SIX6;
	}
	else if (InRange(stickAngle, Utility::SEPARETE_STICK8_DR)) {
		ret = DIR_FULL::THREE3;
	}
	else if (InRange(stickAngle, Utility::SEPARETE_STICK8_D)) {
		ret = DIR_FULL::TWO2;
	}
	else if (InRange(stickAngle, Utility::SEPARETE_STICK8_DL)) {
		ret = DIR_FULL::ONE1;
	}
	else if (InRange(stickAngle, Utility::SEPARETE_STICK8_L)) {
		ret = DIR_FULL::FOUR4;
	}
	else if (InRange(stickAngle, Utility::SEPARETE_STICK8_UL)) {
		ret = DIR_FULL::SEVEN7;
	}


	return ret;
}


int InputManager::GetMouse(void)
{
	return DxLib::GetMouseInput();
}

Vector2 InputManager::GetMousePos(void)
{
	Vector2 mouse = { 0,0 };
	GetMousePoint(&mouse.x, &mouse.y);
	return mouse;
}

void InputManager::Add(int key)
{
	InputManager::Info info = InputManager::Info();
	info.key = key;
	info.keyOld = false;
	info.keyNew = false;
	info.keyTrgDown = false;
	info.keyTrgUp = false;
	keyInfos_.emplace(key, info);
}

InputManager::InputManager(void)
{
}

const InputManager::Info& InputManager::Find(int key) const
{

	auto it = keyInfos_.find(key);
	if (it != keyInfos_.end())
	{
		return it->second;
	}

	return infoEmpty_;

}

void InputManager::InputFunc::KeyBoardUpdate(void)	//	InputFunc����Update(�֐��|�C���^��)
{
	bool hitKeys = false;
	if (keys.size() >= 1)
	{
		//	C++20�͈͓̔��ŕϐ��錾������肽���������ǁA�܂��@�B�̕����Ή����ĂȂ��炵��
		for (auto& k : keys)
		{
			if (CheckHitKey(k))
			{
				hitKeys = true;
			}
			else
			{
				hitKeys = false;
				break;
			}
		}
	}

	//	���̃L�[��������Ă邩
	if (CheckHitKey(key) || hitKeys)
	{
		//	�������u�Ԃł����Ăق����̂ɁA�O�t���[���ŉ�����Ă���
		if (type == INPUT_TYPE::TRIGGER && isPressBeforeFrame)
		{
			return;
		}

		//	�^�C�v���A���������łȂ�������(TRIGGER��PRESS����Lif��ʉ߂��������ŉ����Ă��珈��������)
		if (type != INPUT_TYPE::RELEASE)
		{
			func();
		}
		isPressBeforeFrame = true;
	}
	else
	{
		if (type == INPUT_TYPE::RELEASE && isPressBeforeFrame)
		{
			func();
		}
		isPressBeforeFrame = false;
	}
}

void InputManager::InputFunc::MouseUpdate(void)
{
	int mouse = GetInstance().GetMouse();
	
	//	���̃L�[��������Ă邩
	if (mouse == key)
	{
		//	�������u�Ԃł����Ăق����̂ɁA�O�t���[���ŉ�����Ă���
		if (type == INPUT_TYPE::TRIGGER && isPressBeforeFrame)
		{
			return;
		}

		//	�^�C�v���A���������łȂ�������(TRIGGER��PRESS����Lif��ʉ߂��������ŉ����Ă��珈��������)
		if (type != INPUT_TYPE::RELEASE)
		{
			func();
		}
		isPressBeforeFrame = true;
	}
	else
	{
		if (type == INPUT_TYPE::RELEASE && isPressBeforeFrame)
		{
			func();
		}
		isPressBeforeFrame = false;
	}
}

void InputManager::InputFunc::JoyPadUpdate(int padNo)
{
	switch ((InputManager::JOYPAD_BTN)key)
	{
	case InputManager::JOYPAD_BTN::LEFT:
		break;
	case InputManager::JOYPAD_BTN::RIGHT:
		break;
	case InputManager::JOYPAD_BTN::TOP:
		break;
	case InputManager::JOYPAD_BTN::DOWN:
		break;
	case InputManager::JOYPAD_BTN::R_TRIGGER:
		break;
	case InputManager::JOYPAD_BTN::L_TRIGGER:
		break;
	}
}

bool InputManager::InputFunc::GetCanPause(void)
{
	return canPause;
	
}

InputManager::TYPE_DEVICE InputManager::InputFunc::GetDeviceType(void)
{
	return device;
}

int InputManager::InputFunc::GetPadNo(void)
{
	return padNo;
}

