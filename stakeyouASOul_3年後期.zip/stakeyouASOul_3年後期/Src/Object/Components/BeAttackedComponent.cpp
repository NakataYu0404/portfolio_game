#include "../../Utility/Utility.h"
#include "HPAccessor.h"
#include "BeAttackedComponent.h"

BeAttackedComponent::BeAttackedComponent(IObjectBase& owner, ActorBase& owneract, IPlayerData& ownerdata, IBeAttaked& guard, IInfoProvider2Player& actOwner) :ComponentBase(owner), owneract_(owneract), ownerData_(ownerdata), guard_(guard),actOwner_(actOwner)
{
	pushBack_ = { 0.0f,0.0f,0.0f };
}

void BeAttackedComponent::BatchUpdate(void)
{
	if (pushBack_.x != 0.0f )
	{
		//	�����߂���z�͕K�v�Ȃ�����0��
		pushBack_.z = 0.0f;

		owneract_.GetTransform().lock()->pos = VAdd(owneract_.GetTransform().lock()->pos, pushBack_);
		pushBack_ = { 0.0f,0.0f,0.0f };
	}
}

//	�������̍U��
void BeAttackedComponent::Attacked(SummonedBase::SUMMOND_ATTACK_BASE& data)
{
	bool isGuard = guard_.IsCanGuard(data.guardDir);

	if (isGuard)
	{
		actOwner_.HitStop(HITSTOP_FRAME);
		//	�K�[�h�ł���
		guard_.ChangeState4Guard(data);
		pushBack_ = data.knockbackDirGuard;
	}
	else
	{
		actOwner_.HitStop(HITSTOP_FRAME);
		//	�K�[�h�ł��ĂȂ�
		pushBack_ = data.knockbackDirHit;
		CHPAccessor::RequestDamage(owneract_, data.damage, isGuard);

		switch (data.hitType)
		{
		case HIT_TYPE::NORMAL:
			guard_.ChangeState4Pain(data);
			break;
		case HIT_TYPE::DOWN:
			guard_.ChangeState4Down();
			break;
		}

	}
	if (ownerData_.IsPosSideLeft())
	{
		pushBack_.x *= -1;
	}
}

//	�ʏ�U��
void BeAttackedComponent::Attacked(ATTACK_DATA& data)
{
	bool isGuard = guard_.IsCanGuard(data.guardDir);

	if (isGuard)
	{
		actOwner_.HitStop(HITSTOP_FRAME);
		//	�K�[�h�ł���
		guard_.ChangeState4Guard(data);
		pushBack_ = data.knockbackDirGuard;
	}
	else
	{
		actOwner_.HitStop(HITSTOP_FRAME);
		//	�K�[�h�ł��ĂȂ�
		pushBack_ = data.knockbackDirHit;
		CHPAccessor::RequestDamage(owneract_, data.damage, isGuard);

		switch (data.hitType)
		{
		case HIT_TYPE::NORMAL:
			guard_.ChangeState4Pain(data);
			break;
		case HIT_TYPE::DOWN:
			guard_.ChangeState4Down();
			break;
		}

	}
	if (ownerData_.IsPosSideLeft())
	{
		pushBack_.x *= -1;
	}
}

//	�R�}���h�Z�̍U��
void BeAttackedComponent::Attacked(SKILL_DATA& data)
{
	bool isGuard = guard_.IsCanGuard(data.guardDir);

	if (isGuard)
	{
		actOwner_.HitStop(HITSTOP_FRAME);
		//	�K�[�h�ł���
		guard_.ChangeState4Guard(data);
		pushBack_ = data.knockbackDirGuard;
	}
	else
	{
		actOwner_.HitStop(HITSTOP_FRAME);
		//	�K�[�h�ł��ĂȂ�
		pushBack_ = data.knockbackDirHit;
		CHPAccessor::RequestDamage(owneract_, data.damage, isGuard);

		switch (data.hitType)
		{
		case HIT_TYPE::NORMAL:
			guard_.ChangeState4Pain(data);
			break;
		case HIT_TYPE::DOWN:
			guard_.ChangeState4Down();
			break;
		}

	}
	if (ownerData_.IsPosSideLeft())
	{
		pushBack_.x *= -1;
	}
}
