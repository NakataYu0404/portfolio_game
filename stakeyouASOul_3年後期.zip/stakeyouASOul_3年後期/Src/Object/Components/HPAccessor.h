#pragma once
#include "HPComponent.h"
#include "../ActorBase.h"

class CHPAccessor
{
public:
	static void RequestDamage(ActorBase& target, int damage, bool isGuard)
	{
		IHp* hpComp = static_cast<IHp*>(target.GetComponent<HPComponent>());

		if (hpComp != nullptr)
		{
			if (isGuard)
			{
				hpComp->ChipDamage(damage);
			}
			else
			{
				hpComp->Damage(damage);
			}
		}
	}
};