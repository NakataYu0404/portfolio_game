#include "../../Parameter/AttackBaseComponent.h"
#include "../../Parameter/AttackDetailComponent.h"
#include "../../../Common/CharacterDataLoader.h"

#include "AttackStateComponent.h"

AttackStateComponent::AttackStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack) 
	:StateBase(owner, StateInterfacePack), colliderFunc_(StateInterfacePack.collider), timerFunc_(StateInterfacePack.timer)
	, attackFunc_(StateInterfacePack.attack), animFunc_(StateInterfacePack.animation), jumpAttackFunc_(StateInterfacePack.jumpAttack)
{
	dataLoader_ = std::make_unique<CharacterDataLoader>();

	nowAttackType_ = ATTACK_TYPE::NONE;
	oldAttackState_ = ATTACK_STATE::NONE;
}

void AttackStateComponent::ManualUpdate(void)
{
	//	SetAttack()�ŃZ�b�g���ꂽ�ʏ�U��or�R�}���h�Z��Update�֐�
	updateFuncs_();
}

void AttackStateComponent::SetAttack(ATTACK_TYPE type)
{
	//	�����^�C�v�̍U�������݂��邩�`�F�b�N
	if (attackNormal_.find(type) == attackNormal_.end()) { return; }

	//	Update�֐��������^�C�v�p�̊֐��ɕύX
	updateFuncs_ = [this, &data = attackNormal_[type]]() {
		this->AttackUpdate(data); 
	};

	nowAttackType_ = type;
	nowAttackCommand_ = COMMAND::NONE;
}

void AttackStateComponent::SetAttack(COMMAND command)
{
	//	�����R�}���h�̃R�}���h�Z�����݂��邩�`�F�b�N
	if (attackSkill_.find(command) == attackSkill_.end()) { return; }

	//	Update�֐��������R�}���h�p�̊֐��ɕύX
	updateFuncs_ = [this, &data = attackSkill_[command]](){
		this->AttackUpdate(data);
	};

	nowAttackType_ = ATTACK_TYPE::COMMAND;
	nowAttackCommand_ = command;
}

//	�ʏ�U�����[�h�p�֐�(�eCharacter�N���X��Init���Ă�)
void AttackStateComponent::LoadNormalAttackData(const std::string& filePath) 
{
	dataLoader_->LoadNormalAttackData(filePath, attackNormal_);
}

//	�R�}���h�Z���[�h�p�֐�(�eCharacter�N���X��Init���Ă�)
void AttackStateComponent::LoadSkillAttackData(const std::string& filePath)
{
	dataLoader_->LoadSkillAttackData(filePath, attackSkill_);
}

void AttackStateComponent::AttackUpdate(ATTACK_DATA& data)
{

	//	�U������̐���
	if (data.startHitFrame > timerFunc_.GetUpdateFrame())
	{
		//	�U�������O�̃R���C�_
		if (oldAttackState_ != ATTACK_STATE::BEFORE)
		{
			ChangeCollider4StateAttack(ATTACK_STATE::BEFORE);
			oldAttackState_ = ATTACK_STATE::BEFORE;
		}
	}
	else if (data.startHitFrame + data.activeHitFrame > timerFunc_.GetUpdateFrame())
	{
		//	�U���������̃R���C�_
		if (oldAttackState_ != ATTACK_STATE::ATTACKING)
		{
			ChangeCollider4StateAttack(ATTACK_STATE::ATTACKING);
			oldAttackState_ = ATTACK_STATE::ATTACKING;
		}
	}
	else if (oldAttackState_ != ATTACK_STATE::PUNISH)
	{
		//	�U����̌��̃R���C�_
		ChangeCollider4StateAttack(ATTACK_STATE::PUNISH);
		oldAttackState_ = ATTACK_STATE::PUNISH;
	}

	if (canCancelTimer_ < data.cancelTime)
	{
		attackFunc_.SetAttackUpdateFunc();
	}

	if (nowAttackType_ != ATTACK_TYPE::LOW_J && nowAttackType_ != ATTACK_TYPE::MIDDLE_J && nowAttackType_ != ATTACK_TYPE::HI_J && nowAttackType_ != ATTACK_TYPE::SPECIAL_J)
	{
		//	�s���I���t���[���𒴉߂�����Idle��
		if (data.allFrame <= timerFunc_.GetUpdateFrame())
		{
			commonFunc_.ChangeState(STATE::IDLE);
			oldAttackState_ = ATTACK_STATE::NONE;
			canCancelTimer_ = CANTCANSEL_TIMER;
			nowAttackType_ = ATTACK_TYPE::NONE;
			return;
		}
	}

	//	�W�����v�U���Ɏg�������ȃA�j���[�V�������Ȃ������̂ŁA�W�����v���[�V�����ƍU�����ۂ��|�[�Y�̃u�����h�ł�����ۂ�
	if ((nowAttackType_ == ATTACK_TYPE::LOW_J || nowAttackType_ == ATTACK_TYPE::MIDDLE_J || nowAttackType_ == ATTACK_TYPE::HI_J || nowAttackType_ == ATTACK_TYPE::SPECIAL_J) 
		&& jumpAttackFunc_.GetJumpAttackPunishFrame_A2J() <= 0)
	{
		animFunc_.AnimBlend(data.animationType[ActorBase::LeftOrRight::MIDDLE], data.startHitFrame, false);
	}
	else
	{
		if (data.animationType.find(commonFunc_.GetPlayerData().GetPosSide()) == data.animationType.end())
		{
			//	�A�j���[�V�����ɍ��E����������������
			animFunc_.ChangeAnimation(data.animationType[ActorBase::LeftOrRight::MIDDLE], false);
		}
		else
		{
			animFunc_.ChangeAnimation(data.animationType[commonFunc_.GetPlayerData().GetPosSide()], false);
		}
	}

	timerFunc_.CountUpUpdateFrame();
	canCancelTimer_++;

	if (nowAttackType_ == ATTACK_TYPE::LOW_J || nowAttackType_ == ATTACK_TYPE::MIDDLE_J || nowAttackType_ == ATTACK_TYPE::HI_J || nowAttackType_ == ATTACK_TYPE::SPECIAL_J)
	{
		jumpAttackFunc_.JumpInAttack_A2J();
	}

}

void AttackStateComponent::AttackUpdate(SKILL_DATA& data)
{
	switch (data.skillType)
	{
	case SKILL_TYPE::NORMAL:
		//	�U������̐���
		if (data.startHitFrame > timerFunc_.GetUpdateFrame())
		{
			//	�U�������O�̃R���C�_
			if (oldAttackState_ != ATTACK_STATE::BEFORE)
			{
				ChangeCollider4StateAttack(ATTACK_STATE::BEFORE);
				oldAttackState_ = ATTACK_STATE::BEFORE;
			}
		}
		else if (data.startHitFrame + data.activeHitFrame > timerFunc_.GetUpdateFrame())
		{
			//	�U���������̃R���C�_
			if (oldAttackState_ != ATTACK_STATE::ATTACKING)
			{
				ChangeCollider4StateAttack(ATTACK_STATE::ATTACKING);
				oldAttackState_ = ATTACK_STATE::ATTACKING;
			}
		}
		else if (oldAttackState_ != ATTACK_STATE::PUNISH)
		{
			//	�U����̌��̃R���C�_
			ChangeCollider4StateAttack(ATTACK_STATE::PUNISH);
			oldAttackState_ = ATTACK_STATE::PUNISH;
		}

		//	�s���I���t���[���𒴉߂�����Idle��
		if (data.allFrame <= timerFunc_.GetUpdateFrame())
		{
			commonFunc_.ChangeState(STATE::IDLE);
			oldAttackState_ = ATTACK_STATE::NONE;
			canCancelTimer_ = CANTCANSEL_TIMER;
			nowAttackType_ = ATTACK_TYPE::NONE;
			nowAttackCommand_ = COMMAND::NONE;
			return;
		}

		break;
	case SKILL_TYPE::GENERATE:

		//	�U������̐���
		if (data.startHitFrame > timerFunc_.GetUpdateFrame())
		{
			//	�U�������O�̃R���C�_
			if (oldAttackState_ != ATTACK_STATE::BEFORE)
			{
				ChangeCollider4StateAttack(ATTACK_STATE::BEFORE);
				oldAttackState_ = ATTACK_STATE::BEFORE;
			}
		}
		else if (oldAttackState_ == ATTACK_STATE::BEFORE)
		{
			if (commonFunc_.GetPlayerData().IsPosSideLeft())
			{
				attackFunc_.MobGenerate(VAdd(commonFunc_.GetPlayerData().GetPos(), data.generatePos), data);
			}
			else
			{
				attackFunc_.MobGenerate({ commonFunc_.GetPlayerData().GetPos().x - data.generatePos.x,commonFunc_.GetPlayerData().GetPos().y + data.generatePos.y,commonFunc_.GetPlayerData().GetPos().z + data.generatePos.z }, data);
			}


			oldAttackState_ = ATTACK_STATE::ATTACKING;
		}
		else if (oldAttackState_ != ATTACK_STATE::PUNISH)
		{
			//	�U����̌��̃R���C�_
			ChangeCollider4StateAttack(ATTACK_STATE::PUNISH);
			oldAttackState_ = ATTACK_STATE::PUNISH;
		}

		//	�s���I���t���[���𒴉߂�����Idle��
		if (data.allFrame <= timerFunc_.GetUpdateFrame())
		{
			commonFunc_.ChangeState(STATE::IDLE);
			oldAttackState_ = ATTACK_STATE::NONE;
			canCancelTimer_ = CANTCANSEL_TIMER;
			nowAttackType_ = ATTACK_TYPE::NONE;
			nowAttackCommand_ = COMMAND::NONE;
			return;
		}
		break;
	}

	if (data.animationType.find(commonFunc_.GetPlayerData().GetPosSide()) == data.animationType.end())
	{
		//	�A�j���[�V�����ɍ��E����������������
		animFunc_.ChangeAnimation(data.animationType[ActorBase::LeftOrRight::MIDDLE], false);
	}
	else
	{
		animFunc_.ChangeAnimation(data.animationType[commonFunc_.GetPlayerData().GetPosSide()], false);
	}

	timerFunc_.CountUpUpdateFrame();
	canCancelTimer_++;

}

const ATTACK_TYPE AttackStateComponent::GetNowAttackType(void) const
{
	return nowAttackType_;
}

const COMMAND AttackStateComponent::GetNowAttackCommand(void) const
{
	return nowAttackCommand_;
}

void AttackStateComponent::Landing(void)
{
	oldAttackState_ = ATTACK_STATE::NONE;
	canCancelTimer_ = CANTCANSEL_TIMER;
	nowAttackType_ = ATTACK_TYPE::NONE;

}

void AttackStateComponent::SetNoAtkNow(void)
{
	oldAttackState_ = ATTACK_STATE::NONE;
	nowAttackType_ = ATTACK_TYPE::NONE;
}

void AttackStateComponent::SetCancelTimer(int frame)
{
	canCancelTimer_ = frame;
}

std::unordered_map<ATTACK_TYPE, ATTACK_DATA>& AttackStateComponent::GetAttacks(void)
{
	return attackNormal_;
}

std::unordered_map<COMMAND, SKILL_DATA>& AttackStateComponent::GetSkills(void)
{
	return attackSkill_;
}

ATTACK_DATA& AttackStateComponent::GetAttack(ATTACK_TYPE type)
{
	if (attackNormal_.find(type) == attackNormal_.end())
	{
		ATTACK_DATA atk;
		return atk;
	}

	return attackNormal_[type];
}

SKILL_DATA& AttackStateComponent::GetSkill(COMMAND command)
{
	if (attackSkill_.find(command) == attackSkill_.end())
	{
		SKILL_DATA atk;
		return atk;
	}

	return attackSkill_[command];
}

const bool AttackStateComponent::IsRegisterAttack(ATTACK_TYPE type)
{
	if (attackNormal_.find(type) == attackNormal_.end()) { return false; };
	return true;
}

const bool AttackStateComponent::IsRegisterSkill(COMMAND command)
{
	if (attackSkill_.find(command) == attackSkill_.end()) { return false; };
	return true;
}

void AttackStateComponent::ChangeCollider4StateAttack(ATTACK_STATE atkState)
{

	if (atkState == ATTACK_STATE::NONE) { return; }

	if (nowAttackType_ == ATTACK_TYPE::COMMAND)
	{
		auto skillIt = attackSkill_.find(nowAttackCommand_);
		if (skillIt != attackSkill_.end()) {
			auto colIt = skillIt->second.colMapAtk_.find(atkState);
			if (colIt != skillIt->second.colMapAtk_.end()) {
				colliderFunc_.ChangeColliderColMap(
					std::make_shared<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>>(colIt->second)
				);
			}
		}
		return;
	}

	auto normalIt = attackNormal_.find(nowAttackType_);
	if (normalIt != attackNormal_.end()) {
		auto colIt = normalIt->second.colMapAtk_.find(atkState);
		if (colIt != normalIt->second.colMapAtk_.end()) {
			colliderFunc_.ChangeColliderColMap(
				std::make_shared<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>>(colIt->second));
		}
	}
}
