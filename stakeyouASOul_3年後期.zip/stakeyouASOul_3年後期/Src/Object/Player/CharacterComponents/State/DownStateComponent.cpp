#include "../../CharacterBase.h"
#include "StateInterfacePack.h"
#include "DownStateComponent.h"

DownStateComponent::DownStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack)
	:StateBase(owner, StateInterfacePack),  animFunc_(StateInterfacePack.animation),
	 colliderFunc_(StateInterfacePack.collider), timerFunc_(StateInterfacePack.timer)
{
}

void DownStateComponent::ManualUpdate(void)
{
	commonFunc_.CheckSidePosition();

	colliderFunc_.ChangeCollider4StateNoAttack();
	animFunc_.ChangeAnimation(ANIM_TYPE::DOWN, false);
	timerFunc_.CountUpUpdateFrame();
	if (animFunc_.IsEndAnimation())
	{
		//	�N���オ��update��
		commonFunc_.ChangeState(STATE::GETUP);
	}
}
