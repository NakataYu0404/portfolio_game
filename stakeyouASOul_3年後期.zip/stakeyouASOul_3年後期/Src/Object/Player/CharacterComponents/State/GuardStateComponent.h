#pragma once
#include "StateBase.h"

class IInputInfo;
class IAnimationControl;
class IColliderControl;
class ITimerControl;

class ATTACK_BASE;

class GuardStateComponent : public StateBase {
public:

    GuardStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack);

    void ManualUpdate(void) override;

    void SetAttackData(ATTACK_BASE& data);
private:

    ATTACK_BASE atkData_;

    IInputInfo& inputFunc_;
    IAnimationControl& animFunc_;
    IColliderControl& colliderFunc_;
    ITimerControl& timerFunc_;

};