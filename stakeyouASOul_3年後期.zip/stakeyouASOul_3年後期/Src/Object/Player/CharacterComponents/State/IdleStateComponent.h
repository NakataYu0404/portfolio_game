#pragma once
#include "StateBase.h"

class IInputInfo;
class IAnimationControl;
class IAttackControl;
class IColliderControl;

class IdleStateComponent : public StateBase {
public:

    IdleStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack);

    void ManualUpdate(void) override;

private:

    IInputInfo& inputFunc_;
    IAnimationControl& animFunc_;
    IAttackControl& attackFunc_;
    IColliderControl& colliderFunc_;
};