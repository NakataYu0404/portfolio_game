#pragma once
#include "StateBase.h"
#include "../../../ActorBase.h"

class IInputInfo;
class IAnimationControl;
class IAttackControl;
class IColliderControl;
class ITimerControl;
class IMovementControl;
class IStateControl;
class IJumpAttackControl;

class JumpStateComponent : public StateBase
{
public:
    JumpStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack);

    void Enter(void) override;
    void ManualUpdate(void) override;
    void JumpAttacking(void);

    const int GetJumpAtkPunishFrame(void) const;

private:
    void Jump(void);

    // �萔
    static constexpr float JUMP_POW_1ST = 25.0f;
    static constexpr float JUMP_MOVEPOW_X = 3.0f;

    // �C���^�[�t�F�[�X
    IInputInfo& inputFunc_;
    IAnimationControl& animFunc_;
    IAttackControl& attackFunc_;
    IColliderControl& colliderFunc_;
    ITimerControl& timerFunc_;
    IMovementControl& moveFunc_;
    IStateControl& stateFunc_;
    IJumpAttackControl& jumpAttackFunc_;

    // ��ԊǗ��p
    bool JumpProcess1st_ = false;

    int jAtkPunishFrame_ = 0;

    ActorBase::LeftOrRight LorMorR_ = ActorBase::LeftOrRight::MIDDLE;

};