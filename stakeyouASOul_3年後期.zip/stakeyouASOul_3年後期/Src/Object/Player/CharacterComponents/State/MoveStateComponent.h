#pragma once
#include "StateBase.h"
#include "../../../ActorBase.h"

class IInputInfo;
class IAnimationControl;
class IAttackControl;
class IColliderControl;
class IMovementControl;

class MoveStateComponent : public StateBase
{
public:

    MoveStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack);

    void ManualUpdate(void) override;

private:
    void Walk(ActorBase::LeftOrRight LorR);

    //  �����������Ƃ��ɁA�ړ����x�ɂ����錸���l
    static constexpr float MOVE_BACK_COEFFICIENT = 0.6f;

    IInputInfo& inputFunc_;
    IAnimationControl& animFunc_;
    IAttackControl& attackFunc_;
    IColliderControl& colliderFunc_;
    IMovementControl& moveFunc_;
};