#include "../../CharacterBase.h"
#include "StateInterfacePack.h"
#include "ReviveStateComponent.h"

ReviveStateComponent::ReviveStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack)
	:StateBase(owner, StateInterfacePack), animFunc_(StateInterfacePack.animation),
	colliderFunc_(StateInterfacePack.collider), timerFunc_(StateInterfacePack.timer),
	noticeFunc_(StateInterfacePack.notice), setLifeFunc_(StateInterfacePack.setLife)
{
	int i = 0;
}

void ReviveStateComponent::ManualUpdate(void)
{
	animFunc_.ChangeAnimation(ANIM_TYPE::GETUP, false);
	if (animFunc_.IsEndAnimation() && commonFunc_.GetPlayerData().IsAlive())
	{
		//	Idleupdate��
		commonFunc_.ChangeState(STATE::IDLE);
		noticeFunc_.noticeRevive();
	}
	else
	{
		setLifeFunc_.Heal();
	}
}
