#pragma once
#include "StateBase.h"

class IAnimationControl;
class IColliderControl;
class ITimerControl;
class INoticeOwner;
class ISetLifeControl;


class ReviveStateComponent : public StateBase {
public:

    ReviveStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack);

    void ManualUpdate(void) override;

private:


    IAnimationControl& animFunc_;
    IColliderControl& colliderFunc_;
    ITimerControl& timerFunc_;
    INoticeOwner& noticeFunc_;
    ISetLifeControl& setLifeFunc_;
};