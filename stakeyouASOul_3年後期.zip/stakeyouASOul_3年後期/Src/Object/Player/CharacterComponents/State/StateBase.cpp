#include "StateInterfacePack.h"
#include "StateBase.h"

StateBase::StateBase(IObjectBase& owner, StateInterfacePack& StateInterfacePack) :ComponentBase(owner), commonFunc_(StateInterfacePack.common)
{
}
