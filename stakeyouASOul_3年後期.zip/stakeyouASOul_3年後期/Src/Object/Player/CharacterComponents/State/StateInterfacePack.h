#pragma once

// �C���^�[�t�F�[�X�Q�̑O���錾
class IActionbyStateCommon;
class IInputInfo;
class IAnimationControl;
class IAttackControl;
class IColliderControl;
class ITimerControl;
class IMovementControl;
class IStateControl;
class IJumpAttackControl;
class INoticeOwner;
class ISetLifeControl;

// ���ׂĂ�State���ʂ̈ˑ��֌W���܂Ƃ߂��\����
struct StateInterfacePack {

    IActionbyStateCommon& common;
    IInputInfo& input;
    IAnimationControl& animation;
    IAttackControl& attack;
    IColliderControl& collider;
    ITimerControl& timer;
    IMovementControl& movement;
    IStateControl& state;
    IJumpAttackControl& jumpAttack;
    INoticeOwner& notice;
    ISetLifeControl& setLife;
};