#pragma once
#include <string>
#include <DxLib.h>
#include "../../ActorBase.h"

class SummonedBase;
class IInfoProvider2Player;
class SKILL_DATA;

class MobGenerator
{
public:
	MobGenerator(class IInfoProvider2Player& owner,std::string myPlayerNumber);
	~MobGenerator(void);

	void Generate(ActorBase::LeftOrRight posSide,VECTOR generatePos, SKILL_DATA& data);

private:
	IInfoProvider2Player& owner_;
	std::string myPlayerNumber_;
};

