#include <string>
#include <DxLib.h>
#include <EffekseerForDXLib.h>
#include "../Utility/Utility.h"
#include "../Manager/ResourceManager.h"
#include "Common/CollisionManager.h"
#include "Common/EffectController.h"
#include "Common/Collider.h"
#include "Common/Transform.h"
#include "../Scene/SceneBase.h"
#include "Stage.h"

Stage::Stage(int drawPrio):colMng_(CollisionManager::GetInstance())
{
	//backGround_ = std::make_shared<Transform>();
	colMng_.Add(static_cast<std::string>(Utility::OBJECT_NAME::STAGE), this);
}

Stage::~Stage(void)
{
	//backGround_->Release();
}

void Stage::Init(void)
{
	auto& res = ResourceManager::GetInstance();
	transform_->SetModel(res.LoadModelDuplicate(ResourceManager::SRC::MDL_STAGE));
	transform_->pos = { 0.0f,0.0f,0.0f };
	transform_->scl = { 1.0f,1.5f,1.0f };
	transform_->quaRot = Quaternion();
	transform_->localPos = { 0.0f,0.0f,0.0f };
	transform_->Update();

	//backGround_->SetModel(res.LoadModelDuplicate(ResourceManager::SRC::MDL_BACKGROUND));
	//backGround_->pos = { 0.0f,0.0f,0.0f };
	//backGround_->scl = { 0.4f,0.4f,0.4f };
	//backGround_->quaRot = Quaternion();
	//backGround_->localPos = { 0.0f,0.0f,0.0f };
	//backGround_->Update();

	std::shared_ptr<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>> map = std::make_shared<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>>();
	Collider::COLLISION_SQUERE col;
	col.UP_L = { -2000.0f,1000.0f,0.0f };
	col.UP_R = { -1000.0f,1000.0f,0.0f };
	col.DOWN_L = { -2000.0f,-1000.0f,0.0f };
	col.DOWN_R = { -1000.0f,-1000.0f,0.0f };
	map->emplace(Collider::Category::PUSH, col);
	col.UP_L = { 1000.0f,1000.0f,0.0f };
	col.UP_R = { 2000.0f,1000.0f,0.0f };
	col.DOWN_L = { 1000.0f,-1000.0f,0.0f };
	col.DOWN_R = { 2000.0f,-1000.0f,0.0f };
	map->emplace(Collider::Category::PUSH, col);

	transform_->MakeCollider(map, Collider::TYPE::STAGE);
	transform_->Update();
}

void Stage::Update(void)
{
}

void Stage::Draw()
{
	MV1DrawModel(transform_->modelId);
	// MV1DrawModel(backGround_->modelId);
}


void Stage::SetParam(void)
{
}
