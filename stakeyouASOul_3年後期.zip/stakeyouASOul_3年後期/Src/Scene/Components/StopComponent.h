#pragma once
#include "../../Component/ComponentBase.h"
#include "../../Common/ObjectBase.h"

class StopComponent:public ComponentBase
{
public:

	enum class STOP_TYPE
	{
		HITSTOP,
		ALLSTOP,
	};

	StopComponent(IObjectBase& owner);

	void Stop(int stopFrame, STOP_TYPE type);

	bool IsStop(void);

	STOP_TYPE GetStopType(void);

private:
	void BatchUpdate(void) override;

	int stopFrame_;
	int timer_;
	bool isStop_;
	STOP_TYPE type_;
};

