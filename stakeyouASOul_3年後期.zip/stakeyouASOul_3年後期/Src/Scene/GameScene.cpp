#include <DxLib.h>
#include <algorithm>
#include "../Application.h"
#include "../Manager/InputManager.h"
#include "../Manager/SceneManager.h"
#include "../Manager/Camera.h"
#include "../Manager/ResourceManager.h"
#include "../Manager/UIManager.h"
#include "../Object/Common/CollisionManager.h"
#include "Components/StopComponent.h"
#include "../Object/ActorBase.h"
#include "../Object/Player/Ghostleman/Ghostleman.h"
#include "../Object/Stage.h"
#include "GameScene.h"

GameScene::GameScene(): colMng_(CollisionManager::CreateInstance())
{
	ChangeState(std::bind(&GameScene::RoundCallUpdate, this));
}

GameScene::~GameScene()
{
	colMng_.ClearCollider();
}

void GameScene::Init(void)
{
	
	//	��_�J����
	SceneManager::GetInstance().GetCamera()->ChangeMode(Camera::MODE::FOLLOW);


	if (plNum_ == SceneManager::PLNUM::DEMO)
	{
		SceneBase::AddActor(std::move(std::make_unique<Ghostleman>(player1_, *this, true)), ActorBase::DrawPriority::PLAYER_F);
		SceneBase::AddActor(std::move(std::make_unique<Ghostleman>(player2_, *this, true)), ActorBase::DrawPriority::PLAYER_B);
		
		//	�}�W�b�N
		demoTimer_ = 7200;

		imgPushHdl_ = resMng_.Load(ResourceManager::SRC::IMG_PUSHSPACE).handleId_;

	}
	else if(plNum_ == SceneManager::PLNUM::SOLO)
	{
		SceneBase::AddActor(std::move(std::make_unique<Ghostleman>(player1_, *this)), ActorBase::DrawPriority::PLAYER_F);
		SceneBase::AddActor(std::move(std::make_unique<Ghostleman>(player2_, *this, true)), ActorBase::DrawPriority::PLAYER_B);
	}
	else
	{
		SceneBase::AddActor(std::move(std::make_unique<Ghostleman>(player1_, *this)), ActorBase::DrawPriority::PLAYER_F);
		SceneBase::AddActor(std::move(std::make_unique<Ghostleman>(player2_, *this)), ActorBase::DrawPriority::PLAYER_B);
	}

	isFrontPlayer_ = player1_;

	stage_ = std::make_unique<Stage>();
	SortActor();
	for (auto& actor : activeActors_)
	{
		actor.actor->Init();
		actor.actor->Update();
	}
	stage_->Init();
	stage_->Update();

	cameraFollowPos_ = VAdd(playerDatas_[0]->GetPlayerData().GetPos(), Utility::VDiv(VSub(playerDatas_[1]->GetPlayerData().GetPos(), playerDatas_[0]->GetPlayerData().GetPos()), 2));
	p2pDistanse_ = Utility::DistanceV(playerDatas_[0]->GetPlayerData().GetPos(), playerDatas_[1]->GetPlayerData().GetPos(),true);
	SceneManager::GetInstance().GetCamera()->SetFollow(&cameraFollowPos_, &p2pDistanse_);


	 img_round_ = resMng_.Load(ResourceManager::SRC::IMG_ROUND).handleId_;
	 img_roundNum_[0] = resMng_.Load(ResourceManager::SRC::IMG_ROUND_1).handleId_;
	 img_roundNum_[1] = resMng_.Load(ResourceManager::SRC::IMG_ROUND_2).handleId_;
	 img_roundNum_[2] = resMng_.Load(ResourceManager::SRC::IMG_ROUND_3).handleId_;
	 img_fight_ = resMng_.Load(ResourceManager::SRC::IMG_FIGHT).handleId_;

	  img_win_p1_ = resMng_.Load(ResourceManager::SRC::IMG_WIN_P1).handleId_;
	  img_win_p2_ = resMng_.Load(ResourceManager::SRC::IMG_WIN_P2).handleId_;

	  snd_win_ = resMng_.Load(ResourceManager::SRC::BGM_WIN).handleId_;
	  snd_battle_ = resMng_.Load(ResourceManager::SRC::BGM_BATTLE).handleId_;

	  snd_callNum_[0] = resMng_.Load(ResourceManager::SRC::SE_CALL_1).handleId_;
	  snd_callNum_[1] = resMng_.Load(ResourceManager::SRC::SE_CALL_2).handleId_;
	  snd_callNum_[2] = resMng_.Load(ResourceManager::SRC::SE_CALL_3).handleId_;
	  snd_call_fight_ = resMng_.Load(ResourceManager::SRC::SE_CALL_FIGHT).handleId_;

	 isNowRoundCall_ = true;
	 isWinP1_ = false;
	 isWinP2_ = false;
	 isDraw_ = false;

	LoadComponents();

	auto& inputM = InputManager::GetInstance();
	isDrawHitBox_ = false;
	inputM.AddInputFunction(*this, InputManager::TYPE_DEVICE::KEYBOARD, KEY_INPUT_X,
		[&] {ChangeDrawHitBox();}, InputManager::INPUT_TYPE::TRIGGER);

	InitUI();
}

void GameScene::InitUI(void)
{
}

void GameScene::Update(void)
{
	if (plNum_ == SceneManager::PLNUM::DEMO)
	{
		DemoUpdate();
	}

	updateFuncs_();

	for (auto& c : components_)
	{
		c->BatchUpdate();

	}
	auto& sceneM = SceneManager::GetInstance();
	auto& inputM = InputManager::GetInstance();

	if (isWinP1_ || isWinP2_)
	{
		if (inputM.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::DOWN) || CheckHitKey(KEY_INPUT_SPACE))
		{
			sceneM.ChangeScene(SceneManager::SCENE_ID::TITLE);
		}
	}

	for(int i = 0; i < addActorsLater_.size();i++)
	{
		//	Update������ɁA�V�������ꂽActor��Actors_�ɂ����
		SceneBase::AddActor(std::move(addActorsLater_[i].actor), addActorsLater_[i].drawPriority);
	}

	UIMng_.Update();

	addActorsLater_.clear();

}

void GameScene::Draw(void)
{
	stage_->Draw();

	for (auto& actor : activeActors_)
	{
		actor.actor->Draw();
	}

	if (isNowRoundCall_)
	{
		if (updatingFrame_ < 240)
		{
			DrawGraph(0, 0, img_round_, true);

			int totalLife = playerDatas_[0]->GetPlayerData().GetLife() + playerDatas_[1]->GetPlayerData().GetLife();

			//	�}�W�b�N�i���o�[
			int roundIndex = 4 - totalLife;
			if (roundIndex >= 0 && roundIndex <= 2)
			{
				int i = roundIndex;
				DrawGraph(0, 0, img_roundNum_[i], true);

				if (snd_callNum_[i] != -1)
				{
					PlaySoundMem(snd_callNum_[i], DX_PLAYTYPE_BACK);
					snd_callNum_[i] = -1;
				}
			}
			calledFight_ = false;
		}
		else
		{
			DrawGraph(0, 0, img_fight_, true);
			if (!calledFight_)
			{
				PlaySoundMem(snd_call_fight_, DX_PLAYTYPE_BACK);
				calledFight_ = true;
			}
		}
	}

	if (isWinP1_)
	{
		DrawGraph(0, 0, img_win_p1_,true);
	}
	else if (isWinP2_)
	{
		DrawGraph(0, 0, img_win_p2_,true);
	}
	else if (isDraw_)
	{
	}

	if (isDrawHitBox_)
	{
		colMng_.Draw();
	}

	if (plNum_ == SceneManager::PLNUM::DEMO)
	{
		//	�}�W�b�N�i���o�[
		if (demoTimer_ % 30 < 20)
		{
			DrawGraph(Application::SCREEN_SIZE_X / 2 - 256, 900, imgPushHdl_, true);
		}
	}


	UIMng_.Draw();

#pragma region �f�o�b�O
	DrawFormatString(10, 10, GetColor(255, 255, 255), "�L�[�{�[�h��X�L�[�œ����蔻��\���؂�ւ�");
#pragma endregion
}

void GameScene::RoundCallUpdate(void)
{
	for (int i = 0; const auto & actorInfo : activeActors_)
	{
		actorInfo.actor->Update();
		AdJustPlayerFrontBack(i);
		i++;
	}
	SortActor();
	cameraFollowPos_ = VAdd(playerDatas_[0]->GetPlayerData().GetPos(), Utility::VDiv(VSub(playerDatas_[1]->GetPlayerData().GetPos(), playerDatas_[0]->GetPlayerData().GetPos()), 2));
	p2pDistanse_ = Utility::DistanceV(playerDatas_[0]->GetPlayerData().GetPos(), playerDatas_[1]->GetPlayerData().GetPos(), true);

	if (updatingFrame_ > 300)
	{
		ChangeState(std::bind(&GameScene::FightUpdate, this));
	}
	isNowRoundCall_ = true;
	updatingFrame_++;

	if (!calledBgm_)
	{
		PlaySoundMem(snd_battle_, DX_PLAYTYPE_LOOP);
		calledBgm_ = true;
	}
}

void GameScene::FightUpdate(void)
{
	if (!GetComponent<StopComponent>()->IsStop())
	{
		for (int i = 0; const auto & actorInfo : activeActors_)
		{
			actorInfo.actor->Update();
			AdJustPlayerFrontBack(i);
			i++;
		}
		colMng_.Update();
		SortActor();
		cameraFollowPos_ = VAdd(playerDatas_[0]->GetPlayerData().GetPos(), Utility::VDiv(VSub(playerDatas_[1]->GetPlayerData().GetPos(), playerDatas_[0]->GetPlayerData().GetPos()), 2));
		p2pDistanse_ = Utility::DistanceV(playerDatas_[0]->GetPlayerData().GetPos(), playerDatas_[1]->GetPlayerData().GetPos(), true);
	}
	else
	{
		for (const auto& actorInfo : activeActors_)
		{
			actorInfo.actor->UpdateStop();
		}
	}
	isNowRoundCall_ = false;
	updatingFrame_++;
}

void GameScene::BreakTimeUpdate(void)
{
	//	�񕜂����āA�񕜂��������烉�E���h�R�[����
	for (int i = 0; const auto & actorInfo : activeActors_)
	{
		actorInfo.actor->Update();
		AdJustPlayerFrontBack(i);
		i++;
	}
	SortActor();
	cameraFollowPos_ = VAdd(playerDatas_[0]->GetPlayerData().GetPos(), Utility::VDiv(VSub(playerDatas_[1]->GetPlayerData().GetPos(), playerDatas_[0]->GetPlayerData().GetPos()), 2));
	p2pDistanse_ = Utility::DistanceV(playerDatas_[0]->GetPlayerData().GetPos(), playerDatas_[1]->GetPlayerData().GetPos(), true);
	isNowRoundCall_ = false;
	updatingFrame_++;
}

void GameScene::EndUpdate(void)
{
	if (playerDatas_[0]->GetPlayerData().GetLife() >= 1 && playerDatas_[1]->GetPlayerData().GetLife() >= 1)
	{
		isDraw_ = true;
	}
	else if (playerDatas_[0]->GetPlayerData().GetLife() >= 1)
	{
		isWinP1_ = true;
	}
	else
	{
		isWinP2_ = true;
	}

	auto& sceneM = SceneManager::GetInstance();
	auto& inputM = InputManager::GetInstance();
	
	if (!calledWin_)
	{
		StopSoundMem(snd_battle_);
		PlaySoundMem(snd_win_, DX_PLAYTYPE_LOOP);
		calledWin_ = true;
	}
}

void GameScene::ChangeState(std::function<void()> func)
{
	updateFuncs_ = func;
	updatingFrame_ = 0;
	calledFight_ = false;
}

IPlayerData& GameScene::GetEnemyData(std::string charNum)
{
	if (charNum == player1_)
	{
		return playerDatas_[1]->GetPlayerData();
	}
	if (charNum == player2_)
	{
		return playerDatas_[0]->GetPlayerData();
	}
}

ICamera2Object* GameScene::GetCameraInterface(void)
{
	return SceneManager::GetInstance().GetCamera();
}

const int GameScene::GetMainScreenHdl(void)
{
	return SceneManager::GetInstance().GetMainScreen();
}

void GameScene::HitStop(int stopFrame)
{
	GetComponent<StopComponent>()->Stop(stopFrame, StopComponent::STOP_TYPE::HITSTOP);
}

void GameScene::PlayerDead()
{
	if (playerDatas_[0]->GetPlayerData().GetLife() >= 1 && playerDatas_[1]->GetPlayerData().GetLife() >= 1)
	{
		ChangeState(std::bind(&GameScene::BreakTimeUpdate, this));
	}
	else
	{
		ChangeState(std::bind(&GameScene::EndUpdate, this));
	}
}

void GameScene::PlayerRevived()
{
	ChangeState(std::bind(&GameScene::RoundCallUpdate, this));
}

void GameScene::LoadComponents(void)
{
	new StopComponent(*this);
}

void GameScene::AdJustPlayerFrontBack(int index)
{
	if (playerDatas_[0]->GetPlayerData().GetAttackingFrame() == 0 && playerDatas_[1]->GetPlayerData().GetAttackingFrame() == 0)
	{
		return;
	}

	//	actor���v���C���[
	if (isFrontPlayer_ == player1_ && playerDatas_[1]->GetPlayerData().GetAttackingFrame() != 0)
	{
		//	�O�ɂ���̂��v���C���[1�ŁA�v���C���[2�͍U����U���Ă�
		if (playerDatas_[0]->GetPlayerData().GetAttackingFrame() != 0 && playerDatas_[0]->GetPlayerData().GetAttackingFrame() <= playerDatas_[1]->GetPlayerData().GetAttackingFrame())
		{
			//	�v���C���[1�̂��U����U���Ă���̎��Ԃ�����
			return;
		}
		else
		{
			if (activeActors_[index].drawPriority == ActorBase::DrawPriority::PLAYER_F)
			{
				//	actor���v���C���[1�ŁA�t�����g�͐�Ό�ɏ��������
				activeActors_[index].drawPriority = ActorBase::DrawPriority::PLAYER_B;
				activeActors_[index - 1].drawPriority = ActorBase::DrawPriority::PLAYER_F;
				isFrontPlayer_ = player2_;
			}
		}
	}
	else if (isFrontPlayer_ == player2_ && playerDatas_[0]->GetPlayerData().GetAttackingFrame() != 0)
	{
		//	�O�ɂ���̂��v���C���[2�ŁA�v���C���[1�͍U����U���Ă�
		if (playerDatas_[1]->GetPlayerData().GetAttackingFrame() != 0 && playerDatas_[1]->GetPlayerData().GetAttackingFrame() < playerDatas_[0]->GetPlayerData().GetAttackingFrame())
		{
			//	�v���C���[1�̂��U����U���Ă���̎��Ԃ�����
			return;
		}
		else
		{
			if (activeActors_[index].drawPriority == ActorBase::DrawPriority::PLAYER_F)
			{
				//	actor���v���C���[2�ŁA�t�����g�͐�Ό�ɏ��������
				activeActors_[index].drawPriority = ActorBase::DrawPriority::PLAYER_B;
				activeActors_[index - 1].drawPriority = ActorBase::DrawPriority::PLAYER_F;
				isFrontPlayer_ = player1_;
			}
		}
	}

}

void GameScene::SortActor(void)
{
	std::sort(activeActors_.begin(), activeActors_.end(),
		[](const ActorInfo& a, const ActorInfo& b) {
			return a.drawPriority < b.drawPriority;
		});
}

void GameScene::ChangeDrawHitBox(void)
{
	if (isDrawHitBox_ == true)
	{
		isDrawHitBox_ = false;
	}
	else
	{
		isDrawHitBox_ = true;
	}
}

void GameScene::DemoUpdate(void)
{
	auto& sceneM = SceneManager::GetInstance();
	auto& inputM = InputManager::GetInstance();

	if (demoTimer_ <= 0 || playerDatas_[0]->GetPlayerData().GetLife() + playerDatas_[1]->GetPlayerData().GetLife() <= 3 || inputM.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::DOWN) || CheckHitKey(KEY_INPUT_SPACE))
	{

		sceneM.ChangeScene(SceneManager::SCENE_ID::TITLE);

	}
	demoTimer_--;
}

IPlayerData& GameScene::PlayerDataWrapper::GetPlayerData(void)
{
	return _playerData;
}

