#include <memory>
#include <string>
#include <DxLib.h>
#include "../Application.h"
#include "../Utility/Utility.h"
#include "../Manager/SceneManager.h"
#include "../Manager/ResourceManager.h"
#include "../Manager/InputManager.h"
#include "../Manager/Camera.h"
#include "../Object/SkyDome.h"
#include "TitleScene.h"

TitleScene::TitleScene(void)
{
}

TitleScene::~TitleScene(void)
{
}

void TitleScene::Init(void)
{
	//	�J�������[�h�ύX
	auto& sceneM = SceneManager::GetInstance();
	sceneM.GetCamera()->ChangeMode(Camera::MODE::FIXED_POINT);

	//	����A�N�V�����ǉ�
	auto& inputM = InputManager::GetInstance();
	////	�V�[���J�ڑ���
	//inputM.AddInputFunction(*this, InputManager::TYPE_DEVICE::KEYBOARD, KEY_INPUT_SPACE,
	//	[&] {sceneM.ChangeScene(SceneManager::SCENE_ID::GAME); }, InputManager::INPUT_TYPE::TRIGGER);

	//	�A�N�^�[�ǉ�
	AddActor(std::make_unique<SkyDome>());

	for (auto& actor : activeActors_)
	{
		actor.actor->Init();
	}

	oldPadStickY_ = 0.0f;

	imgTitleHdl_ = resMng_.Load(ResourceManager::SRC::IMG_TITLE).handleId_;
	imgPushHdl_ = resMng_.Load(ResourceManager::SRC::IMG_PUSHSPACE).handleId_;
	imgEveryone_ = resMng_.Load(ResourceManager::SRC::IMG_EVERYONE).handleId_;
	imgSolo_ = resMng_.Load(ResourceManager::SRC::IMG_SOLO).handleId_;

	cnt_ = 0;

	inScene_ = InScene::PUSHKEY;

	oldPadStickY_ = 0.0f;

	abandonedTimer_ = 1800;

	plnum_ = SceneManager::PLNUM::SOLO;

	InitUI();
}

void TitleScene::InitUI(void)
{
}

void TitleScene::Update(void)
{
	if (abandonedTimer_ <= 0)
	{
		SceneManager::GetInstance().SetPlayerNum(SceneManager::PLNUM::DEMO);
		SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::GAME);
	}

	//	�V�[���J��
	InputManager& ins = InputManager::GetInstance();

	// �v���C���[�̓��͂����m����
	auto playerCtl = ins.GetJPadInputState(InputManager::JOYPAD_NO::PAD1);

	float stick = playerCtl.AKeyLY * -1 / 10;

	switch (inScene_)
	{
	case TitleScene::InScene::PUSHKEY:
		if (ins.IsTrgDown(KEY_INPUT_SPACE) ||
			ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::DOWN))
		{
			inScene_ = InScene::PLNUMSELECT;
		}
		break;
	case TitleScene::InScene::PLNUMSELECT:
		if (ins.IsTrgDown(KEY_INPUT_SPACE) ||
			ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::DOWN))
		{
			SceneManager::GetInstance().SetPlayerNum(plnum_);
			SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::GAME);
		}
		if (ins.IsTrgDown(KEY_INPUT_DOWN) || ins.IsTrgDown(KEY_INPUT_UP) || (fabsf(stick) >= 0.01 && fabsf(oldPadStickY_) < 0.01))
		{
			switch (plnum_)
			{
			case SceneManager::PLNUM::SOLO:
				plnum_ = SceneManager::PLNUM::EVERYONE;
				break;
			case SceneManager::PLNUM::EVERYONE:
				plnum_ = SceneManager::PLNUM::SOLO;
				break;
			}
		}
		break;
	}

	cnt_++;
	abandonedTimer_--;

	if (ins.IsTrgDown(KEY_INPUT_DOWN) || ins.IsTrgDown(KEY_INPUT_UP) || ins.IsTrgDown(KEY_INPUT_SPACE) || (fabsf(stick) >= 0.01 && fabsf(oldPadStickY_) < 0.01))
	{
		abandonedTimer_ = 1800;
	}

	oldPadStickY_ = stick;

}

void TitleScene::Draw(void)
{
	for (auto& actor : activeActors_)
	{
		actor.actor->Draw();
	}

	DrawRotaGraph(Application::SCREEN_SIZE_X / 2, 300, 1.0, 0.0, imgTitleHdl_, true);

	switch (inScene_)
	{
	case TitleScene::InScene::PUSHKEY:

		if (cnt_ % 30 < 20)
		{
			DrawRotaGraph(Application::SCREEN_SIZE_X / 2, 700, 1.0, 0.0, imgPushHdl_, true);
		}
		break;
	case TitleScene::InScene::PLNUMSELECT:
		switch (plnum_)
		{
		case SceneManager::PLNUM::SOLO:
			DrawGraph(0, 0, imgSolo_, true);
			break;
		case SceneManager::PLNUM::EVERYONE:
			DrawGraph(0, 0, imgEveryone_, true);
			break;
		default:
			break;
		}
		break;
	}

	//DrawFormatString(0, 0, 0x66bbff, "Title");
}
