#include <DxLib.h>
#include "../Utility/Utility.h"
#include "../Manager/ResourceManager.h"
#include "../Object/Player/CharacterBase.h"
#include "HpUI.h"

HpUI::HpUI(IPlayerData& player,ZBuffer zBuffer) :UIBase(zBuffer), player_(player)
{
	Init();
}

void HpUI::Init(void)
{
	hp_ = 0;
	life_ = 0;

	img_hpScale_L_ = resMng_.Load(ResourceManager::SRC::IMG_HP_SCALE_L).handleId_;
	img_hpScale_R_ = resMng_.Load(ResourceManager::SRC::IMG_HP_SCALE_R).handleId_;

	img_Life_ = resMng_.Load(ResourceManager::SRC::IMG_LIFE).handleId_;

    const Resource& jsonRes = resMng_.Load(ResourceManager::SRC::JSON_UI_HP);
    if (!jsonRes.jsonData_) {
        throw std::runtime_error("jsonData_ �� nullptr �ł��I");
    }

    std::string playerKey = (player_.GetPlayerNum() == Utility::OBJECT_NAME::PLAYER_1) ? "player1" : "player2";

    // `hp_scale_pos_L` or `hp_scale_pos_R` ���擾
    std::string hpKey = (playerKey == "player1") ? "hp_scale_pos_L" : "hp_scale_pos_R";
        hpScalePos_ = {
            (*jsonRes.jsonData_)[playerKey][hpKey].at(0).get<int>(),
            (*jsonRes.jsonData_)[playerKey][hpKey].at(1).get<int>()
        };
        lifePos_ = {
            (*jsonRes.jsonData_)[playerKey]["life_pos"].at(0).get<int>(),
            (*jsonRes.jsonData_)[playerKey]["life_pos"].at(1).get<int>()
        };
        hpOffset_ = (*jsonRes.jsonData_)[playerKey]["hp_offset"].get<int>();
        lifeOffset_ = (*jsonRes.jsonData_)[playerKey]["life_offset"].get<int>();
        hpDivisor_ = (*jsonRes.jsonData_)["hp_divisor"].get<int>();
}

void HpUI::Update() {}

void HpUI::Draw()
{
    hp_ = player_.GetHp();
    life_ = player_.GetLife();
 
    if (player_.GetHp() > 0)
    {
        for (int m = 0; m < hp_ / hpDivisor_; m++) {
            DrawGraph(hpScalePos_.x + m * hpOffset_, hpScalePos_.y,
                (player_.GetPlayerNum() == Utility::OBJECT_NAME::PLAYER_1) ? img_hpScale_L_ : img_hpScale_R_, true);
        }
    }

    for (int n = 0; n < life_; n++) {
        DrawGraph(lifePos_.x + n * lifeOffset_, lifePos_.y, img_Life_, true);
    }
}