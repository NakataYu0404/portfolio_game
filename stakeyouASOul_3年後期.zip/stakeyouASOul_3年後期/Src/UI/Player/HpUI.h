#pragma once
#include <memory>
#include "../Common/Vector2.h"
#include "../UIBase.h"

class HpUI : public UIBase {
public:
    HpUI(IPlayerData& player, ZBuffer zBuffer);

    void Init() override;
    void Update() override;
    void Draw() override;

private:
    IPlayerData& player_;
    int hp_;
    int life_;

    int img_hpScale_L_;
    int img_hpScale_R_;
    int img_Life_;

    Vector2 hpScalePos_;
    Vector2 lifePos_;
    int hpOffset_;
    int lifeOffset_;
    int hpDivisor_;
};