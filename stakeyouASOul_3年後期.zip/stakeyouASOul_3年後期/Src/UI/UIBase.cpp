#include "../Manager/ResourceManager.h"
#include "UIBase.h"

UIBase::UIBase()
    : zBuffer_(ZBuffer::MIDDLE), resMng_(ResourceManager::GetInstance()) {
}

UIBase::UIBase(ZBuffer zBuffer)
    : zBuffer_(zBuffer), resMng_(ResourceManager::GetInstance()) {
}