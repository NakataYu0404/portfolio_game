#include "RandomGenerator.h"

RandomGenerator::RandomGenerator() :gen_(std::random_device{}()) {}

int RandomGenerator::GetRandomNum(int min,int max) 
{
    std::uniform_int_distribution<> distr(min, max);
    return distr(gen_);
}

float RandomGenerator::GetRandomNumf(float min, float max, int precision)
{
    // �����_���� float �𐶐�
    std::uniform_real_distribution<float> distr(min, max);
    float result = distr(gen_);

    // �����_�ȉ��̌����𒲐�
    float factor = std::pow(10.0f, precision);
    result = std::round(result * factor) / factor;

    return result;
}