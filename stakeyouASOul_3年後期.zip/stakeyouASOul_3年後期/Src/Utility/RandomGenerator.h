#pragma once
#include <random>

class RandomGenerator {
public:
    RandomGenerator();

    int GetRandomNum(int min = 0,int max = 0);
    float GetRandomNumf(float min, float max, int precision = 1);

private:
    std::mt19937 gen_;
};

