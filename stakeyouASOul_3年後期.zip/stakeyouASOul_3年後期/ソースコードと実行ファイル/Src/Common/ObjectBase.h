#pragma once
#include <memory>
#include <vector>
#include "../Component/ComponentBase.h"

class IObjectBase
{
public:

	virtual ~IObjectBase() {};

	//	�R���|�[�l���g��ǉ�
	virtual void AddComponent(ComponentBase& component) = 0;
};

class ObjectBase: public IObjectBase
{
public:
	~ObjectBase(void);
	
	//	�R���|�[�l���g���擾
	template<typename T>
	T* GetComponent()
	{
		for (auto& component : components_)
		{
			if (typeid(*component).name() == typeid(T).name())
			{
				return dynamic_cast<T*>(component.get());
			}
		}
		return nullptr;
	}

	template<typename T>
	const T* GetComponent() const
	{
		for (const auto& component : components_) 
		{
			if (typeid(*component).name() == typeid(T).name()) 
			{
				return dynamic_cast<const T*>(component.get());
			}
		}
		return nullptr;
	}
protected:

	std::vector<std::unique_ptr<ComponentBase>>components_;
private:

	//	�R���|�[�l���g��ǉ�
	void AddComponent(ComponentBase& component)override
	{
		components_.emplace_back(&component);
	}

};

