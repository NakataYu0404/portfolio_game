#include "../Common/ObjectBase.h"
#include "ComponentBase.h"

ComponentBase::ComponentBase(IObjectBase& owner):owner_(owner)
{
	owner_.AddComponent(*this);
}

ComponentBase::ComponentBase(IObjectBase& owner, IActorInfo& actorInfo) : ComponentBase(owner)
{
}

ComponentBase::~ComponentBase()
{
}

