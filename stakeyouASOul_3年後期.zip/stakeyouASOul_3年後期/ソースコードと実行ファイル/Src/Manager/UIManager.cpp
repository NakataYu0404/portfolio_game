#include <algorithm>
#include "../UI/UIBase.h"
#include "UIManager.h"

UIManager* UIManager::instance_ = nullptr;

UIManager& UIManager::CreateInstance(void)
{
    if (instance_ == nullptr)
    {
        instance_ = new UIManager();
    }
    return *instance_;
}

UIManager& UIManager::GetInstance(void)
{
    if (instance_ == nullptr)
    {
        UIManager::CreateInstance();
    }
    return *instance_;
}

void UIManager::Destroy(void)
{
    delete instance_;
}

void UIManager::AddUI(std::shared_ptr<UIBase> ui)
{
    UIArray_.emplace_back(ui);
}

void UIManager::Update()
{
    for (auto& ui : UIArray_) 
    {
        ui->Update();
    }
}

void UIManager::Draw() 
{
    // Z�I�[�_�[�Ń\�[�g���ĕ`��
    std::sort(UIArray_.begin(), UIArray_.end(), [](const auto& a, const auto& b) 
        {
        return a->GetZOrder() < b->GetZOrder();
        });

    for (auto& ui : UIArray_)
    {
        ui->Draw();
    }
}

void UIManager::RemoveUI(std::shared_ptr<UIBase> ui)
{
    UIArray_.erase(std::remove(UIArray_.begin(), UIArray_.end(), ui), UIArray_.end());
}

void UIManager::Clear() {
    UIArray_.clear();
}
