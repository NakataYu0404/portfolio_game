#include "../Manager/ResourceManager.h"
#include "../Manager/SceneManager.h"
#include "ActorBase.h"

ActorBase::ActorBase(void)
	: resMng_(ResourceManager::GetInstance()),
	scnMng_(SceneManager::GetInstance())
{

	transform_ = std::make_shared<Transform>();
}

ActorBase::~ActorBase(void)
{
	transform_->Release();
}

const std::weak_ptr<Transform> ActorBase::GetTransform(void) const
{
	return transform_;
}

void ActorBase::SetPos(VECTOR pos)
{
	transform_->pos = pos;
	transform_->Update();
}
