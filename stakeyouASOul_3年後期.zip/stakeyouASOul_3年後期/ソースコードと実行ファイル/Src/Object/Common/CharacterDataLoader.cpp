#include "CharacterDataLoader.h"
#include <fstream>
#include <iostream>
#include <filesystem>

CharacterDataLoader::CharacterDataLoader()
{
}

CharacterDataLoader::~CharacterDataLoader()
{
}

ActorBase::LeftOrRight CharacterDataLoader::ConvertToLeftOrRight(const std::string& dir)
{
    if (dir == "MIDDLE") return ActorBase::LeftOrRight::MIDDLE;
    if (dir == "LEFT") return ActorBase::LeftOrRight::LEFT;
    if (dir == "RIGHT") return ActorBase::LeftOrRight::RIGHT;
    throw std::invalid_argument("Invalid LeftOrRight value: " + dir);
}

ATTACK_STATE CharacterDataLoader::ConvertToAttackState(const std::string& state)
{
    if (state == "BEFORE") return ATTACK_STATE::BEFORE;
    if (state == "PUNISH") return ATTACK_STATE::PUNISH;
    if (state == "ATTACKING") return ATTACK_STATE::ATTACKING;
    throw std::invalid_argument("Invalid ATTACK_STATE value: " + state);
}

Collider::Category CharacterDataLoader::ConvertToCategory(const std::string& category)
{
    if (category == "PAIN") return Collider::Category::PAIN;
    if (category == "PUSH") return Collider::Category::PUSH;
    if (category == "ATTACK") return Collider::Category::ATTACK;
    throw std::invalid_argument("Invalid Collider::Category value: " + category);
}

ATTACK_TYPE CharacterDataLoader::ConvertToAttackType(const std::string& type)
{
    if (type == "NONE") return ATTACK_TYPE::NONE;
    if (type == "LOW") return ATTACK_TYPE::LOW;
    if (type == "MIDDLE") return ATTACK_TYPE::MIDDLE;
    if (type == "HI") return ATTACK_TYPE::HI;
    if (type == "SPECIAL") return ATTACK_TYPE::SPECIAL;
    if (type == "THROW") return ATTACK_TYPE::THROW;
    if (type == "LOW_5") return ATTACK_TYPE::LOW_5;
    if (type == "MIDDLE_5") return ATTACK_TYPE::MIDDLE_5;
    if (type == "HI_5") return ATTACK_TYPE::HI_5;
    if (type == "SPECIAL_5") return ATTACK_TYPE::SPECIAL_5;
    if (type == "LOW_2") return ATTACK_TYPE::LOW_2;
    if (type == "MIDDLE_2") return ATTACK_TYPE::MIDDLE_2;
    if (type == "HI_2") return ATTACK_TYPE::HI_2;
    if (type == "SPECIAL_2") return ATTACK_TYPE::SPECIAL_2;
    if (type == "LOW_J") return ATTACK_TYPE::LOW_J;
    if (type == "MIDDLE_J") return ATTACK_TYPE::MIDDLE_J;
    if (type == "HI_J") return ATTACK_TYPE::HI_J;
    if (type == "SPECIAL_J") return ATTACK_TYPE::SPECIAL_J;
    if (type == "THROW_LAND") return ATTACK_TYPE::THROW_LAND;
    if (type == "THROW_AIR") return ATTACK_TYPE::THROW_AIR;
    if (type == "COMMAND") return ATTACK_TYPE::COMMAND;
    if (type == "ALL") return ATTACK_TYPE::ALL;
    throw std::invalid_argument("Invalid ATTACK_TYPE value: " + type);
}

SKILL_TYPE CharacterDataLoader::ConvertToSkillType(const std::string& type)
{
    if (type == "NORMAL") return SKILL_TYPE::NORMAL;
    if (type == "GENERATE") return SKILL_TYPE::GENERATE;
    throw std::invalid_argument("Invalid SKILL_TYPE value: " + type);

}

COMMAND CharacterDataLoader::ConvertToCommand(const std::string& type)
{
    if (type == "NONE") return COMMAND::NONE;
    if (type == "HADO_236") return COMMAND::HADO_236;
    if (type == "SHORYU_623") return COMMAND::SHORYU_623;
    if (type == "TATSUMAKI_214") return COMMAND::TATSUMAKI_214;
    if (type == "SINKUHADO_236236") return COMMAND::SINKUHADO_236236;
    if (type == "SINKUTATSU_214214") return COMMAND::SINKUTATSU_214214;
    if (type == "YOGA_41236") return COMMAND::YOGA_41236;
    if (type == "KOMANAGE_63214") return COMMAND::KOMANAGE_63214;
    if (type == "RELOAD_22") return COMMAND::RELOAD_22;
    throw std::invalid_argument("Invalid Command value: " + type);
}

GUARD_DIR CharacterDataLoader::ConvertToGuardDir(const std::string& dir)
{
    if (dir == "HI") return GUARD_DIR::HI;
    if (dir == "LOW") return GUARD_DIR::LOW;
    if (dir == "MIDDLE") return GUARD_DIR::MIDDLE;
    throw std::invalid_argument("Invalid GUARD_DIR value: " + dir);
}

HIT_TYPE CharacterDataLoader::ConvertToHitType(const std::string& hitType)
{
    if (hitType == "NORMAL") return HIT_TYPE::NORMAL;
    if (hitType == "DOWN") return HIT_TYPE::DOWN;
    throw std::invalid_argument("Invalid HIT_TYPE value: " + hitType);
}

ANIM_TYPE CharacterDataLoader::ConvertToAnimType(const std::string& animType)
{
    if (animType == "NONE") return ANIM_TYPE::NONE;
    if (animType == "IDLE") return ANIM_TYPE::IDLE;
    if (animType == "WALK") return ANIM_TYPE::WALK;
    if (animType == "RUN") return ANIM_TYPE::RUN;
    if (animType == "JUMP") return ANIM_TYPE::JUMP;
    if (animType == "GUARD_STAND") return ANIM_TYPE::GUARD_STAND;
    if (animType == "GUARD_CROUCH") return ANIM_TYPE::GUARD_CROUCH;
    if (animType == "CROUCH") return ANIM_TYPE::CROUCH;
    if (animType == "DOWN") return ANIM_TYPE::DOWN;
    if (animType == "GETUP") return ANIM_TYPE::GETUP;
    if (animType == "PAIN") return ANIM_TYPE::PAIN;
    if (animType == "ATTACK_5L_L") return ANIM_TYPE::ATTACK_5L_L;
    if (animType == "ATTACK_5L_R") return ANIM_TYPE::ATTACK_5L_R;
    if (animType == "ATTACK_5M") return ANIM_TYPE::ATTACK_5M;
    if (animType == "ATTACK_5H") return ANIM_TYPE::ATTACK_5H;
    if (animType == "ATTACK_5S") return ANIM_TYPE::ATTACK_5S;
    if (animType == "ATTACK_2L_L") return ANIM_TYPE::ATTACK_2L_L;
    if (animType == "ATTACK_2L_R") return ANIM_TYPE::ATTACK_2L_R;
    if (animType == "ATTACK_2M") return ANIM_TYPE::ATTACK_2M;
    if (animType == "ATTACK_2H") return ANIM_TYPE::ATTACK_2H;
    if (animType == "ATTACK_2S") return ANIM_TYPE::ATTACK_2S;
    if (animType == "ATTACK_JL") return ANIM_TYPE::ATTACK_JL;
    if (animType == "ATTACK_JM") return ANIM_TYPE::ATTACK_JM;
    if (animType == "ATTACK_JH") return ANIM_TYPE::ATTACK_JH;
    if (animType == "COMMAND_SHORYU") return ANIM_TYPE::COMMAND_SHORYU;
    if (animType == "COMMAND_HADO") return ANIM_TYPE::COMMAND_HADO;
    throw std::invalid_argument("Invalid CharacterBase::ANIM_TYPE value: " + animType);
}

ATTACK_LEVEL CharacterDataLoader::ConvertToAttackLevel(const std::string& level)
{
    if (level == "ONE1") return ATTACK_LEVEL::ONE1;
    if (level == "TWO2") return ATTACK_LEVEL::TWO2;
    if (level == "THREE3") return ATTACK_LEVEL::THREE3;
    if (level == "FOUR4") return ATTACK_LEVEL::FOUR4;
    if (level == "FIVE5") return ATTACK_LEVEL::FIVE5;
    throw std::invalid_argument("Invalid CharacterBase::ATTACK_LEVEL value: " + level);
}

STATE CharacterDataLoader::ConvertToState(const std::string& state)
{
    if (state == "IDLE") return STATE::IDLE;
    if (state == "MOVE") return STATE::MOVE;
    if (state == "JUMP") return STATE::JUMP;
    if (state == "CROUCH") return STATE::CROUCH;
    if (state == "GUARD") return STATE::GUARD;
    if (state == "ATTACK") return STATE::ATTACK;
    if (state == "PAIN") return STATE::PAIN;
    if (state == "DOWN") return STATE::DOWN;
    if (state == "DEAD") return STATE::DEAD;
    if (state == "GETUP") return STATE::GETUP;
    if (state == "REVIVE") return STATE::REVIVE;

    throw std::invalid_argument("Invalid STATE value: " + state);
}

void CharacterDataLoader::LoadNormalAttackData(const std::string& filePath, std::unordered_map<ATTACK_TYPE, ATTACK_DATA>& attackNormal_) 
{
    std::ifstream file(filePath);
    if (!file.is_open()) {
        printf("Failed to open %s\n", filePath.c_str());
        return;
    }

    nlohmann::json jsonData;
    file >> jsonData;

    std::filesystem::path baseDir = std::filesystem::path(filePath).parent_path();

    for (const auto& [key, value] : jsonData.items()) {
       
        if (!value.is_object()) {
            continue; // ������ȂǁA�I�u�W�F�N�g����Ȃ��v�f�͖���
        }
        
        ATTACK_DATA data;
        data.damage = value["damage"].get<int>();

        // canCancel �̓ǂݍ���
        for (const auto& cancelType : value["canCancel"]) {
            data.canCancel.emplace_back(ConvertToAttackType(cancelType.get<std::string>()));
        }

        data.startHitFrame = value["startHitFrame"].get<int>();
        data.activeHitFrame = value["activeHitFrame"].get<int>();
        data.punishFrame = value["punishFrame"].get<int>();
        data.allFrame = value["allFrame"].get<int>();
        data.blockstunFrame = value["blockstunFrame"].get<int>();
        data.guardDir = ConvertToGuardDir(value["guardDir"].get<std::string>());
        data.hitType = ConvertToHitType(value["hitType"].get<std::string>());
        data.recoveryFrame = value["recoveryFrame"].get<int>();

        // �A�j���[�V�����̓ǂݍ���
        for (const auto& [dir, anim] : value["animationType"].items()) {
            CharacterBase::LeftOrRight dirEnum = ConvertToLeftOrRight(dir);
            data.animationType.emplace(dirEnum, ConvertToAnimType(anim.get<std::string>()));
        }

        // �m�b�N�o�b�N�̓ǂݍ���
        data.knockbackDirHit = {
            value["knockbackDirHit"][0].get<float>(),
            value["knockbackDirHit"][1].get<float>(),
            value["knockbackDirHit"][2].get<float>()
        };

        data.knockbackDirGuard = {
            value["knockbackDirGuard"][0].get<float>(),
            value["knockbackDirGuard"][1].get<float>(),
            value["knockbackDirGuard"][2].get<float>()
        };

        data.level = ConvertToAttackLevel(value["level"].get<std::string>());
        data.cancelTime = value["cancelTime"].get<int>();

        // colMapAtk �̓ǂݍ��݁i�t�@�C�������i�[����Ă���O��j
        std::string colMapFileName = value["colMapAtk"].get<std::string>();
        std::filesystem::path colMapPath = baseDir / "Hitbox" / colMapFileName;
        data.colMapAtk_ = LoadColMap(colMapPath);

        attackNormal_.emplace(ConvertToAttackType(key), data);
    }
}

void CharacterDataLoader::LoadSkillAttackData(const std::string& filePath, std::unordered_map<COMMAND, SKILL_DATA>& attackSkill_) 
{
    std::ifstream file(filePath);
    if (!file.is_open()) 
    {
        printf("Failed to open %s\n", filePath.c_str());
        return;
    }

    nlohmann::json jsonData;
    file >> jsonData;

    std::filesystem::path baseDir = std::filesystem::path(filePath).parent_path();

    for (const auto& [key, value] : jsonData.items()) 
    {
    
        if (!value.is_object()) 
        {
            continue; // ������ȂǁA�I�u�W�F�N�g����Ȃ��v�f�͖���
        }
        
        SKILL_DATA data;
        data.damage = value["damage"].get<int>();

        data.startHitFrame = value["startHitFrame"].get<int>();
        data.activeHitFrame = value["activeHitFrame"].get<int>();
        data.punishFrame = value["punishFrame"].get<int>();
        data.allFrame = value["allFrame"].get<int>();
        data.blockstunFrame = value["blockstunFrame"].get<int>();
        data.guardDir = ConvertToGuardDir(value["guardDir"].get<std::string>());
        data.hitType = ConvertToHitType(value["hitType"].get<std::string>());
        data.recoveryFrame = value["recoveryFrame"].get<int>();
        data.skillType = ConvertToSkillType(value["skillType"].get<std::string>());
        
        // �A�j���[�V�����̓ǂݍ���
        for (const auto& [dir, anim] : value["animationType"].items()) {
            CharacterBase::LeftOrRight dirEnum = ConvertToLeftOrRight(dir);
            data.animationType.emplace(dirEnum, ConvertToAnimType(anim.get<std::string>()));
        }

        // �m�b�N�o�b�N�̓ǂݍ���
        data.knockbackDirHit = {
            value["knockbackDirHit"][0].get<float>(),
            value["knockbackDirHit"][1].get<float>(),
            value["knockbackDirHit"][2].get<float>()
        };

        data.knockbackDirGuard = {
            value["knockbackDirGuard"][0].get<float>(),
            value["knockbackDirGuard"][1].get<float>(),
            value["knockbackDirGuard"][2].get<float>()
        };
        if (value.contains("generatePos")) {
            data.generatePos = {
                value["generatePos"][0].get<float>(),
                value["generatePos"][1].get<float>(),
                value["generatePos"][2].get<float>()
            };
        }
        if (value.contains("scl") && value["scl"].is_array() && value["scl"].size() == 3) {
            data.scl = {
                value["scl"][0].get<float>(),
                value["scl"][1].get<float>(),
                value["scl"][2].get<float>()
            };
        }

        data.level = ConvertToAttackLevel(value["level"].get<std::string>());

        // colMapAtk �̓ǂݍ��݁i�t�@�C�������i�[����Ă���O��j
        std::string colMapFileName = value["colMapAtk"].get<std::string>();
        std::filesystem::path colMapPath = baseDir / "Hitbox" / colMapFileName;
        data.colMapAtk_ = LoadColMap(colMapPath);


        if (value.contains("colMapGenerate"))
        {
            colMapFileName = value["colMapGenerate"].get<std::string>();
            colMapPath = baseDir / "Hitbox" / colMapFileName;
            data.colMapGenerate_ = LoadColMap(colMapPath);
        }


        attackSkill_.emplace(ConvertToCommand(key), data);
    }
}

void CharacterDataLoader::LoadNonAttackData(const std::string& filePath, std::unordered_map<STATE, std::shared_ptr<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>>>& colMapNoAtk_)
{
    std::ifstream file(filePath);
    if (!file.is_open()) {
        printf("Failed to open %s\n", filePath.c_str());
        return;
    }

    nlohmann::json jsonData;
    file >> jsonData;

    for (const auto& stateItem : jsonData.items()) {

        STATE stateEnum = ConvertToState(stateItem.key()); // ��Ԗ���ϊ�

        // �V�����}�b�v���쐬
        auto map = std::make_shared<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>>();

        if (stateItem.value().empty()) {
            printf("Warning: Empty collision data for state %s\n", stateItem.key().c_str());
            continue; // ��̃f�[�^���X�L�b�v
        }

        for (const auto& colItem : stateItem.value()) {
            Collider::Category categoryEnum = ConvertToCategory(colItem["category"].get<std::string>());
            Collider::COLLISION_SQUERE col;

            col.UP_L = { colItem["collision"]["UP_L"][0].get<float>(), colItem["collision"]["UP_L"][1].get<float>(), colItem["collision"]["UP_L"][2].get<float>() };
            col.UP_R = { colItem["collision"]["UP_R"][0].get<float>(), colItem["collision"]["UP_R"][1].get<float>(), colItem["collision"]["UP_R"][2].get<float>() };
            col.DOWN_L = { colItem["collision"]["DOWN_L"][0].get<float>(), colItem["collision"]["DOWN_L"][1].get<float>(), colItem["collision"]["DOWN_L"][2].get<float>() };
            col.DOWN_R = { colItem["collision"]["DOWN_R"][0].get<float>(), colItem["collision"]["DOWN_R"][1].get<float>(), colItem["collision"]["DOWN_R"][2].get<float>() };

            map->emplace(categoryEnum, col);
        }

        colMapNoAtk_.emplace(stateEnum, map);
    }
}

std::unordered_map<ATTACK_STATE, std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>>
CharacterDataLoader::LoadColMap(const std::filesystem::path& path)
{
    std::unordered_map<ATTACK_STATE, std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>> result;

    std::filesystem::path colMapPath = path;
    std::ifstream colFile(colMapPath);
    if (!colFile.is_open()) {
        printf("Failed to open colMap file: %s\n", colMapPath.string().c_str());
        return result;
    }

    nlohmann::json colJson;
    colFile >> colJson;

    for (const auto& [state, colliders] : colJson.items()) {

        if (state == "JSON_TYPE") {
            continue;
        }

        std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE> colMap;
        ATTACK_STATE stateEnum = ConvertToAttackState(state);

        for (const auto& colData : colliders) {
            Collider::COLLISION_SQUERE col;
            col.UP_L = { colData["UP_L"][0], colData["UP_L"][1], colData["UP_L"][2] };
            col.UP_R = { colData["UP_R"][0], colData["UP_R"][1], colData["UP_R"][2] };
            col.DOWN_L = { colData["DOWN_L"][0], colData["DOWN_L"][1], colData["DOWN_L"][2] };
            col.DOWN_R = { colData["DOWN_R"][0], colData["DOWN_R"][1], colData["DOWN_R"][2] };

            Collider::Category categoryEnum = ConvertToCategory(colData["category"]);
            colMap.emplace(categoryEnum, col);
        }

        result.emplace(stateEnum, std::move(colMap));
    }

    return result;
}