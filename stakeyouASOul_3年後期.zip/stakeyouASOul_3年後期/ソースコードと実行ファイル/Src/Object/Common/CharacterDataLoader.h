#pragma once
#include <string>
#include <unordered_map>
#include <memory>
#include <nlohmann/json.hpp>
#include "../Player/Parameter/AttackBaseComponent.h"
#include "../Player/Parameter/AttackDetailComponent.h"
#include "../Player/Parameter/AnimType.h"
#include "../Player/Parameter/StateType.h"
#include "../Player/Parameter/AttackState.h"
#include "../Common/Collider.h"
#include "../Player/CharacterBase.h" 

class CharacterDataLoader {
public:
    CharacterDataLoader();
    ~CharacterDataLoader();

	//	String��Json����ǂݎ�����e�v�f���A�Ή�����`�ɕϊ�����
	static CharacterBase::LeftOrRight ConvertToLeftOrRight(const std::string& dir);
	static ATTACK_STATE ConvertToAttackState(const std::string& state);
	static Collider::Category ConvertToCategory(const std::string& category);
	static ATTACK_TYPE ConvertToAttackType(const std::string& type);
	static SKILL_TYPE ConvertToSkillType(const std::string& type);
	static COMMAND ConvertToCommand(const std::string& type);
	static GUARD_DIR ConvertToGuardDir(const std::string& dir);
	static HIT_TYPE ConvertToHitType(const std::string& hitType);
	static ANIM_TYPE ConvertToAnimType(const std::string& animType);
	static ATTACK_LEVEL ConvertToAttackLevel(const std::string& level);
	static STATE ConvertToState(const std::string& state);

	//	�e�f�[�^�����[�h����
    static void LoadNormalAttackData(const std::string& filePath, std::unordered_map<ATTACK_TYPE, ATTACK_DATA>& attackNormal_);
    static void LoadSkillAttackData(const std::string& filePath, std::unordered_map<COMMAND, SKILL_DATA>& attackSkill_);
    static void LoadNonAttackData(const std::string& filePath, std::unordered_map<STATE, std::shared_ptr<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>>>& colMapNoAtk_);

	//	�R���W�����}�b�v�����[�h����
	static std::unordered_map<ATTACK_STATE, std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>> LoadColMap(const std::filesystem::path& path);
};