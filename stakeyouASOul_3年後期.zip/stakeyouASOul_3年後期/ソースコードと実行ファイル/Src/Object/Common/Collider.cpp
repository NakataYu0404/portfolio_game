#include "Collider.h"

Collider::Collider(std::shared_ptr<std::unordered_multimap<Category, COLLISION_SQUERE>> colMap,TYPE type):colMap_(colMap)
{
	hitInfo_ = {};
	type_ = type;
}

Collider::~Collider(void)
{
}

void Collider::ChangeCollider(std::shared_ptr<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>> colMap)
{
	colMap_ = colMap;
}
