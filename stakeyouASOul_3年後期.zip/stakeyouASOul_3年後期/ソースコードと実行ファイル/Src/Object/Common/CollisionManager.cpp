#include <algorithm>
#include <unordered_map>
#include"../../Utility/Utility.h"
#include"Capsule.h"
#include"Sphere.h"
#include"Collider.h"
#include "CollisionManager.h"

CollisionManager* CollisionManager::instance_ = nullptr;


CollisionManager& CollisionManager::CreateInstance()
{
	if (instance_ == nullptr)
	{
		instance_ = new CollisionManager();
	}
	instance_->Init();

    return *instance_;
}

CollisionManager& CollisionManager::GetInstance(void)
{
	return *instance_;
}

void CollisionManager::Init(void)
{

	std::vector<Collider::Category> tags;

	//	�g�p����^�O��ǉ�����
	tags.clear();
	tags.emplace_back(Collider::Category::ATTACK);
	tags.emplace_back(Collider::Category::PAIN);
	tags.emplace_back(Collider::Category::PUSH);

	//	�����蔻��̂��߂̃^�O�Ǘ�
	categoryMap_.emplace(Collider::Category::PUSH, tags);
	categoryMap_.emplace(Collider::Category::ATTACK, tags);

}

void CollisionManager::Update(void)
{
    // ���[�v�𔲂����Ƃ��ɍ폜����R���C�_�̗v�f�ԍ���ۑ�����
    std::vector<int> deleteAct;
    deleteAct.clear();

    // ���ɁZ�ԖڃA�N�^�[�ƃR���W�����������s���Ă��Ȃ����z��
    std::unordered_multimap<int, int> finishedColUpdate;

    // ���������J�e�S���[�z��
    std::vector<std::function<void()>> colFuncActors;

    // for���ɕύX
    for (int actNum = 0; actNum < actors_.size(); actNum++)
    {
        auto& actor = actors_[actNum].second;  // actor->second��ActorBase*�擾

        // �擾�����R���C�_�[���
        auto& actorCollider = actor->GetTransform().lock()->collider_;

        if (actorCollider->type_ == Collider::TYPE::STAGE)
        {
            continue;
        }

        // ���݂̃A�N�^�[�̃R���C�_�z��
        std::vector<std::pair<Collider::Category, Collider::COLLISION_SQUERE>> actorColmapVector(actorCollider->colMap_->begin(), actorCollider->colMap_->end());

        VECTOR& actPos = actor->GetTransform().lock()->pos;

        Collider::Category hitCategoriesActor = Collider::Category::NONE;

        for (int tarNum = 0; tarNum < actors_.size(); tarNum++)
        {
            auto& target = actors_[tarNum].second;  // target->second��ActorBase*�擾

            Collider::Category hitCategoriesTarget = Collider::Category::NONE;
            bool isHitWithoutPush = false;

            if (actor == target || actors_[actNum].first == actors_[tarNum].first)
            {
                continue;
            }

            // ������������������{actNum, tarNum}�܂���{tarNum, actNum}�̃y�A�����݂��Ȃ�������
            if (std::find_if(finishedColUpdate.begin(), finishedColUpdate.end(),
                [&](const auto& pair) {
                    return (pair.first == actNum && pair.second == tarNum) ||
                        (pair.first == tarNum && pair.second == actNum);
                }) != finishedColUpdate.end())
            {
                continue;
            }

            // target�̃R���C�_�[���
            auto& targetCollider = target->GetTransform().lock()->collider_;
            std::vector<std::pair<Collider::Category, Collider::COLLISION_SQUERE>> targetColmapVector(targetCollider->colMap_->begin(), targetCollider->colMap_->end());

            VECTOR& tarPos = target->GetTransform().lock()->pos;

            // PUSH�R���C�_�p�̓����蔻��
            for (int aIndex = 0; aIndex < actorColmapVector.size(); ++aIndex)
            {
                auto& a = actorColmapVector[aIndex];
                if (a.first != Collider::Category::PUSH)
                {
                    continue;
                }

                for (int tIndex = 0; tIndex < targetColmapVector.size(); ++tIndex)
                {
                    auto& t = targetColmapVector[tIndex];
                    if (t.first != Collider::Category::PUSH)
                    {
                        continue;
                    }

                    // AABB
                    float actorR = a.second.right(actPos.x);
                    float actorL = a.second.left(actPos.x);
                    float targetR = t.second.right(tarPos.x);
                    float targetL = t.second.left(tarPos.x);

                    if (actorR >= targetL && actorL <= targetR &&
                        a.second.top(actPos.y) >= t.second.bottom(tarPos.y) &&
                        a.second.bottom(actPos.y) <= t.second.top(tarPos.y))
                    {
                        if (actPos.x <= tarPos.x)
                        {
                            actor->OnCollision(targetCollider->type_, *target, (targetL - actorR), a.second, t.second);
                            target->OnCollision(actorCollider->type_, *actor, (actorR - targetL), a.second, t.second);
                        }
                        else
                        {
                            actor->OnCollision(targetCollider->type_, *target, (targetR - actorL), a.second, t.second);
                            target->OnCollision(actorCollider->type_, *actor, (actorL - targetR), a.second, t.second);
                        }
                    }
                }
            }

            // STAGE��������APUSH�ȊO����K�v���Ȃ�
            if (targetCollider->type_ == Collider::TYPE::STAGE)
            {
                continue;
            }
            VECTOR hitPos = { 0.0f, 0.0f, 0.0f };

            // PUSH�ȊO�̓����蔻��
            for (int aIndex = 0; aIndex < actorColmapVector.size(); ++aIndex)
            {
                auto& a = actorColmapVector[aIndex];
                if (a.first == Collider::Category::PUSH)
                {
                    continue;
                }

                bool breakAttack = false;

                for (int tIndex = 0; tIndex < targetColmapVector.size(); ++tIndex)
                {
                    auto& t = targetColmapVector[tIndex];
                    if (t.first == Collider::Category::PUSH || (a.first == Collider::Category::PAIN && t.first == Collider::Category::PAIN))
                    {
                        continue;
                    }

                    // AABB
                    if (a.second.right(actPos.x) >= t.second.left(tarPos.x) &&
                        a.second.left(actPos.x) <= t.second.right(tarPos.x) &&
                        a.second.top(actPos.y) >= t.second.bottom(tarPos.y) &&
                        a.second.bottom(actPos.y) <= t.second.top(tarPos.y))
                    {
                        isHitWithoutPush = true;

                        if (a.first == t.first)
                        {
                            switch (a.first)
                            {
                            case Collider::Category::ATTACK:
                                hitCategoriesActor = Collider::Category::BLANCEOUT;
                                hitCategoriesTarget = Collider::Category::BLANCEOUT;
                                breakAttack = true;
                                break;
                            case Collider::Category::THROW:
                                hitCategoriesActor = Collider::Category::THROWBREAK;
                                hitCategoriesTarget = Collider::Category::THROWBREAK;
                                breakAttack = true;
                                break;
                            }
                        }

                        // �Փˈʒu�̌v�Z
                        if (actPos.x <= tarPos.x)
                        {
                            hitPos.x = (a.second.right(actPos.x) + t.second.left(tarPos.x)) / 2.0f;
                        }
                        else
                        {
                            hitPos.x = (a.second.left(actPos.x) + t.second.right(tarPos.x)) / 2.0f;
                        }
                        if (actPos.y <= tarPos.y)
                        {
                            hitPos.y = (a.second.top(actPos.y) + t.second.bottom(tarPos.y)) / 2.0f;
                        }
                        else
                        {
                            hitPos.y = (a.second.bottom(actPos.y) + t.second.top(tarPos.y)) / 2.0f;
                        }

                        if (breakAttack)
                        {
                            break;
                        }
                        if (hitCategoriesActor != Collider::Category::BLANCEOUT && hitCategoriesActor != Collider::Category::THROWBREAK)
                        {
                            hitCategoriesActor = a.first;
                        }
                        if (hitCategoriesTarget != Collider::Category::BLANCEOUT && hitCategoriesTarget != Collider::Category::THROWBREAK)
                        {
                            hitCategoriesTarget = t.first;
                        }

                    }
                }
                if (breakAttack)
                {
                    break;
                }
            }

            if (isHitWithoutPush)
            {

                //  �Փ˂��Ă��z��ɁA�Փˌ㏈���Ăяo�����i�[
                colFuncActors.emplace_back([hitCategoriesActor, targetCollider, hitPos, target, actor]
                    {
                        actor->OnCollision(hitCategoriesActor, targetCollider->type_, hitPos, *target);
                    });

                colFuncActors.emplace_back([hitCategoriesTarget, actorCollider, hitPos, target, actor]
                    {
                        target->OnCollision(hitCategoriesTarget, actorCollider->type_, hitPos, *actor);
                    });

                // �Փ˂�������A�U������폜�z���
                deleteAct.emplace_back(actNum);
                deleteAct.emplace_back(tarNum);
            }

            finishedColUpdate.emplace(actNum, tarNum);
        }
    }

    // �폜����
    for (auto& del : deleteAct)
    {
        actors_[del].second->GetTransform().lock()->collider_->colMap_->erase(Collider::Category::ATTACK);
        actors_[del].second->GetTransform().lock()->collider_->colMap_->erase(Collider::Category::THROW);
    }

    // �Փˌ�̊֐����s
    for (auto& colFunc : colFuncActors)
    {
        colFunc();
    }
}

void CollisionManager::Draw(void)
{
    for (auto& a : actors_)
    {
        // a.first �� string �^ (���O�Ȃ�) �ŁAa.second �� ActorBase* �ł�
        ActorBase* actor = a.second;

        // ���� collider ���Ȃ��ꍇ�̓X�L�b�v
        if (actor->GetTransform().lock()->collider_ == nullptr)
        {
            continue;
        }

        // collider ���擾
        std::shared_ptr<Collider> col = actor->GetTransform().lock()->collider_;

        // colMap_ ���̂��ׂẴJ�e�S���ɂ��ď���
        for (auto it = col->colMap_->begin(); it != col->colMap_->end(); ++it)
        {
            VECTOR actPos = actor->GetTransform().lock()->pos;
            float actorR = it->second.right(actPos.x);
            float actorL = it->second.left(actPos.x);
            float actorU = it->second.top(actPos.y);
            float actorD = it->second.bottom(actPos.y);

            unsigned int color = 0;
            switch (it->first)
            {
            case Collider::Category::ATTACK:
                color = 0xff0000; // ��
                break;
            case Collider::Category::PAIN:
                color = 0xffffff; // ��
                break;
            case Collider::Category::PUSH:
                color = 0x00ff00; // ��
                break;
            case Collider::Category::THROW:
                color = 0x0000ff; // ��
                break;
            }

            // ��
            DrawLine3D({ actorL, actorU, 0.0f }, { actorR, actorU, 0.0f }, color);
            // ��
            DrawLine3D({ actorL, actorD, 0.0f }, { actorR, actorD, 0.0f }, color);
            // ��
            DrawLine3D({ actorL, actorU, 0.0f }, { actorL, actorD, 0.0f }, color);
            // �E
            DrawLine3D({ actorR, actorU, 0.0f }, { actorR, actorD, 0.0f }, color);

        }
    }
}

void CollisionManager::Destroy(void)
{
	delete instance_;
}

void CollisionManager::Add(const std::string& name, ActorBase* actor)
{
    actors_.push_back(std::make_pair(name, actor));
}

void CollisionManager::AddCollider(std::weak_ptr<Collider> collider)
{
	colliders_.push_back(collider);
}

void CollisionManager::ClearCollider(void)
{
	colliders_.clear();
	actors_.clear();
	categoryMap_.clear();
}

