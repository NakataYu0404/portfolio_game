#pragma once
#include "../../Component/ComponentBase.h"
#include "../../Scene/GameScene.h"
#include "../Player/Parameter/AttackBaseComponent.h"
#include "../Player/CharacterBase.h"
#include "../Player/Mobs/SummonedBase.h"

class BeAttackedComponent :public ComponentBase
{
public:
	BeAttackedComponent(IObjectBase& owner, ActorBase& owneract, IPlayerData& ownerdata, IBeAttaked& guard, IInfoProvider2Player& actOwner);

	void BatchUpdate(void) override;

	void Attacked(SummonedBase::SUMMOND_ATTACK_BASE& atkData);
	
	void Attacked(ATTACK_DATA& atkData);
	void Attacked(SKILL_DATA& skillData);

private:

	static constexpr int HITSTOP_FRAME = 5;

	IBeAttaked& guard_;
	CharacterBase::ActorBase& owneract_;
	IPlayerData& ownerData_;
	IInfoProvider2Player& actOwner_;

	VECTOR pushBack_;
};
