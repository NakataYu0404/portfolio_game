#include "../../Object/Common/Transform.h"
#include "../Player/CharacterBase.h"
#include "GravityComponent.h"

GravityComponent::GravityComponent(IObjectBase& owner,IActorInfo& actorInfo) : ComponentBase(owner,actorInfo), actorInfo_(actorInfo)
{
	gravityPow_ = 0.0f;
}

float GravityComponent::GetGravityPow(void)
{
	return gravityPow_;
}

float GravityComponent::GetGravityScl(void)
{
    return SCALE_GRAVITY;
}

void GravityComponent::SetGravityPow(float gravityPow)
{
	gravityPow_ = gravityPow;
}

void GravityComponent::AddGravityPow(float gravityPow)
{
	gravityPow_ += gravityPow;
}

void GravityComponent::BatchUpdate(void)
{
    gravityPow_ -= (DEFAULT_GRAVITY * SCALE_GRAVITY) * CORRECT_GRAVITY;

    actorInfo_.GetTransform().lock()->pos.y += gravityPow_;

    if (actorInfo_.GetTransform().lock()->pos.y < 0.0f)
    {
        actorInfo_.GetTransform().lock()->pos.y = 0.0f;
        gravityPow_ = 0.0f;
    }
}