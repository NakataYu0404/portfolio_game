#include "../Utility/Utility.h"
#include "HPComponent.h"

HPComponent::HPComponent(IObjectBase& owner,int maxHp) :ComponentBase(owner)
{
    life_ = MAX_LIFE;
    maxHp_ = maxHp;
    totalHp_ = maxHp_;
    greenHp_ = totalHp_;
    whiteHp_ = 0;
    isAlive_ = true;
    healTimer_ = 0;
}

const int HPComponent::GetLife(void) const
{
    return life_;
}

const int HPComponent::GetHp(void) const
{
    return greenHp_;
}

void HPComponent::SetHp(int hp)
{
    whiteHp_ = 0;
    greenHp_ = hp;

    if (greenHp_ <= 0)
    {
        isAlive_ = false;
    }
    else
    {
        isAlive_ = true;
    }
}

void HPComponent::Heal(void)
{
    //  �}�W�b�N�i���o�[
    whiteHp_ = 0;
    greenHp_ += AUTO_HEAL_MINIMUM_HP;

    if (greenHp_ >= maxHp_)
    {
        greenHp_ = maxHp_;
        isAlive_ = true;
    }
}

void HPComponent::Draw(void)
{
}

void HPComponent::Damage(int damage,bool whiteBreak)
{
    if (!isAlive_)
    {
        return;
    }

    if (whiteBreak)
    {
        whiteHp_ = 0;
    }

    greenHp_ -= damage;
    whiteHp_ += Utility::ScaleDownTen(damage) * HP_CONVERSION_SCALE;

    if (greenHp_ <= 0)
    {
        isAlive_ = false;
        life_ -= 1;
    }

    healTimer_ = 0;
}

void HPComponent::ChipDamage(int damage)
{ 
    int damage_ = 0;
    
    if (greenHp_ - (Utility::ScaleDownTen(damage) * HP_CONVERSION_SCALE) <= 0)
    {
        damage_ = fabs(greenHp_ - (Utility::ScaleDownTen(damage) * HP_CONVERSION_SCALE));
        greenHp_ = 0;
        if (whiteHp_ - damage_ <= 0)
        {
            whiteHp_ = 0;
        }
        else
        {
            whiteHp_ -= damage_;
        }
    }
    else
    {
        greenHp_ -= (Utility::ScaleDownTen(damage) * HP_CONVERSION_SCALE);
        whiteHp_ += Utility::ScaleDownTen(damage);
    }

    healTimer_ = 0;
}

const bool HPComponent::IsAlive(void) const
{
    return isAlive_;
}

void HPComponent::BatchUpdate(void)
{
    totalHp_ = greenHp_ + whiteHp_;

    if (whiteHp_ >= AUTO_HEAL_MINIMUM_HP && healTimer_ >= AUTO_HEAL_TIMER)
    {
        whiteHp_ -= AUTO_HEAL_MINIMUM_HP;
        greenHp_ += AUTO_HEAL_MINIMUM_HP;
        healTimer_ = 0;
    }
    else if (healTimer_ >= AUTO_HEAL_TIMER)
    {
        greenHp_ += whiteHp_;
        whiteHp_ = 0;
    }

    healTimer_++;
}
