#pragma once
#include "../Player/CharacterBase.h"

class IHp
{
public:
	virtual void Damage(int damage, bool whiteBreak = true) = 0;
	virtual void ChipDamage(int damage) = 0;

	virtual ~IHp() {}
};

class HPComponent : public ComponentBase,public IHp
{
public:

	static constexpr int MAX_LIFE = 2;

	//	�R���X�g
	HPComponent(IObjectBase& owner,int maxHp);

	const int GetLife(void) const;

	const int GetHp(void) const;
	void SetHp(int hp);

	void Heal(void);

	const bool IsAlive(void) const;

	void Draw(void);

private:

	static constexpr int AUTO_HEAL_TIMER = 180;
	static constexpr int AUTO_HEAL_MINIMUM_HP = 100;
	static constexpr int HP_CONVERSION_SCALE = 2;

	void Damage(int damage, bool whiteBreak = true) override;
	void ChipDamage(int damage) override;


	void BatchUpdate(void) override;

	int totalHp_;
	int greenHp_;
	int whiteHp_;
	int maxHp_;
	bool isAlive_;

	int healTimer_;

	int life_;
};

