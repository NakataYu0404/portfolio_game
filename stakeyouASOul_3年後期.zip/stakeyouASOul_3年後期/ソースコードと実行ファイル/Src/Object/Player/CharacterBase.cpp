#include <iostream>
#include <fstream>
#include <algorithm>
#include <nlohmann/json.hpp>
#include "../../Application.h"
#include "../../Utility/Utility.h"
#include "../../Manager/ResourceManager.h"
#include "../../Manager/UIManager.h"
#include "../../Manager/Camera.h"
#include "../../Scene/GameScene.h"
#include "../../Object/Common/AnimationController.h"
#include "../../Object/Common/CollisionManager.h"
#include "../../Object/Common/EffectController.h"
#include "../../Component/ComponentBase.h"
#include "../Components/ColPushComponent.h"
#include "../Components/HPComponent.h"
#include "../Components/BeAttackedComponent.h"
#include "../Common/CharacterDataLoader.h"
#include "Mobs/MobGenerator.h"

#include "CharacterComponents/State/StateBase.h"
#include "CharacterComponents/State/IdleStateComponent.h"
#include "CharacterComponents/State/MoveStateComponent.h"
#include "CharacterComponents/State/JumpStateComponent.h"
#include "CharacterComponents/State/CrouchStateComponent.h"
#include "CharacterComponents/State/GuardStateComponent.h"
#include "CharacterComponents/State/PainStateComponent.h"
#include "CharacterComponents/State/DownStateComponent.h"
#include "CharacterComponents/State/DeadStateComponent.h"
#include "CharacterComponents/State/ReviveStateComponent.h"
#include "CharacterComponents/State/AttackStateComponent.h"

#include "../../UI/UIBase.h"
#include "../../UI/Player/HpUI.h"
#include "../../UI/Player/BackFrameUI.h"
#include "../../UI/Player/LeverDIRHistoryUI.h"

#include "CharacterBase.h"

CharacterBase::CharacterBase(std::string plnum, IInfoProvider2Player& owner, bool isAi)
	: ActorBase(), owner_(owner), attackInputMapping_(), colMng_(CollisionManager::GetInstance()), UIMng_(UIManager::GetInstance()),
	dataLoader_(make_unique<CharacterDataLoader>()), stateInterfacePack_(StateInterfacePack({ *this, *this, *this, *this, *this, *this, *this, *this, *this, *this, *this }))
{
	myPlayerNumber_ = plnum;

	//	�I�[�i�[�Ƀv���C���[�f�[�^�C���^�[�t�F�[�X�^�̎������Z�b�g����
	owner_.SetPlayerData(*this);
	animation_ = std::make_unique<AnimationController>();
	colMng_.Add(myPlayerNumber_, this);

	//	��l�p���[�h���ǂ���
	isAi_ = isAi;
}

CharacterBase::~CharacterBase(void)
{
}

void CharacterBase::InitCommon(void)
{
	//	�L�����N�^�[�`��p�X�N���[�������蓖��(�`�掞�̎�O�A�����̊T�O����������^���ɕK�v)
	CharcterDrawScreenHdl_ = MakeScreen(Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, true);

	//	��{������
	transform_->scl = { 1.0f,1.0f,1.0f };
	transform_->quaRot = Quaternion();
	transform_->quaRotLocal = Quaternion();
	transform_->localPos = { 0.0f,0.0f,0.0f };

	//	1P��,2P�����ꂼ��̃L�����p�x
	side1PRot_ = transform_->quaRot;
	side2PRot_ = transform_->quaRot;
	side1PRot_ = Quaternion::AngleAxis(Utility::Deg2RadF(-89.0f), Utility::AXIS_Y);
	side2PRot_ = Quaternion::AngleAxis(Utility::Deg2RadF(89.0f), Utility::AXIS_Y);

	//	�v���C���[�ʏ�����
	auto& inputM = InputManager::GetInstance();
	if (myPlayerNumber_ == Utility::OBJECT_NAME::PLAYER_1)
	{
		//	��	���X��������čU�����������悤�ɂ��Ă������A���ꂾ��UpdateFunc�̓s���𖳎����Đ��Attack�ɑJ�ڂ�������(Stun���Ƃ��ł��A�^�b�N�֐������s���Ȃ��Ⴂ���Ȃ�)����A
		//	��	�@�܊p�w�񂾐V�Z�p�����ǂ�߂��B
		//	inputM.AddInputFunction(*this, InputManager::TYPE_DEVICE::KEYBOARD, KEY_INPUT_T,
		//	[&] {ProcessAttack(ATTACK_TYPE::LOW); }, InputManager::INPUT_TYPE::PRESS);

		buttonL = KEY_INPUT_T;
		buttonM = KEY_INPUT_G;
		buttonH = KEY_INPUT_H;
		buttonS = KEY_INPUT_Y;
		buttonThrow = KEY_INPUT_R;
		buttonDash = KEY_INPUT_F;

		transform_->pos = { -FIRST_POS_X,0.0f,0.0f };
		transform_->quaRot = side1PRot_;
	}
	else if (myPlayerNumber_ == Utility::OBJECT_NAME::PLAYER_2)
	{
		buttonL = KEY_INPUT_I;
		buttonM = KEY_INPUT_K;
		buttonH = KEY_INPUT_L;
		buttonS = KEY_INPUT_O;
		buttonThrow = KEY_INPUT_U;
		buttonDash = KEY_INPUT_J;

		transform_->pos = { FIRST_POS_X,0.0f,0.0f };
		transform_->quaRot = side2PRot_;
	}

	//	����}�l�[�W���[�ɍU���{�^���ǉ�
	InputManager::GetInstance().Add(buttonL);
	InputManager::GetInstance().Add(buttonM);
	InputManager::GetInstance().Add(buttonH);
	InputManager::GetInstance().Add(buttonS);
	InputManager::GetInstance().Add(buttonThrow);
	InputManager::GetInstance().Add(buttonDash);

	//	�R���|�[�l���g���[�h
	LoadComponents();

	//	�e�X�e�[�g���i�[
	stateMap_ = {
		{ STATE::IDLE, GetComponent<IdleStateComponent>() },
		{ STATE::MOVE, GetComponent<MoveStateComponent>() },
		{ STATE::JUMP, GetComponent<JumpStateComponent>() },
		{ STATE::CROUCH, GetComponent<CrouchStateComponent>() },
		{ STATE::GUARD, GetComponent<GuardStateComponent>() },
		{ STATE::PAIN, GetComponent<PainStateComponent>() },
		{ STATE::DOWN, GetComponent<DownStateComponent>() },
		{ STATE::DEAD, GetComponent<DeadStateComponent>() },
		{ STATE::REVIVE, GetComponent<ReviveStateComponent>() },
		{ STATE::ATTACK, GetComponent<AttackStateComponent>() }
	};

	//	���o�[����
	leverDir_ = InputManager::DIR_FULL::FIVE5;

	//	���o�[�����̗���
	dirHistory_ = std::make_shared<std::vector<DIR_HISTORY>>();
	dirHistory_->reserve(Utility::ROUND_COUNT * Utility::GAME_FRAMERATE);

	state_ = STATE::IDLE;

	updatingFrame_ = 0;

	JumpProcess1st_ = true;

	posSide_ = LeftOrRight::LEFT;
	posSideOldCollider_ = LeftOrRight::LEFT;


	jAtkPunishFrame_ = 0;


	ChangeState(STATE::IDLE);

	snd_AtkL_ = resMng_.Load(ResourceManager::SRC::SE_ATTACK_L).handleId_;
	snd_AtkM_ = resMng_.Load(ResourceManager::SRC::SE_ATTACK_M).handleId_;
	snd_AtkH_ = resMng_.Load(ResourceManager::SRC::SE_ATTACK_H).handleId_;
	snd_AtkS_ = resMng_.Load(ResourceManager::SRC::SE_ATTACK_S).handleId_;
	snd_AtkCommand_ = resMng_.Load(ResourceManager::SRC::SE_ATTACK_COMMAND).handleId_;
	snd_Shot_ = resMng_.Load(ResourceManager::SRC::SE_SHOT_HADO).handleId_;

	UIMng_.AddUI(std::make_shared<HpUI>(*this, UIBase::ZBuffer::MIDDLE));
	UIMng_.AddUI(std::make_shared<BackFrameUI>(UIBase::ZBuffer::BACK));
	UIMng_.AddUI(std::make_shared<LeverDirHistoryUI>(*this, dirHistory_, UIBase::ZBuffer::BACK));

	mobGenerator_ = std::make_unique<MobGenerator>(owner_, myPlayerNumber_);
}

void CharacterBase::DrawCommon(void)
{
}

void CharacterBase::Update(void)
{
	//	���o�[�����m�F
	if (!isAi_)
	{
		CheckLeverDir();
	}
	CheckAttackButton(state_);

	if (isAi_)
	{
		DecideAction();
	}

	moveSpeed_ = 0;

	//	���݂̏�Ԃɉ���������
	updateFuncs_();

	if (!GetComponent<HPComponent>()->IsAlive() && ( state_ != STATE::DEAD && state_ != STATE::REVIVE))
	{
		ChangeState(STATE::DEAD);
	}

	for (auto& c : components_)
	{
		c->BatchUpdate();
	}

	//	�v���C���[���J�����ɍ��킹�ĕ␳����֐�
	//	�v���C���[�̌������J�������v���C���[�x�N�g���ɐ����ɂȂ�悤�␳����(X���W���ǂ��ɂȂ��Ă��A�����p�x�Ɍ�����)
	//	�v���C���[�̈ʒu���J�������痣�ꂷ���Ȃ��悤�ɂ���
	AdjustCharacter2Camera(posSide_);

	transform_->Update();
	animation_->Update();

	effectController_->Update();
}

void CharacterBase::UpdateStop(void)
{
	//	���o�[�����m�F
	CheckLeverDir();
	CheckAttackButton(state_);

	SetAttackUpdateFunc();

	if (!GetComponent<HPComponent>()->IsAlive())
	{
		ChangeState(STATE::DEAD);
	}
}

void CharacterBase::Draw(void)
{
}

void CharacterBase::OnCollision(Collider::TYPE type, ActorBase& act, float overPos, Collider::COLLISION_SQUERE& myHitBox, Collider::COLLISION_SQUERE& otherHitBox)
{
	bool isPushedPlayer = true;
	switch (type)
	{
	case Collider::TYPE::PLAYER:
		isPushedPlayer = act.GetComponent<ColPushComponent>()->Push4Player(*this,overPos);
		break;
	case Collider::TYPE::STAGE:
		GetComponent<ColPushComponent>()->Push4Stage(myHitBox, otherHitBox);
		break;
	}
	
	if (!isPushedPlayer)
	{
		GetComponent<ColPushComponent>()->Push4Player(*this, -overPos);
	}
}

void CharacterBase::OnCollision(Collider::Category myCategory, Collider::TYPE someOneType, VECTOR hitPos, ActorBase& act)
{
	AttackStateComponent* atkComponent = GetComponent<AttackStateComponent>();

	switch (someOneType)
	{
	case Collider::TYPE::PLAYER:
		switch (myCategory)
		{
		case Collider::Category::ATTACK:


			if (atkComponent->GetNowAttackType() == ATTACK_TYPE::NONE) { break; }

			// ����̔�e�R���|�[�l���g�̔�e�֐����Ă�
			if (atkComponent->GetNowAttackType() == ATTACK_TYPE::COMMAND)
			{
				act.GetComponent<BeAttackedComponent>()->Attacked(atkComponent->GetSkill(atkComponent->GetNowAttackCommand()));
				PlaySoundMem(snd_AtkCommand_, DX_PLAYTYPE_BACK);

				effectController_->Play((int)EFFECT_TYPE::HIT, false);
				//	�}�W�b�N�i���o�[
				effectController_->TransUpdate((int)EFFECT_TYPE::HIT, hitPos, { 50.0f,50.0f,50.0f }, Utility::VECTOR_ZERO);

			}
			else
			{
				act.GetComponent<BeAttackedComponent>()->Attacked(atkComponent->GetAttack(atkComponent->GetNowAttackType()));
				PlaySoundMem(snd_AtkL_, DX_PLAYTYPE_BACK);

				effectController_->Play((int)EFFECT_TYPE::HIT, false);
				effectController_->TransUpdate((int)EFFECT_TYPE::HIT, hitPos, { 50.0f,50.0f,50.0f }, Utility::VECTOR_ZERO);

				GetComponent<AttackStateComponent>()->SetCancelTimer(0);
			}

			break;

		case Collider::Category::THROW:
			break;

		case Collider::Category::BLANCEOUT:
			owner_.HitStop(16);
			GetComponent<AttackStateComponent>()->SetCancelTimer(0);
			break;

		case Collider::Category::THROWBREAK:
			break;
		}
		break;

	case Collider::TYPE::MOB:
		break;

	case Collider::TYPE::SHOT:
		break;

	case Collider::TYPE::STAGE:
		break;
	}
}

void CharacterBase::LoadComponents(void)
{
	//	ComponentBase�̃R���X�g���N�^�ŏ����components�ɓ���Ă���邩��A����悤�Ƃ��Ȃ��Ă���
	//	delete���Ȃ��Ă��A���j�[�N�|�C���^�̔z��Ɋi�[����̂ŏ���ɏ�����
	new GravityComponent(*this, *this);
	
	new HPComponent(*this, hp_max_);
	new ColPushComponent(*this, *this, *this);
	new BeAttackedComponent(*this, *this, *this, *this, owner_);

	//	�e�X�e�[�g�̃R���|�[�l���g
	new IdleStateComponent(*this, stateInterfacePack_);
	new MoveStateComponent(*this, stateInterfacePack_);
	new JumpStateComponent(*this, stateInterfacePack_);
	new CrouchStateComponent(*this, stateInterfacePack_);
	new GuardStateComponent(*this, stateInterfacePack_);
	new PainStateComponent(*this, stateInterfacePack_);
	new DownStateComponent(*this, stateInterfacePack_);
	new DeadStateComponent(*this, stateInterfacePack_);
	new ReviveStateComponent(*this, stateInterfacePack_);
	new AttackStateComponent(*this, stateInterfacePack_);

}

void CharacterBase::LoadNonAttackData(const std::string& filepath)
{
	dataLoader_->LoadNonAttackData(filepath, colMapNoAtk_);
}

void CharacterBase::CheckLeverDir(void)
{
	auto& ins = InputManager::GetInstance();

	// �v���C���[�̓��͂����m����

	if (GetPlayerNum() == Utility::OBJECT_NAME::PLAYER_1)
	{
		//	���݃��o�[�̕���
		leverDir_ = ins.GetDir(InputManager::JOYPAD_NO::PAD1,KEY_INPUT_W, KEY_INPUT_S, KEY_INPUT_A, KEY_INPUT_D);
	}
	else
	{
		//	���݃��o�[�̕���
		leverDir_ = ins.GetDir(InputManager::JOYPAD_NO::PAD2, KEY_INPUT_UP, KEY_INPUT_DOWN, KEY_INPUT_LEFT, KEY_INPUT_RIGHT);
	}

	if (dirHistory_->size() == 0 || leverDir_ != dirHistory_->back().dir)
	{
		//	�V�������͂��ꂽ������z��ɒǉ�
		dirHistory_->emplace_back(leverDir_);
	}
	else
	{
		//	���������J�E���g����
		dirHistory_->back().pushingFrame++;
	}
}

void CharacterBase::CheckAttackButton(STATE state)
{
	auto& inputM = InputManager::GetInstance();

	isPushL = inputM.IsNew(buttonL) || inputM.IsPadBtnNew(GetPlayerNum(), InputManager::JOYPAD_BTN::LEFT) || buttonLAI;
	isPushM = inputM.IsNew(buttonM) || inputM.IsPadBtnNew(GetPlayerNum(), InputManager::JOYPAD_BTN::DOWN) || buttonMAI;
	isPushH = inputM.IsNew(buttonH) || inputM.IsPadBtnNew(GetPlayerNum(), InputManager::JOYPAD_BTN::RIGHT) || buttonHAI;
	isPushS = inputM.IsNew(buttonS) || inputM.IsPadBtnNew(GetPlayerNum(), InputManager::JOYPAD_BTN::TOP) || buttonSAI;

	// �R�}���h�Z�̑Ή�����U���^�C�v������
	bool isCommand = false;
	if (CheckCommand() != COMMAND::NONE)
	{
		isCommand = true;
	}

	// �X�e�[�g�ʂ̃{�^���ƑΉ��Z�`�F�b�N
	switch (state)
	{
	case STATE::IDLE:
	case STATE::MOVE:
		attackInputMapping_ = {
			{inputM.IsTrgDown(buttonL) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::LEFT) || buttonLAI, ATTACK_TYPE::LOW_5},
			{inputM.IsTrgDown(buttonM) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::DOWN) || buttonMAI, ATTACK_TYPE::MIDDLE_5},
			{inputM.IsTrgDown(buttonH) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::RIGHT) || buttonHAI, ATTACK_TYPE::HI_5},

			//	�R�}���h���������Ă���S�{�^���̑Ή��Z���R�}���h�ɁA�������ĂȂ�������SPECIAL�ɂ���
			{inputM.IsTrgDown(buttonS) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::TOP) || buttonSAI, isCommand ? ATTACK_TYPE::COMMAND : ATTACK_TYPE::SPECIAL_5},
			{inputM.IsTrgDown(buttonThrow), ATTACK_TYPE::THROW_LAND}
		};
		break;
	case STATE::JUMP:
		attackInputMapping_ = {
			{inputM.IsTrgDown(buttonL) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::LEFT), ATTACK_TYPE::LOW_J},
			{inputM.IsTrgDown(buttonM) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::DOWN), ATTACK_TYPE::MIDDLE_J},
			{inputM.IsTrgDown(buttonH) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::RIGHT), ATTACK_TYPE::HI_J},
			{inputM.IsTrgDown(buttonS) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::TOP), ATTACK_TYPE::HI_J},
			{inputM.IsTrgDown(buttonThrow), ATTACK_TYPE::THROW_AIR}
		};
		break;
	case STATE::CROUCH:
		attackInputMapping_ = {
			{inputM.IsTrgDown(buttonL) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::LEFT), ATTACK_TYPE::LOW_2},
			{inputM.IsTrgDown(buttonM) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::DOWN), ATTACK_TYPE::MIDDLE_2},
			{inputM.IsTrgDown(buttonH) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::RIGHT), ATTACK_TYPE::HI_2},
			{inputM.IsTrgDown(buttonS) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::TOP), isCommand ? ATTACK_TYPE::COMMAND : ATTACK_TYPE::SPECIAL_2},
			{inputM.IsTrgDown(buttonThrow), ATTACK_TYPE::THROW_LAND}
		};
		break;
	case STATE::ATTACK:
		switch (leverDir_)
		{
		case InputManager::DIR_FULL::ONE1:
		case InputManager::DIR_FULL::TWO2:
		case InputManager::DIR_FULL::THREE3:
			attackInputMapping_ = {
				{inputM.IsTrgDown(buttonL) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::LEFT) || buttonLAI, ATTACK_TYPE::LOW_2},
				{inputM.IsTrgDown(buttonM) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::DOWN) || buttonMAI, ATTACK_TYPE::MIDDLE_2},
				{inputM.IsTrgDown(buttonH) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::RIGHT) || buttonHAI, ATTACK_TYPE::HI_2},
				{inputM.IsTrgDown(buttonS) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::TOP) || buttonSAI, isCommand ? ATTACK_TYPE::COMMAND : ATTACK_TYPE::SPECIAL_2},
			};
			break;
		case InputManager::DIR_FULL::FOUR4:
		case InputManager::DIR_FULL::FIVE5:
		case InputManager::DIR_FULL::SIX6:
		case InputManager::DIR_FULL::SEVEN7:
		case InputManager::DIR_FULL::EIGHT8:
		case InputManager::DIR_FULL::NINE9:
			attackInputMapping_ = {
				{inputM.IsTrgDown(buttonL) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::LEFT) || buttonLAI, ATTACK_TYPE::LOW_5},
				{inputM.IsTrgDown(buttonM) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::DOWN) || buttonMAI, ATTACK_TYPE::MIDDLE_5},
				{inputM.IsTrgDown(buttonH) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::RIGHT) || buttonHAI, ATTACK_TYPE::HI_5},
				{inputM.IsTrgDown(buttonS) || inputM.IsPadBtnTrgDown(GetPlayerNum(),InputManager::JOYPAD_BTN::TOP) || buttonSAI, isCommand ? ATTACK_TYPE::COMMAND : ATTACK_TYPE::SPECIAL_5},
			};
			break;
		}
		break;
	
	}
}

void CharacterBase::CheckPosSideCollider(void)
{
	float tmp = 0.0f;
	for (auto& [state, colMap] : colMapNoAtk_) 
	{
		for (auto& [key, value] : *colMap)
		{
			Collider::COLLISION_SQUERE copiedValue = value;  // �R�s�[���쐬
			tmp = copiedValue.DOWN_L.x;
			copiedValue.DOWN_L.x = -copiedValue.DOWN_R.x;
			copiedValue.DOWN_R.x = -tmp;

			tmp = copiedValue.UP_L.x;
			copiedValue.UP_L.x = -copiedValue.UP_R.x;
			copiedValue.UP_R.x = -tmp;

			value = copiedValue;  // �R�s�[��߂�
		}
	}
	for (auto& [atkType, atkData] : GetComponent<AttackStateComponent>()->GetAttacks())
	{
		for (auto& [atkState, colMap] : atkData.colMapAtk_)
		{
			for (auto& c : colMap)
			{
				tmp = c.second.DOWN_L.x;
				c.second.DOWN_L.x = -c.second.DOWN_R.x;
				c.second.DOWN_R.x = -tmp;

				tmp = c.second.UP_L.x;
				c.second.UP_L.x = -c.second.UP_R.x;
				c.second.UP_R.x = -tmp;
			}
		}
	}
	for (auto& [command, atkData] : GetComponent<AttackStateComponent>()->GetSkills())
	{
		for (auto& [atkState, colMap] : atkData.colMapAtk_)
		{
			for (auto& c : colMap)
			{
				tmp = c.second.DOWN_L.x;
				c.second.DOWN_L.x = -c.second.DOWN_R.x;
				c.second.DOWN_R.x = -tmp;

				tmp = c.second.UP_L.x;
				c.second.UP_L.x = -c.second.UP_R.x;
				c.second.UP_R.x = -tmp;
			}
		}
	}

	posSideOldCollider_ = posSide_;
}

void CharacterBase::CheckSidePosition(void)
{
	//	����̍��W���擾
	VECTOR enemyPos = owner_.GetEnemyData(myPlayerNumber_).GetPos();

	//	���݂́ZP�����ɑΉ��������E����
	switch (posSide_)
	{
	case CharacterBase::LeftOrRight::LEFT:
		if (transform_->pos.x > enemyPos.x)
		{
			posSide_ = LeftOrRight::RIGHT;
		}
		break;
	case CharacterBase::LeftOrRight::RIGHT:
		if (transform_->pos.x < enemyPos.x)
		{
			posSide_ = LeftOrRight::LEFT;
		}
		break;
	}

	if (posSideOldCollider_ != posSide_)
	{
		if (state_ != STATE::DOWN && state_ != STATE::DEAD)
		{
			CheckPosSideCollider();
		}
	}
}

void CharacterBase::SetAttackUpdateFunc(void)
{
	ATTACK_TYPE type = ATTACK_TYPE::NONE;

	//	[�{�^����������Ă��邩,�Ή�����U���^�C�v]
	for (const auto& [isPress, attackType] : attackInputMapping_)
	{
		//	�{�^����������Ă邩
		if (isPress)
		{
			//	�U�����Ă�������
			if (IsCanAttack(attackType))
			{
				//	�q�b�g�X�g�b�v�̉���
				owner_.HitStop(0);

				if (attackType == ATTACK_TYPE::COMMAND)
				{
					//	�R�}���h�Z
					GetComponent<AttackStateComponent>()->SetAttack(CheckCommand());
					ChangeState(STATE::ATTACK);
					return;
				}

				//	�ʏ�U��
				GetComponent<AttackStateComponent>()->SetAttack(attackType);
				ChangeState(STATE::ATTACK);
				return;  //	�ǂꂩ�������������_�ŏI��(�U�����x���Ⴂ���̂��D�悳���,L��M��H��S��Throw)
			}
		}
	}
}

const ATTACK_TYPE CharacterBase::GetAttackType() const
{
	return GetComponent<AttackStateComponent>()->GetNowAttackType();
}

void CharacterBase::MobGenerate(VECTOR generatePos, SKILL_DATA& data)
{
	mobGenerator_->Generate(posSide_, generatePos, data);

	PlaySoundMem(snd_Shot_, DX_PLAYTYPE_BACK);
	// Hadoken ���ˎ��ɃG�t�F�N�g���Đ�
	effectController_->Play((int)EFFECT_TYPE::SHOT);

}

InputManager::DIR_FULL CharacterBase::GetLeverDir(void)
{
	return leverDir_;
}

bool CharacterBase::IsDashPressed(void)
{
	return CheckHitKey(buttonDash);
}

void CharacterBase::ChangeAnimation(ANIM_TYPE type, bool isLoop, float startStep, float endStep, bool isStop, bool isForce)
{
	animation_->Play((int)type, isLoop, startStep, endStep, isStop, isForce);
}

void CharacterBase::AnimBlend(ANIM_TYPE blendType, int blendEndFrame, bool isLoop, float startStep, float endStep, bool isStop, bool isForce)
{
	animation_->PlayBlend((int)blendType, blendEndFrame, isLoop, startStep, endStep, isStop, isForce);
}

bool CharacterBase::IsAnimationPlayerdInState(void)
{
	return playedAnimationState_;
}

void CharacterBase::ChangeAnimationPlayerdInState(bool animPlayed)
{
	playedAnimationState_ = animPlayed;
}

bool CharacterBase::IsEndAnimation(void)
{
	return animation_->IsEnd();
}

bool CharacterBase::IsCanAttack(ATTACK_TYPE attack)
{
	AttackStateComponent* atkComponent = GetComponent<AttackStateComponent>();

	//	�U�����܂��o�^����Ă��Ȃ�������A��(�����ŋA��ꍇ�͂܂��U�����L�����e���N���X��InitAttackDatas�ɓo�^���邱��)
	if (!atkComponent->IsRegisterAttack(attack) && attack != ATTACK_TYPE::COMMAND)
	{
		return false;
	}

	if (atkComponent->GetAttack(atkComponent->GetNowAttackType()).canCancel.size() > 0)
	{
		//	�L�����Z���������U�����A���݂̍U���̃L�����Z�����e�U�����X�g�ɓ����Ă��邩�A���邢�͉��ɃL�����Z�����Ă����v���̔���(���Ƃ��Ɖ����U�����Ă��Ȃ������ꍇ�͖�����L�����Z������)
		if (std::find_if(atkComponent->GetAttack(atkComponent->GetNowAttackType()).canCancel.begin(),
			atkComponent->GetAttack(atkComponent->GetNowAttackType()).canCancel.end(),
			[&](ATTACK_TYPE type) { return attack == type; })
			!= atkComponent->GetAttack(atkComponent->GetNowAttackType()).canCancel.end() || 
			atkComponent->GetAttack(atkComponent->GetNowAttackType()).canCancel[0] == ATTACK_TYPE::ALL)
		{
			return true;
		}
	}

	return false;
}

std::vector<InputManager::DIR_FULL> CharacterBase::FlipCommand(const std::vector<InputManager::DIR_FULL>& sequence)
{
	std::vector<InputManager::DIR_FULL> flipped;
	flipped.reserve(sequence.size());

	// ���E�̑Ή��\
	std::unordered_map<InputManager::DIR_FULL, InputManager::DIR_FULL> flipMap = {
		{InputManager::DIR_FULL::ONE1, InputManager::DIR_FULL::THREE3}, {InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::TWO2}, {InputManager::DIR_FULL::THREE3, InputManager::DIR_FULL::ONE1},
		{InputManager::DIR_FULL::FOUR4, InputManager::DIR_FULL::SIX6}, {InputManager::DIR_FULL::FIVE5, InputManager::DIR_FULL::FIVE5}, {InputManager::DIR_FULL::SIX6, InputManager::DIR_FULL::FOUR4}
	};

	// ������ϊ�
	for (InputManager::DIR_FULL dir : sequence)
	{
		flipped.push_back(flipMap[dir]);
	}

	return flipped;
}

COMMAND CharacterBase::CheckCommand(void)
{
	const std::vector<std::pair<COMMAND, std::vector<InputManager::DIR_FULL>>> commands = {
		{COMMAND::SINKUHADO_236236, {InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::THREE3, InputManager::DIR_FULL::SIX6, InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::THREE3, InputManager::DIR_FULL::SIX6}},
		{COMMAND::SINKUTATSU_214214, {InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::ONE1, InputManager::DIR_FULL::FOUR4, InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::ONE1, InputManager::DIR_FULL::FOUR4}},
		{COMMAND::YOGA_41236, {InputManager::DIR_FULL::FOUR4, InputManager::DIR_FULL::ONE1, InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::THREE3, InputManager::DIR_FULL::SIX6}},
		{COMMAND::KOMANAGE_63214, {InputManager::DIR_FULL::SIX6, InputManager::DIR_FULL::THREE3, InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::ONE1, InputManager::DIR_FULL::FOUR4}},
		{COMMAND::SHORYU_623, {InputManager::DIR_FULL::SIX6, InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::THREE3}},

		//	���ۂ͓����Ă��Ȃ��Ă��A����������ɂȂ�R�}���h(�s�̕i�͑��ɂ�����̂����B���ׂ��������ꂮ�炢����������)
		{COMMAND::SHORYU_623, {InputManager::DIR_FULL::SIX6, InputManager::DIR_FULL::THREE3, InputManager::DIR_FULL::SIX6}},
		{COMMAND::SHORYU_623, {InputManager::DIR_FULL::THREE3, InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::THREE3}},
		
		{COMMAND::HADO_236, {InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::THREE3, InputManager::DIR_FULL::SIX6}},
		{COMMAND::TATSUMAKI_214, {InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::ONE1, InputManager::DIR_FULL::FOUR4}},
		{COMMAND::RELOAD_22, {InputManager::DIR_FULL::TWO2, InputManager::DIR_FULL::FIVE5, InputManager::DIR_FULL::TWO2}},
	};

	for (const auto& [command, sequence] : commands)
	{
		const auto& targetSequence = (posSide_ == LeftOrRight::RIGHT) ? FlipCommand(sequence) : sequence;

		if (dirHistory_->size() <= targetSequence.size() || !GetComponent<AttackStateComponent>()->IsRegisterSkill(command))
		{
			continue;
		}

		int totalFrames = 0;
		int sequenceIdx = targetSequence.size() - 1;
		int historyIdx = dirHistory_->size() - 1;

		while (historyIdx >= 0 && sequenceIdx >= 0)
		{
			if (dirHistory_->at(historyIdx).dir == targetSequence[sequenceIdx])
			{
				sequenceIdx--; // ���̃R�}���h������
			}

			totalFrames += dirHistory_->at(historyIdx).pushingFrame;

			if (totalFrames > targetSequence.size() * INPUTBUFFER)
			{
				break; // �������ԃI�[�o�[
			}

			historyIdx--;
		}

		// ���ׂĂ̕������������Ă���΃R�}���h����
		if (sequenceIdx < 0)
		{
			return command;
		}
	}
	return COMMAND::NONE;
}

void CharacterBase::AdjustCharacter2Camera(LeftOrRight LR)
{
	AttackStateComponent* atkComponent = GetComponent<AttackStateComponent>();

	auto cam = owner_.GetCameraInterface();

	if (state_ == STATE::ATTACK)
	{
		if ((atkComponent->GetNowAttackType() != ATTACK_TYPE::LOW_J && atkComponent->GetNowAttackType() != ATTACK_TYPE::MIDDLE_J
			&& atkComponent->GetNowAttackType() != ATTACK_TYPE::HI_J && atkComponent->GetNowAttackType() != ATTACK_TYPE::SPECIAL_J))
		{
			switch (LR)
			{
			case CharacterBase::LeftOrRight::LEFT:
				transform_->quaRot = Quaternion::AngleAxis(Utility::Deg2RadF(-PLAYER_ROT_ATTACKING), Utility::AXIS_Y);
				break;
			case CharacterBase::LeftOrRight::RIGHT:
				transform_->quaRot = Quaternion::AngleAxis(Utility::Deg2RadF(PLAYER_ROT_ATTACKING), Utility::AXIS_Y);
				break;
			}
			return;
		}
	}

	if (state_ == STATE::DOWN || state_ == STATE::DEAD)
	{
		return;
	}

	//	�J�������v���C���[�̃x�N�g��
	VECTOR character2Camera = VSub(transform_->pos, cam->GetPos());
	VECTOR Camera2Player = Utility::VNormalize(character2Camera);

	//	�J�������v���C���[�̃x�N�g���ɐ����ȃx�N�g�������߂�

	VECTOR vertical;
	switch (LR)
	{
	case CharacterBase::LeftOrRight::LEFT:	
		vertical = VCross(Camera2Player, Utility::DIR_U);
		break;
	case CharacterBase::LeftOrRight::RIGHT:
		vertical = VCross(Utility::DIR_U, Camera2Player);
		break;
	}
	//	����ꂽ�x�N�g���𐳋K�����ĒP�ʃx�N�g���ɂ���
	vertical = Utility::VNormalize(vertical);

	//	�v���C���[��X�����A�J���������ɐ����ȕ����ɐݒ�
	transform_->quaRot = transform_->quaRot.LookRotation(vertical);

	//	�J�����̍��E�ǂ���ɋ��邩
	LeftOrRight P2CLR = LeftOrRight::MIDDLE;

	if (transform_->pos.x < cam->GetPos().x)
	{
		P2CLR = LeftOrRight::LEFT;
	}
	else
	{
		P2CLR = LeftOrRight::RIGHT;
	}


	//	�v���C���[�ʒu���J�����̊O�ɏo�����Ȃ�A������������(�J�����[)
	switch (P2CLR)
	{
	case CharacterBase::LeftOrRight::LEFT:
		if (transform_->pos.x - cam->GetPos().x < -CAMERA2PLAYER_DISTANCE_MAX_X)
		{
			transform_->pos.x = cam->GetPos().x - CAMERA2PLAYER_DISTANCE_MAX_X;
		}
		break;

	case CharacterBase::LeftOrRight::RIGHT:
		if (transform_->pos.x - cam->GetPos().x > CAMERA2PLAYER_DISTANCE_MAX_X)
		{
			transform_->pos.x = cam->GetPos().x + CAMERA2PLAYER_DISTANCE_MAX_X;
		}
		break;
	}
}

void CharacterBase::ChangeState(std::function<void()> func)
{
	updateFuncs_ = func;
	updatingFrame_ = 0;
	playedAnimationState_ = false;
}

//	�eSTATE�R���|�[�l���g�́A��STATE�R���|�[�l���g��m��Ȃ�����ASTATE�����Ő؂�ւ�����悤�ɂ���
void CharacterBase::ChangeState(STATE state)
{
	//	���݂��Ȃ��Ȃ�A��
	if (!stateMap_.contains(state)) return;

	if (state != STATE::ATTACK)
	{
		GetComponent<AttackStateComponent>()->SetNoAtkNow();
	}

	stateMap_.find(state)->second->Enter();
	ChangeState(std::bind(&StateBase::ManualUpdate, stateMap_.find(state)->second));

	state_ = state;
}

const int CharacterBase::GetHp(void) const
{
	return GetComponent<HPComponent>()->GetHp();
}

const int CharacterBase::GetLife(void) const
{
	return GetComponent<HPComponent>()->GetLife();
}

const bool CharacterBase::IsAlive(void) const
{
	return GetComponent<HPComponent>()->IsAlive();
}

void CharacterBase::ChangeState4Guard(ATTACK_BASE& atkData)
{
	GetComponent<GuardStateComponent>()->SetAttackData(atkData);
	ChangeState(STATE::GUARD);
}

void CharacterBase::ChangeState4Pain(ATTACK_BASE& atkData)
{
	GetComponent<PainStateComponent>()->SetAttackData(atkData);
	ChangeState(STATE::PAIN);
}

void CharacterBase::ChangeState4Down(void)
{
	ChangeState(STATE::DOWN);
}

void CharacterBase::ChangeCollider4StateNoAttack(ATTACK_STATE atkState)
{
	//	�X�e�[�g�ɉ����������蔻��ɕύX
	auto colIt = colMapNoAtk_.find(state_);
	if (colIt != colMapNoAtk_.end()) {
		transform_->collider_->ChangeCollider(colIt->second);
	}
}

void CharacterBase::ChangeColliderColMap(std::shared_ptr<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>> colMap)
{
	transform_->collider_->ChangeCollider(colMap);
}

void CharacterBase::CountUpUpdateFrame(void)
{
	updatingFrame_++;
}

void CharacterBase::AddPos(VECTOR pos) const
{
	transform_->pos = VAdd(transform_->pos, pos);
}

void CharacterBase::noticeDead(void) const
{
	owner_.PlayerDead();
}

void CharacterBase::noticeRevive(void) const
{
	owner_.PlayerRevived();
}

void CharacterBase::JumpInAttack_A2J(void)
{
	GetComponent<JumpStateComponent>()->JumpAttacking();
}

const int CharacterBase::GetJumpAttackPunishFrame_A2J(void) const
{
	return GetComponent<JumpStateComponent>()->GetJumpAtkPunishFrame();
}

void CharacterBase::LandingInAttack_J2A(void)
{
	GetComponent<AttackStateComponent>()->Landing();
}

void CharacterBase::Heal(void)
{
	GetComponent<HPComponent>()->Heal();
}

void CharacterBase::DecideAction()
{
	auto& playerPos = owner_.GetEnemyData(myPlayerNumber_).GetPos();
	float distance = fabs(transform_->pos.x - playerPos.x);


	if (state_ == STATE::IDLE || state_ == STATE::MOVE)
	{

		if (aiFrame_ % AI_DECIDE_FRAME != 0)
		{
			aiFrame_++;
			return;
		}

		if (distance < AI_DISTANCE_ATTACK)
		{
			AttackDecision();
		}

		int rand = Utility::GetRandomNum(1, AI_DIR_KIND);

		switch (rand)
		{
		case 1:
			leverDir_ = InputManager::DIR_FULL::SIX6;
			break;
		case 2:
			leverDir_ = InputManager::DIR_FULL::FOUR4;
			break;
		case 3:
			leverDir_ = InputManager::DIR_FULL::FIVE5;
			break;
		default:
			leverDir_ = InputManager::DIR_FULL::FIVE5;
			break;
		}

		aiFrame_++;
	}
}

void CharacterBase::AttackDecision()
{
	int attackType = Utility::GetRandomNum(1, AI_ATTACK_KIND);

	switch (attackType)
	{
	case 1:
		buttonLAI = true;
		break;
	case 2:
		buttonMAI = true;
		break;
	case 3:
		buttonHAI = true;
		break;
	case 4:
		buttonSAI = true;
		break;
	}

	CheckAttackButton(state_);
	SetAttackUpdateFunc();
	buttonLAI = false;
	buttonMAI = false;
	buttonHAI = false;
	buttonSAI = false;

}