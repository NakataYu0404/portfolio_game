// IdleState.cpp
#include "../../CharacterBase.h"
#include "StateInterfacePack.h"
#include "CrouchStateComponent.h"

CrouchStateComponent::CrouchStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack)
    :StateBase(owner, StateInterfacePack), inputFunc_(StateInterfacePack.input), animFunc_(StateInterfacePack.animation), attackFunc_(StateInterfacePack.attack), colliderFunc_(StateInterfacePack.collider)
{
}

void CrouchStateComponent::ManualUpdate(void)
{
    commonFunc_.CheckSidePosition();

    auto dir = inputFunc_.GetLeverDir();
    if (dir != InputManager::DIR_FULL::ONE1 && dir != InputManager::DIR_FULL::TWO2 && dir != InputManager::DIR_FULL::THREE3)
    {
        //	���Ⴊ�݂����͂���ĂȂ�������AIdle�ɖ߂�
        commonFunc_.ChangeState(STATE::IDLE);
        return;
    }

    animFunc_.ChangeAnimation(ANIM_TYPE::CROUCH);
    colliderFunc_.ChangeCollider4StateNoAttack();
    attackFunc_.SetAttackUpdateFunc();

}
