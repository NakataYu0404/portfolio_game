#pragma once
#include "StateBase.h"

class IInputInfo;
class IAnimationControl;
class IAttackControl;
class IColliderControl;

class CrouchStateComponent : public StateBase {
public:

    CrouchStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack);

    void ManualUpdate(void) override;


private:

    IInputInfo& inputFunc_;
    IAnimationControl& animFunc_;
    IAttackControl& attackFunc_;
    IColliderControl& colliderFunc_;
};