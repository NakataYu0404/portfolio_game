#include "../../CharacterBase.h"
#include "StateInterfacePack.h"
#include "DeadStateComponent.h"

DeadStateComponent::DeadStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack)
	:StateBase(owner, StateInterfacePack), animFunc_(StateInterfacePack.animation),
	colliderFunc_(StateInterfacePack.collider), timerFunc_(StateInterfacePack.timer),
	noticeFunc_(StateInterfacePack.notice)
{
}

void DeadStateComponent::ManualUpdate(void)
{
	commonFunc_.CheckSidePosition();

	colliderFunc_.ChangeCollider4StateNoAttack();
	animFunc_.ChangeAnimation(ANIM_TYPE::DOWN, false);
	timerFunc_.CountUpUpdateFrame();

	if (!animFunc_.IsEndAnimation())
	{
		return;
	}
		
	noticeFunc_.noticeDead();

	if (commonFunc_.GetPlayerData().GetLife() >= 1)
	{
		//	�N���オ��update��
		commonFunc_.ChangeState(STATE::REVIVE);
	}
}
