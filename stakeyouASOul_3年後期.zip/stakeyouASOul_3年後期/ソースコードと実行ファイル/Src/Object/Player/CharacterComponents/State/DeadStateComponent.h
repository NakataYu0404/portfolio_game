#pragma once
#include "StateBase.h"

class IAnimationControl;
class IColliderControl;
class ITimerControl;
class INoticeOwner;


class DeadStateComponent : public StateBase {
public:

    DeadStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack);

    void ManualUpdate(void) override;

private:


    IAnimationControl& animFunc_;
    IColliderControl& colliderFunc_;
    ITimerControl& timerFunc_;
    INoticeOwner& noticeFunc_;
};