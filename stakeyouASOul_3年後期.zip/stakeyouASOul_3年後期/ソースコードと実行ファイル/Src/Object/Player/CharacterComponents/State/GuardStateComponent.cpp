// IdleState.cpp
#include "../../CharacterBase.h"
#include "StateInterfacePack.h"
#include "../../Parameter/AttackBaseComponent.h"
#include "GuardStateComponent.h"

GuardStateComponent::GuardStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack)
    :StateBase(owner, StateInterfacePack), inputFunc_(StateInterfacePack.input), animFunc_(StateInterfacePack.animation), 
	 colliderFunc_(StateInterfacePack.collider), timerFunc_(StateInterfacePack.timer)
{
}

void GuardStateComponent::ManualUpdate(void)
{
	commonFunc_.CheckSidePosition();

	if (timerFunc_.GetUpdateFrame() > atkData_.blockstunFrame)
	{
		commonFunc_.ChangeState(STATE::IDLE);
		return;
	}

	InputManager::DIR_FULL leverDir = inputFunc_.GetLeverDir();

	if (inputFunc_.GetLeverDir() == InputManager::DIR_FULL::ONE1 || inputFunc_.GetLeverDir() == InputManager::DIR_FULL::THREE3)
	{
		animFunc_.ChangeAnimation(ANIM_TYPE::GUARD_CROUCH, false, 0.0f, -1.0f, false, true);
	}
	else
	{
		animFunc_.ChangeAnimation(ANIM_TYPE::GUARD_STAND, false, 0.0f, -1.0f, false, true);
	}

	colliderFunc_.ChangeCollider4StateNoAttack();

	timerFunc_.CountUpUpdateFrame();
}

void GuardStateComponent::SetAttackData(ATTACK_BASE& data)
{
	atkData_ = data;
}

