// IdleState.cpp
#include "../../CharacterBase.h"
#include "StateInterfacePack.h"
#include "IdleStateComponent.h"

IdleStateComponent::IdleStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack)
    :StateBase(owner, StateInterfacePack), inputFunc_(StateInterfacePack.input), animFunc_(StateInterfacePack.animation), attackFunc_(StateInterfacePack.attack), colliderFunc_(StateInterfacePack.collider)
{
    animFunc_.ChangeAnimation(ANIM_TYPE::IDLE);
}

void IdleStateComponent::ManualUpdate(void)
{
    commonFunc_.CheckSidePosition();

    auto dir = inputFunc_.GetLeverDir();
    if (dir == InputManager::DIR_FULL::FOUR4 || dir == InputManager::DIR_FULL::SIX6 || inputFunc_.IsDashPressed()) {
        commonFunc_.ChangeState(STATE::MOVE);
        return;
    }
    else if (dir == InputManager::DIR_FULL::ONE1 || dir == InputManager::DIR_FULL::TWO2 || dir == InputManager::DIR_FULL::THREE3) {
        commonFunc_.ChangeState(STATE::CROUCH);
        return;
    }
    else if (dir == InputManager::DIR_FULL::SEVEN7 || dir == InputManager::DIR_FULL::EIGHT8 || dir == InputManager::DIR_FULL::NINE9) {
        commonFunc_.ChangeState(STATE::JUMP);
        return;
    }

    animFunc_.ChangeAnimation(ANIM_TYPE::IDLE);
    colliderFunc_.ChangeCollider4StateNoAttack();
    attackFunc_.SetAttackUpdateFunc();
}
