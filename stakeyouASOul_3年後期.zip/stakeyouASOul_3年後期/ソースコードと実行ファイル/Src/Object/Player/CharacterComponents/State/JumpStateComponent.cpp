#include "../../CharacterBase.h"
#include "../../../Components/GravityComponent.h"
#include "StateInterfacePack.h"
#include "JumpStateComponent.h"

JumpStateComponent::JumpStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack)
    : StateBase(owner, StateInterfacePack), inputFunc_(StateInterfacePack.input), animFunc_(StateInterfacePack.animation),
    attackFunc_(StateInterfacePack.attack), colliderFunc_(StateInterfacePack.collider), timerFunc_(StateInterfacePack.timer),
    moveFunc_(StateInterfacePack.movement), stateFunc_(StateInterfacePack.state), jumpAttackFunc_(StateInterfacePack.jumpAttack)
{
}

void JumpStateComponent::Enter(void)
{
    JumpProcess1st_ = true;
    jAtkPunishFrame_ = 0;
}

void JumpStateComponent::ManualUpdate(void)
{
    Jump();
}

void JumpStateComponent::JumpAttacking(void)
{
    auto gravity = moveFunc_.GetGravity();

    float gravityScale = gravity->GetGravityScl();

    // �d�͂ɍ��킹�������x�̒���
    float jumpPower = JUMP_POW_1ST * std::sqrt(gravityScale);

    if (stateFunc_.GetState() == STATE::ATTACK)
    {
        if (gravity->GetGravityPow() == 0.0f)
        {
            //  ���n����
            if ((attackFunc_.GetAttackType() == ATTACK_TYPE::LOW_J || attackFunc_.GetAttackType() == ATTACK_TYPE::MIDDLE_J || attackFunc_.GetAttackType() == ATTACK_TYPE::HI_J || attackFunc_.GetAttackType() == ATTACK_TYPE::SPECIAL_J) && jAtkPunishFrame_ < 3)
            {
                //	�W�����v�p�̌㌄
                jAtkPunishFrame_++;
                animFunc_.AnimBlend(ANIM_TYPE::IDLE, 6, false);
                return;
            }
            commonFunc_.ChangeState(STATE::IDLE);
            jumpAttackFunc_.LandingInAttack_J2A();
            JumpProcess1st_ = true;
            jAtkPunishFrame_ = 0;
            return;
        }

        switch (LorMorR_)
        {
        case CharacterBase::LeftOrRight::LEFT:
            moveFunc_.AddPos({ (JUMP_MOVEPOW_X * gravityScale) * -1.0f,0.0f,0.0f });
            break;
        case CharacterBase::LeftOrRight::RIGHT:
            moveFunc_.AddPos({ (JUMP_MOVEPOW_X * gravityScale),0.0f,0.0f });
            break;
        }
        return;
    }
}

const int JumpStateComponent::GetJumpAtkPunishFrame(void) const
{
    return jAtkPunishFrame_;
}


void JumpStateComponent::Jump(void)
{

    auto gravity = moveFunc_.GetGravity();

    float gravityScale = gravity->GetGravityScl();

    // �d�͂ɍ��킹�������x�̒���
    float jumpPower = JUMP_POW_1ST * std::sqrt(gravityScale);

    if (timerFunc_.GetUpdateFrame() <= 0)
    {
        if (inputFunc_.GetLeverDir() == InputManager::DIR_FULL::ONE1 || inputFunc_.GetLeverDir() == InputManager::DIR_FULL::FOUR4 || inputFunc_.GetLeverDir() == InputManager::DIR_FULL::SEVEN7)
        {
            LorMorR_ = CharacterBase::LeftOrRight::LEFT;
        }
        else if (inputFunc_.GetLeverDir() == InputManager::DIR_FULL::THREE3 || inputFunc_.GetLeverDir() == InputManager::DIR_FULL::SIX6 || inputFunc_.GetLeverDir() == InputManager::DIR_FULL::NINE9)
        {
            LorMorR_ = CharacterBase::LeftOrRight::RIGHT;
        }
        else if (inputFunc_.GetLeverDir() == InputManager::DIR_FULL::TWO2 || inputFunc_.GetLeverDir() == InputManager::DIR_FULL::FIVE5 || inputFunc_.GetLeverDir() == InputManager::DIR_FULL::EIGHT8)
        {
            LorMorR_ = CharacterBase::LeftOrRight::MIDDLE;
        }

        colliderFunc_.ChangeCollider4StateNoAttack();
        timerFunc_.CountUpUpdateFrame();
        return;
    }

    if (JumpProcess1st_)
    {
        gravity->AddGravityPow(jumpPower);
        JumpProcess1st_ = false;
    }
    else if (gravity->GetGravityPow() == 0.0f)
    {
        commonFunc_.ChangeState(STATE::IDLE);
        JumpProcess1st_ = true;
        return;
    }

    switch (LorMorR_)
    {
    case CharacterBase::LeftOrRight::LEFT:
        moveFunc_.AddPos({ (JUMP_MOVEPOW_X * gravityScale) * -1.0f,0.0f,0.0f });
        break;
    case CharacterBase::LeftOrRight::RIGHT:
        moveFunc_.AddPos({ (JUMP_MOVEPOW_X * gravityScale),0.0f,0.0f });
        break;
    }

    animFunc_.ChangeAnimation(ANIM_TYPE::JUMP);

    colliderFunc_.ChangeCollider4StateNoAttack();

    attackFunc_.SetAttackUpdateFunc();

}
