#include "../../CharacterBase.h"
#include "StateInterfacePack.h"
#include "MoveStateComponent.h"

MoveStateComponent::MoveStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack)
    : StateBase(owner, StateInterfacePack), inputFunc_(StateInterfacePack.input), animFunc_(StateInterfacePack.animation),
    attackFunc_(StateInterfacePack.attack), colliderFunc_(StateInterfacePack.collider),moveFunc_(StateInterfacePack.movement)
{
}

void MoveStateComponent::ManualUpdate(void)
{
    commonFunc_.CheckSidePosition();
    auto dir = inputFunc_.GetLeverDir();

    // �W�����v�܂��͂��Ⴊ�݂֑J��
    if (dir == InputManager::DIR_FULL::ONE1 || dir == InputManager::DIR_FULL::TWO2 || dir == InputManager::DIR_FULL::THREE3)
    {
        commonFunc_.ChangeState(STATE::CROUCH);
        return;
    }
    else if (dir == InputManager::DIR_FULL::SEVEN7 || dir == InputManager::DIR_FULL::EIGHT8 || dir == InputManager::DIR_FULL::NINE9)
    {
        commonFunc_.ChangeState(STATE::JUMP);
        return;
    }

    // �_�b�V�����̌�ނ𐧌�
    
    if (!((dir == InputManager::DIR_FULL::SIX6 && !commonFunc_.GetPlayerData().IsPosSideLeft() && inputFunc_.IsDashPressed()) ||
        (dir == InputManager::DIR_FULL::FOUR4 && commonFunc_.GetPlayerData().IsPosSideLeft() && inputFunc_.IsDashPressed())))
    {
        // ���͕����ֈړ�
        if (dir == InputManager::DIR_FULL::FOUR4 || (!commonFunc_.GetPlayerData().IsPosSideLeft() && inputFunc_.IsDashPressed()))
        {
            Walk(ActorBase::LeftOrRight::LEFT);
        }
        else if (dir == InputManager::DIR_FULL::SIX6 || (commonFunc_.GetPlayerData().IsPosSideLeft() && inputFunc_.IsDashPressed()))
        {
            Walk(ActorBase::LeftOrRight::RIGHT);
        }
        else
        {
            commonFunc_.ChangeState(STATE::IDLE);
            return;
        }
    }
    else
    {
        commonFunc_.ChangeState(STATE::IDLE);
        return;
    }

    animFunc_.ChangeAnimation(ANIM_TYPE::WALK);
    colliderFunc_.ChangeCollider4StateNoAttack();
    attackFunc_.SetAttackUpdateFunc();
}

void MoveStateComponent::Walk(ActorBase::LeftOrRight moveXDir)
{
    float moveSpeed = moveFunc_.GetDefaultMoveSpeed();

    bool sideisleft = commonFunc_.GetPlayerData().IsPosSideLeft();

    //	����(�E)�ɋ��āA����(�E)�Ɉړ����悤�Ƃ��Ă�(���ړ�)
    if ((sideisleft && moveXDir == ActorBase::LeftOrRight::LEFT)
        || (!sideisleft && moveXDir == ActorBase::LeftOrRight::RIGHT))
    {
        //	���ړ��͏����ݑ��ɂ���
        moveSpeed *= MOVE_BACK_COEFFICIENT;
    }

    VECTOR pos = commonFunc_.GetPlayerData().GetPos();

    //	�ړ�
    switch (moveXDir)
    {
    case CharacterBase::LeftOrRight::LEFT:
        moveFunc_.SetPos({ pos.x -= moveSpeed,pos.y ,pos.z });
        break;

    case CharacterBase::LeftOrRight::RIGHT:
        moveFunc_.SetPos({ pos.x += moveSpeed,pos.y ,pos.z });
        break;
    }
}
