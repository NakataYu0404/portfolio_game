// IdleState.cpp
#include "../../CharacterBase.h"
#include "StateInterfacePack.h"
#include "../../Parameter/AttackBaseComponent.h"
#include "PainStateComponent.h"

PainStateComponent::PainStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack)
	:StateBase(owner, StateInterfacePack),  animFunc_(StateInterfacePack.animation),
	 colliderFunc_(StateInterfacePack.collider), timerFunc_(StateInterfacePack.timer)
{
}

void PainStateComponent::ManualUpdate(void)
{
	commonFunc_.CheckSidePosition();

	if (!animFunc_.IsAnimationPlayerdInState())
	{
		animFunc_.ChangeAnimation(ANIM_TYPE::PAIN, false, 0.0f, -1.0f, false, true);
		animFunc_.ChangeAnimationPlayerdInState(true);
	}

	if (timerFunc_.GetUpdateFrame() > atkData_.recoveryFrame)
	{
		commonFunc_.ChangeState(STATE::IDLE);
		return;
	}
	
	colliderFunc_.ChangeCollider4StateNoAttack();

	timerFunc_.CountUpUpdateFrame();
}

void PainStateComponent::SetAttackData(ATTACK_BASE& data)
{
	atkData_ = data;
}

