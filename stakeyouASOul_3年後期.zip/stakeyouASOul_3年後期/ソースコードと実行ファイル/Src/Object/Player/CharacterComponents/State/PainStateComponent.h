#pragma once
#include "StateBase.h"

class IAnimationControl;
class IColliderControl;
class ITimerControl;

class ATTACK_BASE;

class PainStateComponent : public StateBase {
public:

    PainStateComponent(IObjectBase& owner, StateInterfacePack& StateInterfacePack);

    void ManualUpdate(void) override;

    void SetAttackData(ATTACK_BASE& data);
private:

    ATTACK_BASE atkData_;

    IAnimationControl& animFunc_;
    IColliderControl& colliderFunc_;
    ITimerControl& timerFunc_;

};