#include <DxLib.h>
#include "../../../Utility/Utility.h"
#include "../../../Manager/ResourceManager.h"
#include "../../../Manager/InputManager.h"
#include "../../../Scene/GameScene.h"
#include "../../../Manager/Camera.h"
#include "../../../Object/Common/AnimationController.h"
#include "../../../Object/Common/EffectController.h"
#include "../../Components/HPComponent.h"
#include "../Mobs/Hadoken.h"
#include "../CharacterComponents/State/AttackStateComponent.h"

#include "Ghostleman.h"


Ghostleman::Ghostleman(std::string plnum, IInfoProvider2Player& owner, bool isAi) : CharacterBase(plnum, owner,isAi)
{
}

Ghostleman::~Ghostleman(void)
{

}

void Ghostleman::Init(void)
{
	InitCommon();

	auto& res = ResourceManager::GetInstance();
	transform_->SetModel(res.LoadModelDuplicate(ResourceManager::SRC::MDL_PL_GHOSTLEMAN));

	InitAttackDatas();
	InitSkillDatas();
	InitCollisionDataNonAttack();

	transform_->MakeCollider(colMapNoAtk_.find(state_)->second,Collider::TYPE::PLAYER);
	transform_->Update();

	InitAnimation();
	InitEffect();
}

void Ghostleman::Draw(void)
{
	DrawCommon();

	SetDrawScreen(CharcterDrawScreenHdl_);
	ClearDrawScreen();
	owner_.GetCameraInterface()->SetBeforeDraw();
	MV1DrawModel(transform_->modelId);

	SetDrawScreen(owner_.GetMainScreenHdl());

	DrawGraph(0, 0, CharcterDrawScreenHdl_, true);
	owner_.GetCameraInterface()->SetBeforeDraw();

	effectController_->Draw();
}

void Ghostleman::SetParam(void)
{
}

void Ghostleman::InitAnimation(void)
{
	animation_->SetModel(transform_->modelId);
	std::string path = "Data/Model/Player/Ghostleman/Animation/";
	animation_->Add((int)ANIM_TYPE::ATTACK_2M,path + "Attack/2M_M.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_5M,path + "Attack/5M_M.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_5H,path + "Attack/5H_M.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_2H,path + "Attack/2H_M.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_2L_L,path + "Attack/2L_L.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_2L_R,path + "Attack/2L_R.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_5L_L,path + "Attack/5L_L.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_5L_R,path + "Attack/5L_R.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_JL,path + "Attack/JUMP_L.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_JM,path + "Attack/JUMP_M.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_JH,path + "Attack/JUMP_H.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_2S,path + "Attack/2S_M.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::ATTACK_5S,path + "Attack/5S_M.mv1",60.0f);

	animation_->Add((int)ANIM_TYPE::COMMAND_SHORYU,path + "Command/shoryu.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::COMMAND_HADO,path + "Command/hado.mv1",60.0f);

	animation_->Add((int)ANIM_TYPE::WALK,path + "MoveProcess/Walk.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::RUN,path + "MoveProcess/Run.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::JUMP,path + "MoveProcess/Floating.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::IDLE,path + "Idle.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::CROUCH,path + "Crouchidle.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::PAIN,path + "painStand.mv1",60.0f);

	animation_->Add((int)ANIM_TYPE::GUARD_STAND,path + "Guard.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::GUARD_CROUCH,path + "Crouchguard.mv1",60.0f);

	animation_->Add((int)ANIM_TYPE::DOWN,path + "down.mv1",60.0f);
	animation_->Add((int)ANIM_TYPE::GETUP,path + "oki.mv1",60.0f);
}

void Ghostleman::InitEffect(void)
{
	effectController_ = std::make_unique<EffectController>();
	EffHitId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_HIT).handleId_;
	effectController_->Add((int)EFFECT_TYPE::HIT, EffHitId_);
}

void Ghostleman::InitAttackDatas(void)
{
	//	�����߂��R���C�_�̑O��X�͓��ꂵ�Ȃ��Ƃ����Ȃ��B��������ƁA�U�����[�V���������ŉ����߂����������Ē���a��

	const std::string jsonPath = "Data/JSON/";
	const std::string attackNPath = jsonPath + "AttackData/ATTACK_NORMAL/";
	const std::string attackNGhostPath = attackNPath + "Ghostleman/";


	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNPath + "NONE.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "2L.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "5L.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "JL.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "2M.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "5M.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "JM.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "2H.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "5H.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "JH.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "2S.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNGhostPath + "5S.json");
	GetComponent<AttackStateComponent>()->LoadNormalAttackData(attackNPath + "COMMAND.json");

}

void Ghostleman::InitSkillDatas(void)
{
	const std::string jsonPath = "Data/JSON/";
	const std::string attackCPath = jsonPath + "AttackData/COMMAND/";
	const std::string attackCGhostPath = attackCPath + "Ghostleman/";

	GetComponent<AttackStateComponent>()->LoadSkillAttackData(attackCGhostPath + "236_HADO.json");
	GetComponent<AttackStateComponent>()->LoadSkillAttackData(attackCGhostPath + "623_SHORYU.json");
}

void Ghostleman::InitCollisionDataNonAttack(void)
{
	const std::string jsonPath = "Data/JSON/";

	LoadNonAttackData(jsonPath + "CharacterData/Ghostleman.json");
}

void Ghostleman::ShotGenerate(VECTOR generatePos,SKILL_DATA& data)
{
	auto newHadoken = std::make_unique<Hadoken>(posSide_, generatePos, myPlayerNumber_,data);
	owner_.AddActor(std::move(newHadoken), ActorBase::DrawPriority::FRONT_B);
	PlaySoundMem(snd_Shot_, DX_PLAYTYPE_BACK);

	// Hadoken ���ˎ��ɃG�t�F�N�g���Đ�
	effectController_->Play((int)EFFECT_TYPE::SHOT);
}