#include <DxLib.h>
#include "../../../Utility/Utility.h"
#include "../../../Manager/ResourceManager.h"
#include "../../../Manager/InputManager.h"
#include "../../../Object/Common/EffectController.h"
#include "../../Components/BeAttackedComponent.h"

#include "Hadoken.h"

Hadoken::Hadoken(LeftOrRight& LR, VECTOR pos, std::string ownerPLNum, SKILL_DATA& data):SummonedBase(LR, pos, ownerPLNum, data)
{
	SetPos(pos);
	Init();

	effectController_->Play((int)EFFECT_TYPE::SHOT, false);
	effectController_->TransUpdate((int)EFFECT_TYPE::SHOT, transform_->pos, data.scl, Utility::VECTOR_ZERO);
}

Hadoken::~Hadoken(void)
{

}

void Hadoken::Init(void)
{
	InitCommon();

	auto& res = ResourceManager::GetInstance();
	transform_->SetModel(res.LoadModelDuplicate(ResourceManager::SRC::MDL_HADO));

	InitAttackData();
	InitEffect();
	transform_->MakeCollider(attackData_.colMap_, Collider::TYPE::SHOT);

	transform_->Update();

	ChangeState(std::bind(&Hadoken::MoveUpdate, this));

	isAlive_ = true;
}

void Hadoken::Draw(void)
{
	if (!isAlive_)
	{
		return;
	}

	effectController_->Draw();
}

void Hadoken::SetParam(void)
{

}


void Hadoken::Revive(LeftOrRight& LR, VECTOR pos)
{
}

void Hadoken::InitAttackData(void)
{
	std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE> ccMap;

	attackData_.damage = data_.damage;
	attackData_.blockstunFrame = data_.blockstunFrame;
	attackData_.guardDir = data_.guardDir;
	attackData_.hitType = data_.hitType;
	attackData_.recoveryFrame = data_.recoveryFrame;
	attackData_.knockbackDirHit = data_.knockbackDirHit;
	attackData_.knockbackDirGuard = data_.knockbackDirGuard;
	attackData_.level = data_.level;

	ccMap = data_.colMapGenerate_.find(ATTACK_STATE::ATTACKING)->second;
	attackData_.colMap_ = std::make_shared<std::unordered_multimap<Collider::Category, Collider::COLLISION_SQUERE>>(ccMap);

}

void Hadoken::InitEffect(void)
{
	effectController_ = std::make_unique<EffectController>();
	EffHadoId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_HADO).handleId_;
	effectController_->Add((int)EFFECT_TYPE::SHOT, EffHadoId_);
}

void Hadoken::MoveUpdate(void)
{
	if (dir_ == LeftOrRight::LEFT)
	{
		transform_->pos.x += MOVE_SPEED;
	}
	else
	{
		transform_->pos.x -= MOVE_SPEED;
	}
	transform_->Update();
	effectController_->TransUpdate((int)EFFECT_TYPE::SHOT, transform_->pos, { 50.0f,50.0f,50.0f }, Utility::VECTOR_ZERO);
}

void Hadoken::DeadUpdate(void)
{
	isAlive_ = false;
}

void Hadoken::OnCollision(Collider::TYPE type, ActorBase& act, float overPos, Collider::COLLISION_SQUERE& myHitBox, Collider::COLLISION_SQUERE& otherHitBox)
{

}

void Hadoken::OnCollision(Collider::Category myCategory, Collider::TYPE someOneType, VECTOR hitPos, ActorBase& act)
{
	switch (someOneType)
	{
	case Collider::TYPE::PLAYER:
		act.GetComponent<BeAttackedComponent>()->Attacked(attackData_);

		break;
	case Collider::TYPE::MOB:

		break;
	case Collider::TYPE::SHOT:

		break;
	case Collider::TYPE::STAGE:

		break;
	}
	ChangeState(std::bind(&Hadoken::DeadUpdate, this));

}
