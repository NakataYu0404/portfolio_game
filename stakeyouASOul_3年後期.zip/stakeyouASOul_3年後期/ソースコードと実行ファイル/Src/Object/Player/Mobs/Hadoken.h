#pragma once
#include <string>
#include "SummonedBase.h"
#include "../CharacterBase.h"
class Hadoken :public SummonedBase
{
public:

	static constexpr float MOVE_SPEED = 10.0f;

	Hadoken(LeftOrRight& LR, VECTOR pos, std::string ownerPLNum, SKILL_DATA& data);
	~Hadoken(void);

	void Init(void)override;
	void Draw(void) override;
	void SetParam(void) override;

	void Revive(LeftOrRight& LR, VECTOR pos);

	void InitAttackData(void) override;
	void InitEffect(void) override;

	void MoveUpdate(void);
	void DeadUpdate(void);

	void OnCollision(Collider::TYPE type, ActorBase& act, float overPos, Collider::COLLISION_SQUERE& myHitBox, Collider::COLLISION_SQUERE& otherHitBox) override;
	void OnCollision(Collider::Category myCategory, Collider::TYPE someOneType, VECTOR hitPos, ActorBase& act) override;

private:
	SUMMOND_ATTACK_BASE attackData_;

	bool isAlive_;
};

