#include <memory>
#include "../../../Scene/GameScene.h"
#include "../Parameter/AttackBaseComponent.h"
#include "../Parameter/AttackDetailComponent.h"
#include "../Parameter/AttackState.h"
#include "../Parameter/AnimType.h"
#include "../Mobs/Hadoken.h"

#include "MobGenerator.h"

MobGenerator::MobGenerator(IInfoProvider2Player& owner, std::string myPlayerNumber) : owner_(owner),myPlayerNumber_(myPlayerNumber)
{
}

MobGenerator::~MobGenerator(void)
{
}

void MobGenerator::Generate(ActorBase::LeftOrRight posSide, VECTOR generatePos, SKILL_DATA& data)
{
	auto newHadoken = std::make_unique<Hadoken>(posSide, generatePos, myPlayerNumber_, data);
	owner_.AddActor(std::move(newHadoken), ActorBase::DrawPriority::FRONT_B);
}
