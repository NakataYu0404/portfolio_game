#pragma once
class ShotManager
{
};

