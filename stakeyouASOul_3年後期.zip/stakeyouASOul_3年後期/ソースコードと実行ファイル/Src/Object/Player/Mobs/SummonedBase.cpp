#include "../../Common/CollisionManager.h"
#include "../../../Object/Common/EffectController.h"
#include "SummonedBase.h"

SummonedBase::SummonedBase(LeftOrRight& LR, VECTOR pos, std::string ownerPLNum, SKILL_DATA& data) : ActorBase(), colMng_(CollisionManager::GetInstance()), dir_(LR),data_(data)
{
	colMng_.Add(ownerPLNum,this);
}

SummonedBase::~SummonedBase(void)
{
}

void SummonedBase::InitCommon(void)
{
	transform_->scl = { 1.0f,1.0f,1.0f };
	transform_->quaRot = Quaternion();
	transform_->quaRotLocal = Quaternion();
	transform_->localPos = { 0.0f,0.0f,0.0f };

	updatingFrame_ = 0;
}

void SummonedBase::Update(void)
{
	updateFuncs_();
	updatingFrame_++;
	transform_->Update();
	effectController_->Update();
}

void SummonedBase::UpdateStop(void)
{
}

void SummonedBase::ChangeState(std::function<void()> func)
{
	updateFuncs_ = func;
	updatingFrame_ = 0;
}

