#pragma once
#include <map>
#include <array>
#include <memory>
#include "Common/Transform.h"
class ResourceManager;
class CollisionManager;

class SceneBase;

class Stage : public ActorBase
{
public:

	//	�R���X�g���N�^
	Stage(int drawPrio = DrawPriority::ANYTHING);

	//	�f�X�g���N�^
	~Stage(void);

	void Init(void) override;
	void Update(void) override;
	void Draw(void) override;

private:
	void SetParam(void) override;

	//std::shared_ptr<Transform> backGround_;

	CollisionManager& colMng_;

};
