#include "../Manager/ResourceManager.h"
#include "../Manager/UIManager.h"
#include "SceneBase.h"

SceneBase::SceneBase(void) : resMng_(ResourceManager::GetInstance()), UIMng_(UIManager::CreateInstance())
{
}

SceneBase::~SceneBase()
{
}

void SceneBase::SetPlayerNum(SceneManager::PLNUM num)
{
	plNum_ = num;
}

