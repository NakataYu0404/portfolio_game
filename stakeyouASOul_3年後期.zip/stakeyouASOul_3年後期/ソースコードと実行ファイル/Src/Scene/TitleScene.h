#pragma once
#include "SceneBase.h"
#include "../Object/Common/Transform.h"
class SceneManager;
class SkyDome;


class TitleScene : public SceneBase
{

public:

	//	�R���X�g���N�^
	TitleScene(void);

	//	�f�X�g���N�^
	~TitleScene(void);

	void Init(void) override;
	void InitUI(void) override;
	void Update(void) override;
	void Draw(void) override;

private:

	enum class InScene
	{
		PUSHKEY,
		PLNUMSELECT,
	};

	SceneManager::PLNUM plnum_;
	InScene inScene_;

	float oldPadStickY_;

	int imgTitleHdl_;
	int imgPushHdl_;

	int imgEveryone_;
	int imgSolo_;

	int cnt_;
	int abandonedTimer_;

};
