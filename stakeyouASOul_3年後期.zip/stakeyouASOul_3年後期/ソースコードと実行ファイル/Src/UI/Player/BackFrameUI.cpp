#include <DxLib.h>
#include "../Utility/Utility.h"
#include "../Manager/ResourceManager.h"
#include "../Object/Player/CharacterBase.h"
#include "BackFrameUI.h"

BackFrameUI::BackFrameUI(ZBuffer zBuffer) :UIBase(zBuffer)
{
	Init();
}

void BackFrameUI::Init(void)
{
	img_hpBarBlack_ = resMng_.Load(ResourceManager::SRC::IMG_HP_BAR).handleId_;

	img_HpBarBlackPos_ = { 0,0 };

}

void BackFrameUI::Update() {}

void BackFrameUI::Draw()
{
	DrawGraph(img_HpBarBlackPos_.x, img_HpBarBlackPos_.y, img_hpBarBlack_, true);
}