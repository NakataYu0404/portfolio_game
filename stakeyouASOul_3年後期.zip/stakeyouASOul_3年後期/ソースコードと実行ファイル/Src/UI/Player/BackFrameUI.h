#pragma once
#include <memory>
#include "../Common/Vector2.h"
#include "../UIBase.h"

class IPlayerData; // �O���錾�iPlayer�N���X���Q�Ƃ���j

class BackFrameUI : public UIBase {
public:

    BackFrameUI(ZBuffer zBuffer);

    void Init(void) override;
    void Update(void) override;
    void Draw(void) override;

private:

    int img_hpBarBlack_;

    Vector2 img_HpBarBlackPos_;
};
