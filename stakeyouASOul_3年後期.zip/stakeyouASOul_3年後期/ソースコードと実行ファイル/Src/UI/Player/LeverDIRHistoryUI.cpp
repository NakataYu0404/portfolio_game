#include <DxLib.h>
#include "../Utility/Utility.h"
#include "../Manager/ResourceManager.h"
#include "../Object/Player/CharacterBase.h"
#include "LeverDirHistoryUI.h"

LeverDirHistoryUI::LeverDirHistoryUI(IPlayerData& player, std::shared_ptr<std::vector<DIR_HISTORY>> history, ZBuffer zBuffer) :UIBase(zBuffer), player_(player),history_(history)
{
	Init();
}

void LeverDirHistoryUI::Init(void)
{
	img_Input_Back_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::IMG_INPUT_BACK).handleId_;
	imgs_Input_Arrow_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::IMG_INPUT_ARROW).handleIds_;
	imgs_Input_Button_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::IMG_INPUT_BUTTON).handleIds_;
	imgs_Input_Num_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::IMG_INPUT_NUM).handleIds_;
}

void LeverDirHistoryUI::Update() {}

void LeverDirHistoryUI::Draw()
{
	int m = 0;
	int historySize = static_cast<int>(history_->size()); // size_t -> int �ɕϊ�
	int startIndex = std::max<int>(0, historySize - MAX_DRAW_HISTORY); // �ő�20�̗�����`��

	int baseX = player_.GetPlayerNum() == Utility::OBJECT_NAME::PLAYER_1 ? PLAYER_LEFT_X : PLAYER_RIGHT_BASE_X;
	int tensX = player_.GetPlayerNum() == Utility::OBJECT_NAME::PLAYER_1 ? PLAYER_LEFT_TENS_X : PLAYER_RIGHT_TENS_X;
	int onesX = player_.GetPlayerNum() == Utility::OBJECT_NAME::PLAYER_1 ? PLAYER_LEFT_ONES_X : PLAYER_RIGHT_ONES_X;

	for (int i = historySize - 1, m = 0; i >= startIndex; i--, m++)
	{
		int drawY = BASE_Y + m * LINE_HEIGHT;

		// �w�i
		DrawGraph(baseX, drawY, img_Input_Back_, true);

		// ���
		DrawGraph(baseX, drawY, imgs_Input_Arrow_.lock()[static_cast<int>(history_->at(i).dir)], true);

		// pushingFrame
		int pushingFrame = history_->at(i).pushingFrame;
		if (pushingFrame > MAX_PUSHING_FRAME) pushingFrame = MAX_PUSHING_FRAME;

		int tens = pushingFrame / 10;
		int ones = pushingFrame % 10;

		DrawGraph(tensX, drawY, imgs_Input_Num_.lock()[tens], true);
		DrawGraph(onesX, drawY, imgs_Input_Num_.lock()[ones], true);
	}
}