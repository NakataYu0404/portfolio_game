#pragma once
#include <memory>
#include "../Common/Vector2.h"
#include "../UIBase.h"

class IPlayerData;
class DIR_HISTORY;

class LeverDirHistoryUI : public UIBase {
public:

    LeverDirHistoryUI(IPlayerData& player, std::shared_ptr<std::vector<DIR_HISTORY>> history, ZBuffer zBuffer);

    void Init(void) override;
    void Update(void) override;
    void Draw(void) override;

private:

	static constexpr int MAX_DRAW_HISTORY = 20;

	static constexpr int MAX_PUSHING_FRAME = 99;
	static constexpr int BASE_Y = 200;
	static constexpr int LINE_HEIGHT = 36;
	static constexpr int PLAYER_LEFT_X = 100;
	static constexpr int PLAYER_LEFT_TENS_X = 150;
	static constexpr int PLAYER_LEFT_ONES_X = 180;

	static constexpr int PLAYER_RIGHT_BASE_X = 1920 - 256 - 100;
	static constexpr int PLAYER_RIGHT_TENS_X = 1920 - 256 - 50;
	static constexpr int PLAYER_RIGHT_ONES_X = 1920 - 256 - 20;

	//	����UI�̔w�i
	int img_Input_Back_;
	//	����UI�̃��o�[����
	std::weak_ptr<int[]> imgs_Input_Arrow_;
	//	����UI�̍U���{�^��
	std::weak_ptr<int[]> imgs_Input_Button_;
	//	����UI�̐���(���������Ă�t���[��)
	std::weak_ptr<int[]> imgs_Input_Num_;
	
	IPlayerData& player_;
    std::shared_ptr<std::vector<DIR_HISTORY>> history_;

};

