#pragma once
#include <memory>

class ResourceManager;

class UIBase {
public:

    enum class ZBuffer
    {
        BACK,
        MIDDLE,
        FRONT,
    };


    UIBase();
    UIBase(ZBuffer zBuffer);
    virtual ~UIBase() = default;

    virtual void Init(void) = 0;
    virtual void Update(void) = 0;
    virtual void Draw(void) = 0;

    ZBuffer GetZOrder(void) const { return zBuffer_; }
    void SetZOrder(ZBuffer& order) { zBuffer_ = order; }

    bool GetVisible(void) const { return isVisible_; }
    void SetVisible(bool visible) { isVisible_ = visible; }

protected:
    ZBuffer zBuffer_ = ZBuffer::MIDDLE; // �`�揇�i���l���������قǐ�ɕ`�悳���j

    bool isVisible_ = true;

    ResourceManager& resMng_;
};