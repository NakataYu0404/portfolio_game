#include <DxLib.h>
#include <EffekseerForDXLib.h>
#include "Manager/InputManager.h"
#include "Manager/ResourceManager.h"
#include "Manager/SceneManager.h"
#include "Manager/UIManager.h"
#include "Object/Common/CollisionManager.h"
#include "Application.h"

Application* Application::instance_ = nullptr;

const std::string Application::PATH_IMAGE = "Data/Image/";
const std::string Application::PATH_MODEL = "Data/Model/";
const std::string Application::PATH_EFFECT = "Data/Effect/";
const std::string Application::PATH_SHADER = "Data/Shader/";
const std::string Application::PATH_BGM = "Data/Sound/BGM/";
const std::string Application::PATH_SE = "Data/Sound/SE/";
const std::string Application::PATH_JSON = "Data/JSON/";

void Application::CreateInstance(void)
{
	if (instance_ == nullptr)
	{
		instance_ = new Application();
	}
	instance_->Init();
}

Application& Application::GetInstance(void)
{
	return *instance_;
}

void Application::Init(void)
{
	SetUseJoypadVibrationFlag(true);

	SetWindowText("�i�Q�[");

	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, INIT_COLORBIT);
	ChangeWindowMode(true);

	SetUseDirect3DVersion(DX_DIRECT3D_11);
	isInitFail_ = false;
	if (DxLib_Init() == -1)
	{
		isInitFail_ = true;
		return;
	}

	InitEffekseer();

	SetUseDirectInputFlag(true);
	InputManager::CreateInstance();

	ResourceManager::CreateInstance();

	SceneManager::CreateInstance();

}

void Application::Run(void)
{
	auto& inputManager = InputManager::GetInstance();
	auto& sceneManager = SceneManager::GetInstance();


	while (ProcessMessage() == 0 && CheckHitKey(KEY_INPUT_ESCAPE) == 0)
	{

		inputManager.Update(false);
		sceneManager.Update();

		sceneManager.Draw();

	}
}

void Application::Destroy(void)
{
	ResourceManager::GetInstance().Destroy();
	SceneManager::GetInstance().Destroy();
	CollisionManager::GetInstance().Destroy();
	InputManager::GetInstance().Destroy();
	UIManager::GetInstance().Destroy();

	Effkseer_End();

	if (DxLib_End() == -1)
	{
		isReleaseFail_ = true;
	}

	delete instance_;
}

bool Application::IsInitFail(void) const
{
	return isInitFail_;
}

bool Application::IsReleaseFail(void) const
{
	return isReleaseFail_;
}

Application::Application(void)
	: isInitFail_(false), isReleaseFail_(false)
{
}

void Application::InitEffekseer(void)
{
	if (Effekseer_Init(EFFECSEER_MAXPARTICLE) == -1)
	{
		DxLib_End();
	}
	SetChangeScreenModeGraphicsSystemResetFlag(FALSE);
	Effekseer_SetGraphicsDeviceLostCallbackFunctions();
}