#include "../Common/ObjectBase.h"
#include "ComponentBase.h"

ComponentBase::ComponentBase(IObjectBase& owner,bool IsInComponents):owner_(owner)
{
	if (IsInComponents)
	{
		owner_.AddComponent(*this);
	}
}

ComponentBase::~ComponentBase()
{
}
