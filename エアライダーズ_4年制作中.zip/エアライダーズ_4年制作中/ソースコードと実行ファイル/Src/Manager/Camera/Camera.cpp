﻿#include <math.h>
#include <DxLib.h>
#include <EffekseerForDXLib.h>
#include "../Application.h"
#include "../Utility/Utility.h"
#include "../Manager/InputManager.h"
#include "../Object/Common/Transform.h"
#include "../Object/Common/CollisionManager.h"
#include "Camera.h"

Camera::Camera(void) : colMng_(CollisionManager::GetInstance())
{
	angles_ = VECTOR();
	cameraUp_ = VECTOR();
	mode_ = CAMERA_MODE::NONE;
	pos_ = DEFAULT_CAMERA_POS;
	targetPos_ = Utility::VECTOR_ZERO;
	followTransform_ = nullptr;
	followPos_ = nullptr;
	p2pDistance_ = nullptr;
}

Camera::~Camera(void)
{
}

void Camera::Init(void)
{
	ChangeMode(CAMERA_MODE::FIXED_POINT);
}

void Camera::Update(void)
{
	SetBeforeDraw(); // 現在のモードに応じたカメラ行列をセット
}

void Camera::SetBeforeDraw(void)
{

	//	クリップ距離を設定する(SetDrawScreenでリセットされる)
	SetCameraNearFar(CAMERA_NEAR, CAMERA_FAR);

	switch (mode_)
	{
	case CAMERA_MODE::FIXED_POINT:
		SetBeforeDrawFixedPoint();
		break;
	case CAMERA_MODE::FOLLOW_ZOOMIN:
		SetBeforeDrawZoomIn();
		break;
	case CAMERA_MODE::FOLLOW_ZOOMOUT:
		SetBeforeDrawZoomOut();
		break;
	case CAMERA_MODE::FOLLOW_DRIVER:
		SetBeforeDrawFollow_Driver();
		break;
	case CAMERA_MODE::FOLLOW_CAR:
		SetBeforeDrawFollow_Car();
		break;
	default:
		break;
	}

	//	カメラの設定(位置と注視点による制御)
	SetCameraPositionAndTargetAndUpVec(
		pos_,
		targetPos_,
		cameraUp_
	);

	//	DXライブラリのカメラとEffekseerのカメラを同期する。
	Effekseer_Sync3DSetting();

}

void Camera::Draw(void)
{
}

void Camera::SetFollow(const Transform* follow)
{
	followTransform_ = follow;

	prevFollowPos_ = followTransform_->pos;
}

void Camera::SetFollow(const VECTOR* pos, const VECTOR* distance)
{
	followPos_ = pos;
	p2pDistance_ = distance;

	prevFollowPos_ = followTransform_->pos;
}

CAMERA_MODE Camera::GetMode(void)
{
	return mode_;
}

void Camera::CarChargeRelease(void)
{
	// キャラの回転から正面方向取得
	VECTOR forward = followTransform_->quaRot.PosAxis(VGet(0, 0, 1));

	// 追従位置よりさらに離れたところにカメラを初期化
	pos_ = VAdd(followTransform_->pos,
		VAdd(followTransform_->quaRot.PosAxis(RELATIVE_F2C_POS_SPRING),
			VScale(forward, -50.0f)));  // マジックナンバー

	velocity_ = VGet(0, 0, 0);  // 速度初期化
}

VECTOR Camera::GetPos(void) const
{
	return pos_;
}

VECTOR Camera::GetAngles(void) const
{
	return angles_;
}

VECTOR Camera::GetTargetPos(void) const
{
	return targetPos_;
}

Quaternion Camera::CalculateCameraRotation(void) const
{
	VECTOR forward = VSub(targetPos_, pos_);
	forward.y = 0.0f; // 水平方向だけ（Y軸回転だけ取得する場合）
	forward = Utility::VNormalize(forward);

	// カメラの向きの角度を取得 (Y軸周り)
	float yaw = atan2f(forward.x, forward.z);

	return Quaternion::AngleAxis(yaw, Utility::AXIS_Y);
}

Quaternion Camera::GetQuaRot(void) const
{
	return rot_;
}

Quaternion Camera::GetQuaRotOutX(void) const
{
	return rotOutX_;
}

VECTOR Camera::GetForward(void) const
{
	return VNorm(VSub(targetPos_, pos_));
}

void Camera::ChangeMode(CAMERA_MODE mode)
{
	if (mode_ == mode)
	{
		return;
	}

	//	カメラの初期設定
	if (!(mode_ == CAMERA_MODE::FOLLOW_ZOOMIN && mode == CAMERA_MODE::FOLLOW_ZOOMOUT))
	{
		SetDefault();
		if (followTransform_ != nullptr)
		{
			pos2followVec_ = Utility::DistanceV(pos_, followTransform_->pos);
			initPos2FollowDis_ = Utility::Distance(pos_, followTransform_->pos);
		}
	}

	//	カメラモードの変更
	mode_ = mode;

	//	変更時の初期化処理
	switch (mode_)
	{
	case CAMERA_MODE::FIXED_POINT:
		break;
	}
}

void Camera::SetDefault(void)
{

	//	カメラの初期設定
	pos_ = DEFAULT_CAMERA_POS;

	//	注視点
	targetPos_ = { 0.0f,150.0f,0.0f };

	//	カメラの上方向
	cameraUp_ = Utility::DIR_U;

	angles_.x = Utility::Deg2RadF(DEFAULT_CAMERA_ANGLE.x);
	angles_.y = DEFAULT_CAMERA_ANGLE.y;
	angles_.z = DEFAULT_CAMERA_ANGLE.z;

	rot_ = Quaternion();

}

void Camera::ProcessRot(void)
{
}

void Camera::SetBeforeDrawFixedPoint(void)
{
	pos_ = DEFAULT_CAMERA_POS;
}

void Camera::SetBeforeDrawZoomIn(void)
{
	targetPos_ = followTransform_->pos;
	if (Utility::Distance(pos_, targetPos_) >= ZOOMIN_DISTANCE_MAX)
	{
		pos_ = VAdd(pos_, Utility::VDiv(pos2followVec_, ZOOM_SPEED));
	}
}

void Camera::SetBeforeDrawZoomOut(void)
{
	targetPos_ = followTransform_->pos;

	if (Utility::Distance(pos_, targetPos_) <= initPos2FollowDis_)
	{
		pos_ = VSub(pos_, Utility::VDiv(pos2followVec_, ZOOM_SPEED));
	}
	else
	{
		ChangeMode(CAMERA_MODE::FIXED_POINT);
	}
}

void Camera::SetBeforeDrawFollow_Driver(void)
{
	float POW_SPRING = 500.0f;
	float DAMPING_COEFF = 2.0f * sqrt(POW_SPRING);
	constexpr float DELTA_TIME = 1.0f / 60.0f;
	constexpr float ROTATION_LERP_RATE = 0.01f;
	const float MOVE_THRESHOLD = 0.001f;
	const float FORWARD_ANGLE_THRESHOLD = 0.8f; // cos(36°)くらいの閾値（調整可）

	VECTOR followPos = followTransform_->pos;
	VECTOR deltaMove = VSub(followPos, prevFollowPos_);
	float moveDistSq = Utility::VSizeSq(deltaMove);

	// カメラ前方向（現回転から）
	VECTOR forward = rot_.PosAxis(VGet(0, 0, 1));

	bool isMoving = moveDistSq > MOVE_THRESHOLD;
	bool isMovingForward = false;

	if (isMoving) {
		// 移動方向を正規化
		VECTOR moveDir = VScale(deltaMove, 1.0f / sqrt(moveDistSq));

		// 内積で移動方向とカメラ前方向の角度を判定
		float dot = VDot(moveDir, forward);
		if (fabs(dot) > FORWARD_ANGLE_THRESHOLD) {
			isMovingForward = true;
		}
	}

	Quaternion followRot = followTransform_->quaRot;

	// 動いていて、かつ「プレイヤーの移動方向がカメラZ方向じゃない」なら回転追従
	if (isMoving && !isMovingForward) {
		rot_ = Quaternion::Slerp(rot_, followRot, ROTATION_LERP_RATE);
	}

	// ローカル軸取得（回転から）
	VECTOR right = rot_.PosAxis(VGet(1, 0, 0));
	VECTOR up = rot_.PosAxis(VGet(0, 1, 0));
	forward = rot_.PosAxis(VGet(0, 0, 1)); // 更新

	// カメラ位置計算（後ろに配置）
	VECTOR relCPos = rot_.PosAxis(RELATIVE_F2C_POS_SPRING);
	VECTOR idealPos = VAdd(followPos, relCPos);

	VECTOR diff = VSub(idealPos, pos_);

	float dx = VDot(diff, right);
	float dy = VDot(diff, up);
	float dz = VDot(diff, forward);

	pos_ = VAdd(pos_, VScale(right, dx));
	pos_ = VAdd(pos_, VScale(up, dy));

	float forceZ = POW_SPRING * dz - DAMPING_COEFF * velocity_.z;
	velocity_.z += forceZ * DELTA_TIME;
	pos_ = VAdd(pos_, VScale(forward, velocity_.z * DELTA_TIME));

	VECTOR relTPos = rot_.PosAxis(RELATIVE_C2T_POS);
	targetPos_ = VAdd(pos_, relTPos);

	cameraUp_ = rot_.PosAxis(VGet(0, 1, 0));

	prevFollowPos_ = followPos;
}

void Camera::SetBeforeDrawFollow_Car(void)
{
	float POW_SPRING = 500.0f;
	float dampening = 2.0f * sqrt(POW_SPRING);
	float delta = 1.0f / 60.0f;

	// 追従対象の位置と回転
	VECTOR followPos = followTransform_->pos;
	Quaternion followRot = followTransform_->quaRot;
	// ローカル軸（キャラクターにとっての右・上・前方向）
	VECTOR right = followRot.PosAxis(VGet(1, 0, 0)); // ローカルX
	VECTOR up = followRot.PosAxis(VGet(0, 1, 0)); // ローカルY
	VECTOR forward = followRot.PosAxis(VGet(0, 0, 1)); // ローカルZ

	// キャラ基準での相対位置
	VECTOR relCPos = followRot.PosAxis(RELATIVE_F2C_POS_SPRING);
	VECTOR idealPos = VAdd(followPos, relCPos);

	// カメラの位置との差分（ワールド空間）
	VECTOR diff = VSub(idealPos, pos_);

	// ローカル軸ベースの差分を取得
	float dx = VDot(diff, right);
	float dy = VDot(diff, up);
	float dz = VDot(diff, forward);

	// X,Y方向は即追従（キャラにとっての横・縦方向）
	pos_ = VAdd(pos_, VScale(right, dx));
	pos_ = VAdd(pos_, VScale(up, dy));

	// Z方向（キャラの前後）だけバネ的に追従
	float forceZ = POW_SPRING * dz - dampening * velocity_.z;
	velocity_.z += forceZ * delta;
	pos_ = VAdd(pos_, VScale(forward, velocity_.z * delta));

	// 注視点と上方向ベクトルを更新
	VECTOR relTPos = followRot.PosAxis(RELATIVE_C2T_POS);
	targetPos_ = VAdd(pos_, relTPos);
	cameraUp_ = followRot.PosAxis(rot_.GetUp());
}

void Camera::SetFollowTarget(Transform* newFollow)
{
	followTransform_ = newFollow;

	// 新しい追従ターゲットの回転
	Quaternion followRot = followTransform_->quaRot;

	// カメラ回転を即ターゲットに合わせる
	rot_ = followRot;

	// カメラ位置もターゲットに合わせる
	VECTOR relCPos = rot_.PosAxis(RELATIVE_F2C_POS_SPRING);
	pos_ = VAdd(followTransform_->pos, relCPos);

	// バネの速度をリセット
	velocity_ = VGet(0, 0, 0);

	// 前回のターゲット位置もリセット
	prevFollowPos_ = followTransform_->pos;
}