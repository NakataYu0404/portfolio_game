#include <DxLib.h>
#include "../Application.h"
#include "Resource.h"
#include "ResourceManager.h"

ResourceManager* ResourceManager::instance_ = nullptr;

void ResourceManager::CreateInstance(void)
{
	if (instance_ == nullptr)
	{
		instance_ = new ResourceManager();
	}
	instance_->Init();
}

ResourceManager& ResourceManager::GetInstance(void)
{
	return *instance_;
}

void ResourceManager::Init(void)
{
	using RES = Resource;
	using RES_T = RES::TYPE;
	static std::string PATH_IMG = Application::PATH_IMAGE;
	static std::string PATH_MDL = Application::PATH_MODEL;
	static std::string PATH_EFF = Application::PATH_EFFECT;
	static std::string PATH_BGM = Application::PATH_BGM;
	static std::string PATH_SE = Application::PATH_SE;
	static std::string PATH_JSON = Application::PATH_JSON;

	Resource* res;
	
	//	�^�C�g���摜
	res = new RES(RES_T::IMG, PATH_IMG + "-1");
	resourcesMap_.emplace(SRC::IMG_NONE, res);
	res = new RES(RES_T::IMG, PATH_MDL + "-1");
	resourcesMap_.emplace(SRC::MDL_NONE, res);
	res = new RES(RES_T::IMG, PATH_EFF + "-1");
	resourcesMap_.emplace(SRC::EFF_NONE, res);

	//	�^�C�g���摜
	res = new RES(RES_T::IMG, PATH_IMG + "Title/Title.png");
	resourcesMap_.emplace(SRC::IMG_TITLE, res);

	res = new RES(RES_T::IMG, PATH_IMG + "Title/PushSpace.png");
	resourcesMap_.emplace(SRC::IMG_PUSHSPACE, res);

	res = new RES(RES_T::IMG, PATH_IMG + "Title/minnnade.png");
	resourcesMap_.emplace(SRC::IMG_EVERYONE, res);

	res = new RES(RES_T::IMG, PATH_IMG + "Title/hitoride.png");
	resourcesMap_.emplace(SRC::IMG_SOLO, res);

	res = new RES(RES_T::IMG, PATH_IMG + "start.png");
	resourcesMap_.emplace(SRC::IMG_START, res);
	
	res = new RES(RES_T::IMG, PATH_IMG + "ready.png");
	resourcesMap_.emplace(SRC::IMG_READY, res);


	// �����摜�i�ԁE�� 0�`9�j
	for (int i = 0; i <= 9; ++i) 
	{
		// ��
		res = new RES(RES_T::IMG, PATH_IMG + "Number/red/" + std::to_string(i) + ".png");
		resourcesMap_.emplace(static_cast<SRC>(static_cast<int>(SRC::IMG_0_R) + i), res);

		// ��
		res = new RES(RES_T::IMG, PATH_IMG + "Number/blue/" + std::to_string(i) + ".png");
		resourcesMap_.emplace(static_cast<SRC>(static_cast<int>(SRC::IMG_0_B) + i), res);
	}

	res = new RES(RES_T::IMG, PATH_IMG + "game/result_jump.png");
	resourcesMap_.emplace(SRC::IMG_RESULT_JUMP, res);

	res = new RES(RES_T::IMG, PATH_IMG + "game/ready_CityTrial.png");
	resourcesMap_.emplace(SRC::IMG_READY_CITY, res);

	res = new RES(RES_T::IMG, PATH_IMG + "game/ready_LJump.png");
	resourcesMap_.emplace(SRC::IMG_READY_LJUMP, res);

	res = new RES(RES_T::IMG, PATH_IMG + "param.png");
	resourcesMap_.emplace(SRC::IMG_RESULT_CITY_BACK, res);

	res = new RES(RES_T::IMG, PATH_IMG + "memori_red.png");
	resourcesMap_.emplace(SRC::IMG_RESULT_CITY_METER_R, res);

	res = new RES(RES_T::IMG, PATH_IMG + "memori_blue.png");
	resourcesMap_.emplace(SRC::IMG_RESULT_CITY_METER_B, res);

	//	�X�J�C�h�[��
	res = new RES(RES_T::MODEL, PATH_MDL + "Stage/SkyDome/SkyDome.mv1");
	resourcesMap_.emplace(SRC::MDL_SKYDOME, res);

	//	�X�e�[�W
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/city_trial.mv1");
	resourcesMap_.emplace(SRC::MDL_STAGE_CITY, res);

	//	�X�e�[�W
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/humikiri.mv1");
	resourcesMap_.emplace(SRC::MDL_STAGE_LONGJUMP, res);

	//	�X�e�[�W
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/land.mv1");
	resourcesMap_.emplace(SRC::MDL_STAGE_LONGJUMPLAND, res);

	//	�X�e�[�W
	res = new RES(RES_T::MODEL, PATH_MDL + "Stage/haikei.mv1");
	resourcesMap_.emplace(SRC::MDL_BACKGROUND, res);

	//	�v���C���[
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Survivor/1.mv1");
	resourcesMap_.emplace(SRC::MDL_CAR, res);

	//	�v���C���[
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Survivor/2.mv1");
	resourcesMap_.emplace(SRC::MDL_PLAYER, res);

	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Victim/Battery.mv1");
	resourcesMap_.emplace(SRC::MDL_ITEM, res);

	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Victim/Box.mv1");
	resourcesMap_.emplace(SRC::MDL_BOX, res);

	res = new RES(RES_T::SOUND, PATH_SE + "Player/Charge.mp3");
	resourcesMap_.emplace(SRC::SE_CHARGE, res);

	res = new RES(RES_T::SOUND, PATH_SE + "Player/Hassya.mp3");
	resourcesMap_.emplace(SRC::SE_HASSYA, res);
}

void ResourceManager::Release(void)
{
	for (auto& p : loadedMap_)
	{
		p.second.Release();
	}

	loadedMap_.clear();
}

void ResourceManager::Destroy(void)
{
	Release();
	for (auto& res : resourcesMap_)
	{
		res.second->Release();
		delete res.second;
	}
	resourcesMap_.clear();
	delete instance_;
}

const Resource& ResourceManager::Load(SRC src)
{
	Resource& res = _Load(src);
	if (res.type_ == Resource::TYPE::NONE)
	{
		return dummy_;
	}
	return res;
}

int ResourceManager::LoadModelDuplicate(SRC src)
{
	Resource& res = _Load(src);
	if (res.type_ == Resource::TYPE::NONE)
	{
		return -1;
	}

	int duId = MV1DuplicateModel(res.handleId_);
	res.duplicateModelIds_.push_back(duId);

	return duId;
}

ResourceManager::ResourceManager(void)
{
}

Resource& ResourceManager::_Load(SRC src)
{

	//	���[�h�ς݃`�F�b�N
	const auto& lPair = loadedMap_.find(src);
	if (lPair != loadedMap_.end())
	{
		return *resourcesMap_.find(src)->second;
	}

	//	���\�[�X�o�^�`�F�b�N
	const auto& rPair = resourcesMap_.find(src);
	if (rPair == resourcesMap_.end())
	{
		//	�o�^����Ă��Ȃ�
		return dummy_;
	}

	//	���[�h����
	rPair->second->Load();

	//	�O�̂��߃R�s�[�R���X�g���N�^
	loadedMap_.emplace(src, *rPair->second);

	return *rPair->second;

}
