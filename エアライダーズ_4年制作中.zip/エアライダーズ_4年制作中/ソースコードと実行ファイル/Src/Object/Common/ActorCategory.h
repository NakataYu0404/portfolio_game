#pragma once
enum class ActorCategory
{
	PLAYER,
	VEHICLE,
	ITEM_BOX,
	ITEM,
	STAGE,
	DASHAREA

};
