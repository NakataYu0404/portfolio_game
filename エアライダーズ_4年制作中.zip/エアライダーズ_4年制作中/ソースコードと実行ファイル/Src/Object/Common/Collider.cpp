#include "Collider.h"

Collider::Collider(Category cate, TYPE_MODEL type, int modelId)
{
	category_ = cate;
	typeModel_ = type;
	modelId_ = modelId;
	pos_ = { 0.0f,0.0f,0.0f };
	hitInfo_ = {};
}

Collider::~Collider(void)
{
}
