﻿
#include"../../Utility/Utility.h"
#include"Capsule.h"
#include"Sphere.h"
#include"Collider.h"
#include "CollisionManager.h"

CollisionManager* CollisionManager::instance_ = nullptr;


CollisionManager& CollisionManager::CreateInstance()
{
	if (instance_ == nullptr)
	{
		instance_ = new CollisionManager();
	}
	instance_->Init();

	return *instance_;
}

CollisionManager& CollisionManager::GetInstance(void)
{
	return *instance_;
}

void CollisionManager::Init(void)
{

	std::vector<Collider::Category> tags;

	//	使用するタグを追加する
	tags.clear();
	tags.emplace_back(Collider::Category::PLAYER);
	tags.emplace_back(Collider::Category::STAGE);

	//	当たり判定のためのタグ管理
	categoryMap_.emplace(Collider::Category::PLAYER, tags);

	//	tags.clear();f
	//	tags.emplace_back(Collider::TAG::RAIDER);
	//	categoryMap_.emplace(Collider::TAG::SURVIVOR, tags);

}

void CollisionManager::Update(void)
{

	//	ループを抜けたときに削除するコライダの要素番号を保存する
	std::vector<int> deleteAct;
	deleteAct.clear();

	//	範囲for文を使用していたが、「特定の番号で要素を触りたい」ため、普通のfor文に
	for (int actNum = 0; actNum < actors_.size(); actNum++)
	{
		auto& actor = actors_[actNum];

		//	取得したコライダー情報
		auto& actorCollider = actor->GetTransform().lock()->collider_;
		actorCollider->pos_ = actor->GetTransform().lock()->pos;

		auto& actorModelType = actorCollider->typeModel_;
		auto& actorColliderType = actorCollider->typeCollider_;
		auto& actorCategory = actorCollider->category_;

		//	現在のコライダが動くものでなければやりなおし
		if (actorCategory != Collider::Category::PLAYER
			|| categoryMap_.count(actorCategory) == 0)
		{
			continue;
		}

		std::vector<int> deleteTar;
		deleteTar.clear();

		for (int tarNum = 0; tarNum < actors_.size(); tarNum++)
		{
			auto& target = actors_[tarNum];

			//	同じもの同士では判定しない
			if (actor == target)
			{
				continue;
			}

			//	それ以外のオブジェクト
			//	target:typ,CAPSULE, tag, enemy stage
			auto& targetCollider = target->GetTransform().lock()->collider_;
			auto& targetModelType = targetCollider->typeModel_;
			auto& targetColliderType = targetCollider->typeCollider_;
			auto& targetCategory = targetCollider->category_;

			switch (actorModelType)
			{
			case Collider::TYPE_MODEL::MODEL:
				break;
			case Collider::TYPE_MODEL::CAPSULE:
				switch (targetModelType)
				{
				case Collider::TYPE_MODEL::MODEL:		//	カプセル対モデル
				{
					if (targetCategory == Collider::Category::STAGE)
					{

						auto info = Capsule2Model_Collider_PushBack(*actor, target->GetTransform());

						if (info.isHit)
						{
							targetCollider->hitInfo_.isHit = true;
							targetCollider->hitInfo_.normal = info.normal;
							targetCollider->hitInfo_.movedPos = info.movedPos;
							actor->OnCollision(actorColliderType, *targetCollider.get(), *target);
						}
						else
						{
							targetCollider->hitInfo_.isHit = false;
							targetCollider->hitInfo_.normal = { 0.0f, 0.0f, 0.0f };
						}
					}

				}
				break;
				case Collider::TYPE_MODEL::CAPSULE:	//	カプセル対カプセル
					if (Capsule2_Collider(
						actor->GetCapsule(),
						target->GetCapsule()))
					{
						actor->OnCollision(actorColliderType, *targetCollider.get(), *target);
						target->OnCollision(targetColliderType, *actorCollider.get(), *actor);
					}
					break;
				case Collider::TYPE_MODEL::SPHERE:	//	カプセル対スフィア
					if (Sphere2Capsule_Collider(
						target->GetSphere(),
						actor->GetCapsule()))
					{
						actor->OnCollision(actorColliderType, *targetCollider.get(), *target);
						target->OnCollision(targetColliderType, *actorCollider.get(), *actor);
					}
					break;
				}
				break;
			case Collider::TYPE_MODEL::SPHERE:
				switch (targetModelType)
				{
				case Collider::TYPE_MODEL::MODEL:
					break;
				case Collider::TYPE_MODEL::CAPSULE:
					if (Sphere2Capsule_Collider(
						actor->GetSphere(),
						target->GetCapsule()))
					{
						actor->OnCollision(actorColliderType, *targetCollider.get(), *target);
						target->OnCollision(targetColliderType, *actorCollider.get(), *actor);
					}
					break;
				case Collider::TYPE_MODEL::SPHERE:
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}

		}
		for (auto del : deleteTar)
		{
			actors_.erase(actors_.begin() + del);
		}
	}
	for (auto del : deleteAct)
	{
		actors_.erase(actors_.begin() + del);
	}

	for (auto del : actorsDeleteLater_) {
		auto it = std::remove(actors_.begin(), actors_.end(), del);
		if (it != actors_.end()) {
			actors_.erase(it, actors_.end());
		}
	}
	actorsDeleteLater_.clear();
}

void CollisionManager::Draw(void)
{
}

void CollisionManager::Destroy(void)
{
	delete instance_;
}

void CollisionManager::Add(ActorBase& collider)
{
	actors_.emplace_back(&collider);
}

void CollisionManager::Remove(ActorBase& collider) {

	actors_.erase(
		std::remove(actors_.begin(), actors_.end(), &collider),
		actors_.end()
	);
}
void CollisionManager::RemoveLater(ActorBase& collider)
{
	actorsDeleteLater_.emplace_back(&collider);
}

void CollisionManager::AddCollider(std::weak_ptr<Collider> collider)
{
	colliders_.push_back(collider);
}

void CollisionManager::ClearCollider(void)
{
	colliders_.clear();
	actors_.clear();
	categoryMap_.clear();
}

Collider::Collision_Date CollisionManager::Capsule2Model_Collider_PushBack(const ActorBase& actor, const std::weak_ptr<Transform> transform)
{
	Collider::Collision_Date answer;
	answer.isHit = false;

	// 1. 前フレームと今回の目標位置
	VECTOR prevPos = actor.GetTransform().lock()->prevPos;
	VECTOR nextPos = actor.GetTransform().lock()->pos;

	// 2. 分割ステップ数
	const int SUB_STEPS = 40;

	VECTOR stepVec = VScale(VSub(nextPos, prevPos), 1.0f / SUB_STEPS);
	VECTOR currentPos = prevPos;

	// 3. Capsuleの準備
	std::shared_ptr<Transform> trans = std::make_shared<Transform>();
	std::shared_ptr<Capsule> cap = std::make_shared<Capsule>(actor.GetCapsule(), trans);

	// 4. ステップごとに移動
	for (int step = 0; step < SUB_STEPS; ++step)
	{
		VECTOR prevStepPos = currentPos;

		currentPos = VAdd(currentPos, stepVec);
		trans->pos = currentPos;
		trans->Update();

		auto hits = MV1CollCheck_Capsule(
			transform.lock()->modelId, -1,
			cap->GetPosTop(), cap->GetPosDown(), cap->GetRadius());

		if (hits.HitNum > 0)
		{
			// 当たったら前の位置に戻す
			currentPos = prevStepPos;
			trans->pos = currentPos;
			trans->Update();

			answer.isHit = true;

			// ここで一度押し戻し処理を入れる
			for (int i = 0; i < hits.HitNum; i++)
			{
				auto hit = hits.Dim[i];
				answer.normal = hit.Normal;

				// 押し戻し
				currentPos = VAdd(currentPos, VScale(hit.Normal, PUSHBACK_POW_SCALE));
				trans->pos = currentPos;
				trans->Update();
			}

			MV1CollResultPolyDimTerminate(hits);
			break;
		}

		MV1CollResultPolyDimTerminate(hits);
	}

	answer.movedPos = currentPos;
	return answer;
}

MV1_COLL_RESULT_POLY CollisionManager::Line2Collider_ColInfo(
	const Collider::Category colCategory,
	const VECTOR LineTopPos,
	const VECTOR LineBotPos)
{
	MV1_COLL_RESULT_POLY closestHit{};
	closestHit.HitFlag = false;
	float minDistSq = FLT_MAX;

	for (auto& actor : actors_)
	{
		auto& actorCollider = actor->GetTransform().lock()->collider_;
		if (actorCollider->category_ != colCategory)
		{
			continue;
		}

		auto hit = MV1CollCheck_Line(actor->GetTransform().lock()->modelId, -1, LineTopPos, LineBotPos);

		if (hit.HitFlag)
		{
			float dx = hit.HitPosition.x - LineTopPos.x;
			float dy = hit.HitPosition.y - LineTopPos.y;
			float dz = hit.HitPosition.z - LineTopPos.z;
			float distSq = dx * dx + dy * dy + dz * dz;

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				closestHit = hit;
			}
		}
	}

	return closestHit;
}

//DxLib::MV1_COLL_RESULT_POLY CollisionManager::Line2Collider_ColInfo(const Collider::Category colCategory, const VECTOR LineTopPos, const VECTOR LineBotPos)
//{
//	MV1_COLL_RESULT_POLY a;
//
//	if (this == nullptr)
//	{
//		a.HitFlag = false;
//		return a;
//	}
//
//	for (auto& actor : actors_)
//	{
//		auto& actorCollider = actor->GetTransform().lock()->collider_;
//		auto& actorCategory = actorCollider->category_;
//
//		if (actorCategory != colCategory)
//		{
//			continue;
//		}
//
//		auto hit = MV1CollCheck_Line(actor->GetTransform().lock()->modelId, -1, LineTopPos, LineBotPos);
//		return hit;
//	}
//}

std::vector<ActorBase*> CollisionManager::Line2Collider_Actor(const Collider::Category colCategory, const VECTOR LineTopPos, const VECTOR LineBotPos)
{

	std::vector<ActorBase*> ret;

	//このコードに問題があって、ひとつのカテゴリーに複数のモデルがあった場合に、ひとつめのモデルの当たり判定だけ取って満足する

	ActorBase* a  = nullptr;

	if (this == nullptr)
	{
		ret.push_back(a);
		return ret;
	}

	for (auto& actor : actors_)
	{
		//	取得したコライダー情報
		//	actor:typ,CAPSULE, tag, player
		auto& actorCollider = actor->GetTransform().lock()->collider_;
		auto& actorCategory = actorCollider->category_;

		//	対象以外であればループをやり直す
		if (actorCategory != colCategory)
		{
			continue;
		}

		auto hit = HitCheck_Line_Sphere(LineTopPos, LineBotPos, actor->GetCapsule().lock()->GetCenter(), actor->GetCapsule().lock()->GetRadius());

		if (hit)
		{
			ret.push_back(actor);
		}
	}

	return ret;
}

bool CollisionManager::Capsule2_Collider(const std::weak_ptr<Capsule> a, const std::weak_ptr<Capsule> b)
{
	//	プレイヤーと敵の衝突判定
	if (HitCheck_Capsule_Capsule(a.lock()->GetPosTop(), a.lock()->GetPosDown(), a.lock()->GetRadius(),
									b.lock()->GetPosTop(), b.lock()->GetPosDown(), b.lock()->GetRadius()))
	{
		//	isAttack = true;
		return true;
	}
	else
	{
		isAttack = false;
		return false;
	}

}

bool CollisionManager::Sphere2Capsule_Collider(const std::weak_ptr<Sphere> a, const std::weak_ptr<Capsule> b)
{
	if (HitCheck_Sphere_Capsule(a.lock()->GetPos(), a.lock()->GetRadius(), b.lock()->GetPosTop(), b.lock()->GetPosDown(), b.lock()->GetRadius()))
	{
		return true;
	}

	return false;
}
