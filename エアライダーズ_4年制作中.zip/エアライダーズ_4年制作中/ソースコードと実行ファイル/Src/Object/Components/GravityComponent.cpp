#include "../Utility/Utility.h"
#include "../../Object/Common/Transform.h"
#include "../../Object/Common/CollisionManager.h"
#include "../Player/CharacterController.h"
#include "GravityComponent.h"

GravityComponent::GravityComponent(IObjectBase& owner,IActorInfo& actorInfo) : ComponentBase(owner), actorInfo_(actorInfo), colMng_(CollisionManager::GetInstance())
{
	gravityPow_ = 0.0f;
	gravityBase_ = DEFAULT_GRAVITY;
}

float GravityComponent::GetGravityPow(void)
{
	return gravityPow_;
}

float GravityComponent::GetGravityScl(void)
{
    return SCALE_GRAVITY;
}

void GravityComponent::SetGravityPow(float gravityPow)
{
	gravityPow_ = gravityPow;
}

void GravityComponent::AddGravityPow(float gravityPow)
{
	gravityPow_ += gravityPow;
}

void GravityComponent::SetGravityBase_HeavyParam(float gravityPow)
{
	gravityBase_ = DEFAULT_GRAVITY * gravityPow;
}

void GravityComponent::SetGravityBase(float gravity)
{
	gravityBase_ = gravity;
}

void GravityComponent::SetStopGravity(bool isStop)
{
	isStop_ = isStop;
}

void GravityComponent::UpdateBatch(void)
{
	if (isStop_)
	{
		gravityPow_ = 0.0f;
		return;
	}

	VECTOR movedPos = actorInfo_.GetTransform().lock()->pos;

    gravityPow_ += (gravityBase_ * SCALE_GRAVITY) * CORRECT_GRAVITY;

	movedPos.y -= gravityPow_;

	//	�d�͕���
	VECTOR dirGravity = Utility::DIR_D;

	//	�d�͕����̔���
	VECTOR dirUpGravity = Utility::DIR_U;

	float checkPow = CHECK_COL_POW;
	VECTOR gravHitPosUp = VAdd(movedPos, VScale(dirUpGravity, gravityPow_));
	gravHitPosUp = VAdd(gravHitPosUp, VScale(dirUpGravity, checkPow * 2.0f));
	VECTOR gravHitPosDown = VAdd(movedPos, VScale(dirGravity, checkPow));

	auto hit = colMng_.GetInstance().Line2Collider_ColInfo(Collider::Category::STAGE, gravHitPosUp, gravHitPosDown);

	if (hit.HitFlag > 0)
	{
		//	�Փ˒n�_����A������Ɉړ�
		movedPos = VAdd(hit.HitPosition, VScale(dirUpGravity, gravityPow_ * 2.0f));

		gravityPow_ = 0.0f;
	}

    actorInfo_.GetTransform().lock()->pos = movedPos;
	actorInfo_.GetTransform().lock()->Update();

	DrawLine3D(gravHitPosUp, gravHitPosDown, 0xffffff);
}