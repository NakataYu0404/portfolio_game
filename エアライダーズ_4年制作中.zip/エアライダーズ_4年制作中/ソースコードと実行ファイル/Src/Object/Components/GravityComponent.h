#pragma once
#include <memory>
#include "../../Component/ComponentBase.h"

class CollisionManager;

class IGravityFunc
{
public:
	//	�d�͎擾
	virtual float GetGravityPow(void) = 0;
	virtual float GetGravityScl(void) = 0;

	//	�d�̓Z�b�g
	virtual void SetGravityPow(float gravityPow) = 0;

	//	�d�͒ǉ�(+�ŏ����)
	virtual void AddGravityPow(float gravityPow) = 0;

	virtual void SetGravityBase_HeavyParam(float param) = 0;
	virtual void SetGravityBase(float gravity) = 0;

	//	�d�͂��~
	virtual void SetStopGravity(bool isStop) = 0;
};

class GravityComponent : public ComponentBase , public IGravityFunc
{
public:
	//	�R���X�g
	GravityComponent(IObjectBase& owner, IActorInfo& actorInfo);

	//	�d�͎擾
	float GetGravityPow(void) override;
	float GetGravityScl(void) override;

	//	�d�̓Z�b�g
	void SetGravityPow(float gravityPow) override;
	
	//	�d�͒ǉ�(+�ŏ����)
	void AddGravityPow(float gravityPow) override;

	void SetGravityBase_HeavyParam(float gravityPow) override;
	void SetGravityBase(float gravity) override;
	//	�d�͂��~
	void SetStopGravity(bool isStop) override;

	static constexpr float MAX_GRAVITY = 9.8f;

private:

	//	��{�̏d��
	static constexpr float DEFAULT_GRAVITY = 3.0f;

	static constexpr float CORRECT_GRAVITY = 0.095f;
	static constexpr int SCALE_GRAVITY = 2;

	static constexpr float CHECK_COL_POW = 20.0f;


	//	���t���[������
	void UpdateBatch(void) override;

	//	�d��
	float gravityPow_;

	IActorInfo& actorInfo_;

	CollisionManager& colMng_;

	bool isStop_ = false;

	float gravityBase_;
};

