#pragma once

enum class GENERATE_TYPE
{
	VEHICLE,
	ITEMBOX,
	ITEM,
	MAX
};