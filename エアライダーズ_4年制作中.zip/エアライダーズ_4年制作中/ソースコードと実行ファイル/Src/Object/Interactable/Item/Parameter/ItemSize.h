#pragma once

enum class ITEM_SIZE
{
	SMALL,

	MIDIUM,
	
	LARGE,

	GOD,

	MAX
};