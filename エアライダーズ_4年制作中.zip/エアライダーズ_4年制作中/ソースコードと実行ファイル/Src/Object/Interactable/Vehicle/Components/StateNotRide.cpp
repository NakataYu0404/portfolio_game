#include "../Object/Components/GravityComponent.h"
#include "../VehicleBase.h"
#include "StateNotRide.h"

StateNotRide::StateNotRide(IObjectBase& owner, IVehicleInfo& vehicleInfo) : VehicleStateBase(owner, vehicleInfo)
{
	LoadComponents();
}

void StateNotRide::Update(void)
{
	for (auto& c : components_)
	{
		c->UpdateBatch();
	}
}

void StateNotRide::LoadComponents(void)
{
	new GravityComponent(*this, vehicleInfo_);
}
