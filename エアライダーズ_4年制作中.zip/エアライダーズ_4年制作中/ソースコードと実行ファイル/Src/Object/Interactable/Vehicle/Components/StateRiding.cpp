#include "../VehicleBase.h"
#include "StateRiding.h"

StateRiding::StateRiding(IObjectBase& owner, IVehicleInfo& vehicleInfo) : VehicleStateBase(owner, vehicleInfo)
{
}

void StateRiding::Update(void)
{
}

void StateRiding::LoadComponents(void)
{
}
