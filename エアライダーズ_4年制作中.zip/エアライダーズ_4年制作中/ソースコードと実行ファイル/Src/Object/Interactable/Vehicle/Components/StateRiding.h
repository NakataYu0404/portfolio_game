#pragma once
#include "VehicleStateBase.h"

class IObjectBase;
class IVehicleInfo;

class StateRiding : public VehicleStateBase
{
public:
	StateRiding(IObjectBase& owner, IVehicleInfo& vehicleInfo);

	void Enter(void) override {};    // ��Ԃɓ������Ƃ���1�񂾂��Ă΂��

	void Update(void) override;


private:
	void LoadComponents(void) override;

};

