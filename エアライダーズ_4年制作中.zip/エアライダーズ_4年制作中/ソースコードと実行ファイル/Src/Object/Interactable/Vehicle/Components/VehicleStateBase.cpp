#include "../VehicleBase.h"
#include "VehicleStateBase.h"

VehicleStateBase::VehicleStateBase(IObjectBase& owner, IVehicleInfo& vehicleInfo) : ComponentBase(owner), vehicleInfo_(vehicleInfo)
{
}
