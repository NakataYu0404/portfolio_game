#pragma once

enum class CAR_TYPE
{
	NORMAL,

	CHARGE,

	MAX
};