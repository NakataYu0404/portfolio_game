#pragma once

enum class STATE_VEHICLE
{
	NOTRIDE,
	RIDING
};