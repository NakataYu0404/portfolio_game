﻿#include <iostream>
#include <fstream>
#include <algorithm>
#include <nlohmann/json.hpp>
#include "../../Application.h"
#include "../../Utility/Utility.h"
#include "../../Manager/ResourceManager.h"
#include "../../Manager/UIManager.h"
#include "../../Manager/Camera/Camera.h"
#include "../../Scene/GameScene.h"
#include "../Object/Common/AnimationController.h"
#include "../Object/Common/CollisionManager.h"
#include "../Object/Common/EffectController.h"
#include "../Common/Capsule.h"
#include "../../Component/ComponentBase.h"
#include "../Object/Components/GravityComponent.h"
#include "Components/Player/Player.h"
#include "Components/Player/Driver.h"
#include "Components/Player/Car.h"
#include "../Object/Interactable/Vehicle/VehicleBase.h"
#include "../Object/Interactable/Vehicle/Parameter/Car/StateType_Vehicle.h"

#include "../../UI/UIBase.h"

#include "CharacterController.h"

// CharacterController: プレイヤーの操作・状態・パラメータ・車両管理などを担当するメインコントローラー
// 車両・ドライバーの切り替え、パラメータ補正、アイテム取得、コリジョン・描画・初期化などを実装

constexpr float BOOST_RATE = 2.0f;
constexpr float MOVE_YBOOST_THRESHOLD = 0.3f;
constexpr float MOVE_YBOOST_VALUE = 1.3f;
constexpr float INIT_SCALE = 0.2f;
constexpr float INIT_POS_Y = 100.0f;
constexpr float SCALE_MIN = 1.0f / 3.0f;
constexpr float SCALE_MAX = 3.0f;

constexpr int ITEM_UP_SMALL = 1;
constexpr int ITEM_UP_MIDIUM = 2;
constexpr int ITEM_UP_LARGE = 4;
constexpr int ITEM_UP_GOD = 8;

constexpr int ITEM_PARAM_MAX = 60;

constexpr float PARAM_MIN = 0.01f;
constexpr float PARAM_MAX = 60.0f;
constexpr float PARAM_NORM_MIN = 0.1f;
constexpr float PARAM_NORM_MAX = 1.0f;

CharacterController::CharacterController(std::string plnum, IChangeMode& camera, IGetInGameMode& getGameMode) : ActorBase(),  colMng_(CollisionManager::GetInstance()), UIMng_(UIManager::GetInstance()), changeCameraMode_(camera)
{
}

CharacterController::~CharacterController(void)
{
}

// アイテム取得時のパラメータ加算・上限補正
void CharacterController::AddParameter(ITEM_TYPE type, ITEM_SIZE size)
{
    int up = 0;
    switch (size) 
    {
    case ITEM_SIZE::SMALL:  up = ITEM_UP_SMALL; break;
    case ITEM_SIZE::MIDIUM: up = ITEM_UP_MIDIUM; break;
    case ITEM_SIZE::LARGE:  up = ITEM_UP_LARGE; break;
    case ITEM_SIZE::GOD:    up = ITEM_UP_GOD; break;
    }

    switch (type) 
    {
    case ITEM_TYPE::ACCELERATION: myParam_.acceleration += up; break;
    case ITEM_TYPE::MAXSPEED:     myParam_.maxSpeed += up; break;
    case ITEM_TYPE::TURN:         myParam_.turn += up; break;
    case ITEM_TYPE::CHARGESPEED:  myParam_.chargeSpeed += up; break;
    case ITEM_TYPE::HEAVY:        myParam_.heavy += up; break;
    case ITEM_TYPE::GRIP:         myParam_.grip += up; break;
    case ITEM_TYPE::ATTACK:       myParam_.attack += up; break;
    case ITEM_TYPE::DEFENCE:      myParam_.defence += up; break;
    case ITEM_TYPE::HEALTH:       myParam_.health += up; break;
    }

    auto clampMax = [](int& v) { v = min(v, ITEM_PARAM_MAX); };

    clampMax(myParam_.acceleration);
    clampMax(myParam_.maxSpeed);
    clampMax(myParam_.turn);
    clampMax(myParam_.chargeSpeed);
    clampMax(myParam_.heavy);
    clampMax(myParam_.grip);
    clampMax(myParam_.attack);
    clampMax(myParam_.defence);
    clampMax(myParam_.health);
}

// パラメータ取得（車両パラメータに自分の補正をかける）
CAR_PARAMETER_FLOAT CharacterController::GetParameter(void)
{
    CAR_PARAMETER_FLOAT param;

    if (myCar_ == nullptr) 
        return param = { "",float(myParam_.acceleration), float(myParam_.attack),float(param.chargeSpeed),float(param.defence),float(param.heavy),
        float(param.health),float(param.grip),float(param.maxSpeed),float(param.turn)};


    CAR_PARAMETER_FLOAT& car = myCar_->GetParameter();

    auto calcScale = [](float normalized) -> float {
        if (normalized <= 0.5f) {
            // 0〜0.5 (myParam 0〜30) で 1/3 → 1 に補完
            return SCALE_MIN + (1.0f - SCALE_MIN) * (normalized / 0.5f);
        }
        else {
            // 0.5〜1 (myParam 30〜60) で 1 → 3 に補完
            return 1.0f + (SCALE_MAX - 1.0f) * ((normalized - 0.5f) / 0.5f);
        }
    };

    auto normalize = [](float value, float minVal, float maxVal) -> float {
        if (value < minVal) return PARAM_NORM_MIN;
        if (value > maxVal) return PARAM_NORM_MAX;
        return (value - minVal) / (maxVal - minVal);
    };

    // 使い方
    param.acceleration = car.acceleration * calcScale(normalize(myParam_.acceleration, PARAM_MIN, PARAM_MAX));
    param.attack = car.attack * calcScale(normalize(myParam_.attack, PARAM_MIN, PARAM_MAX));
    param.chargeSpeed = car.chargeSpeed * calcScale(normalize(myParam_.chargeSpeed, PARAM_MIN, PARAM_MAX));
    param.defence = car.defence * calcScale(normalize(myParam_.defence, PARAM_MIN, PARAM_MAX));
    param.heavy = car.heavy * calcScale(normalize(myParam_.heavy, PARAM_MIN, PARAM_MAX));
    param.health = car.health * calcScale(normalize(myParam_.health, PARAM_MIN, PARAM_MAX));
    param.maxSpeed = car.maxSpeed * calcScale(normalize(myParam_.maxSpeed, PARAM_MIN, PARAM_MAX));


    param.grip = clamp(car.grip * normalize(myParam_.grip, PARAM_MIN, PARAM_MAX), PARAM_MIN, PARAM_NORM_MAX);
    param.turn = clamp(car.turn * normalize(myParam_.turn, PARAM_MIN, PARAM_MAX), PARAM_MIN, PARAM_NORM_MAX);
    return param;
}

// プレイヤー自身のパラメータ取得
CAR_PARAMETER_INT CharacterController::GetPlayerParameter(void)
{
    return myParam_;
}

// ダッシュ時の移動量加算（Y成分ブースト）
void CharacterController::AddDashMovePow(float maxSpeed)
{
    auto& moveData = dynamic_cast<IGetMoveData*>(controllMap_[CONTROLL_MODE::CAR])->GetMoveData();

    moveData.dashXZSpeed_ += GetParameter().maxSpeed * BOOST_RATE;

    if (moveData.dashXZSpeed_ > maxSpeed)
    {
        moveData.dashXZSpeed_ = maxSpeed;
    }

    // 当たった瞬間のY成分
    VECTOR moveDir = Utility::VNormalize(
        VSub(transform_->pos, transform_->prevPos)
    );

    float moveYboost = 0.0f;
    if (moveDir.y > MOVE_YBOOST_THRESHOLD)
    {
        moveYboost = MOVE_YBOOST_VALUE;
    }

    moveData.dashPow_.y = (moveDir.y * moveYboost) * moveData.dashXZSpeed_;
}

// 車両・ドライバー切り替え
void CharacterController::ChangeGetOnOff(CONTROLL_MODE mode)
{
    // 存在しないなら帰る
    if (!controllMap_.contains(mode)) return;

    controllMap_.find(mode)->second->Enter();
    updateCharacterMode_ = std::bind(&Player::Update, controllMap_.find(mode)->second);

    controllMode_ = mode;

    switch (mode)
    {
    case CONTROLL_MODE::DRIVER:
        changeCameraMode_.ChangeMode(CAMERA_MODE::FOLLOW_DRIVER);
        changeCameraMode_.SetFollowTarget(transform_.get());
        if (myCar_ != nullptr)
        {
            myCar_->ChangeState(STATE_VEHICLE::NOTRIDE);
            myCar_ = nullptr;
        }
        break;
    case CONTROLL_MODE::CAR:
        changeCameraMode_.ChangeMode(CAMERA_MODE::FOLLOW_CAR);
        changeCameraMode_.SetFollowTarget(transform_.get());
        break;
    }
}

// 初期化処理
void CharacterController::Init(void)
{
    transform_ = std::make_shared<Transform>();
    transform_->modelId = resMng_.LoadModelDuplicate(ResourceManager::SRC::MDL_PLAYER);

    float scale = INIT_SCALE;
    transform_->scl = { scale,scale,scale };
    transform_->pos = { 0.0f,INIT_POS_Y,0.0f };
    transform_->quaRot = Quaternion::Euler(0.0f, 0.0f, 0.0f);
    transform_->quaRotLocal = Quaternion::AngleAxis(Utility::Deg2RadF(180.0f),Utility::AXIS_Y);
    transform_->MakeCollider(Collider::Category::PLAYER, Collider::TYPE_MODEL::CAPSULE);
    transform_->Update();
    capsule_ = std::make_shared<Capsule>(transform_);
    // マジック
    capsule_->SetLocalPosTop({ 0.0f, CAPSULE_TOP_Y,0.0f });
    capsule_->SetLocalPosDown({ 0.0f, CAPSULE_DOWN_Y, -0.0f });
    capsule_->SetRadius(CAPSULE_RADIUS);

    myParam_ = { "",INIT_PARAM_VALUE,INIT_PARAM_VALUE,INIT_PARAM_VALUE,INIT_PARAM_VALUE,INIT_PARAM_VALUE,INIT_PARAM_VALUE,INIT_PARAM_VALUE,INIT_PARAM_VALUE,INIT_PARAM_VALUE };
    
    colMng_.Add(*this);

    LoadComponents();

    ChangeGetOnOff(CONTROLL_MODE::DRIVER);
}

// コンポーネント初期化
void CharacterController::LoadComponents(void)
{
    new GravityComponent(*this, *this);

    new Driver(*this, *this,*GetComponent<GravityComponent>());
    new Car(*this, *this, changeCameraMode_, *this, *this, *GetComponent<GravityComponent>());

    controllMap_.emplace(CONTROLL_MODE::DRIVER, GetComponent<Driver>());
    controllMap_.emplace(CONTROLL_MODE::CAR, GetComponent<Car>());

}

void CharacterController::SetParam(void)
{
}

// 毎フレームの更新処理
void CharacterController::Update(void)
{
    transform_->prevPos = transform_->pos;

    updateCharacterMode_();

    for (auto& c : components_)
    {
        c->UpdateBatch();
    }
    if (myCar_ != nullptr)
    {
        myCar_->GetTransform().lock()->pos = transform_->pos;
        myCar_->GetTransform().lock()->quaRot = transform_->quaRot;
        myCar_->GetTransform().lock()->Update();
    }

    if (InputManager::GetInstance().IsPress(KEY_INPUT_LSHIFT))
        ChangeGetOnOff(CONTROLL_MODE::DRIVER);
}

void CharacterController::UpdateStop(void)
{
}

// 描画処理
void CharacterController::Draw(void)
{
    MV1DrawModel(transform_->modelId);
    capsule_->Draw();

    DrawFormatString(0, 0, 0xffffff, "x:%.f,y:%.f,z:%.f", transform_->pos.x, transform_->pos.y, transform_->pos.z);
}

// コリジョン判定
void CharacterController::OnCollision(Collider::TYPE_COLLIDER& myColliderType, Collider& someOneCollider, IActorInfo& someOne)
{
    if (someOneCollider.category_ == Collider::Category::STAGE)
    {
        transform_->pos = someOneCollider.hitInfo_.movedPos;
        transform_->Update();

        if (myCar_ != nullptr)
        {
            myCar_->GetTransform().lock()->pos = transform_->pos;
            myCar_->GetTransform().lock()->Update();
        }
    }
    if (someOneCollider.category_ == Collider::Category::VEHICLE)
    {
        IVehicleInfo* vehicle = dynamic_cast<IVehicleInfo*>(&someOne);

        if (vehicle->GetIsRiding()) return;
        
        if (vehicle->IsCantRide()) return;

        ChangeGetOnOff(CONTROLL_MODE::CAR);

        myCar_ = vehicle;
        myCar_->ChangeState(STATE_VEHICLE::RIDING);
    }
}

void CharacterController::DrawCommon(void)
{
}

void CharacterController::InitAnimation(void)
{
}

void CharacterController::InitEffect(void)
{
}

// 自分の車両情報取得
IVehicleInfo& CharacterController::GetMyCar(void)
{
    return *myCar_;
}
