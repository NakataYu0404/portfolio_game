#pragma once
#include <vector>
#include <memory>
#include <functional>
#include <unordered_map>
#include <map>
#include "../../Manager/InputManager.h"
#include "../ActorBase.h"
#include "Parameter/CharacterControlMode.h"
#include "../Object/Interactable/Vehicle/Parameter/Car/CarParameter.h"
#include "../Object/Interactable/Item/Parameter/ItemSize.h"
#include "../Object/Interactable/Item/Parameter/ItemType.h"

class CollisionManager;
class UIManager;
class EffectController;
class AnimationController;
class ComponentBase;
class Player;
class IChangeMode;
class IVehicleInfo;
class IGetInGameMode;

// ICharacterInfo: �L�����N�^�[���C���^�[�t�F�[�X
class ICharacterInfo : virtual public IActorInfo
{
public:
    virtual std::string GetPlayerNum(void) const = 0;
    virtual const std::weak_ptr<Transform> GetTransform(void) const override = 0;
};

// ICharacterMyCar: �����̎ԗ����C���^�[�t�F�[�X
class ICharacterMyCar
{
public:
    virtual IVehicleInfo& GetMyCar(void) = 0;
};

// IParameterInfo: �p�����[�^�Ǘ��C���^�[�t�F�[�X
class IParameterInfo
{
public:
    virtual void AddParameter(ITEM_TYPE type, ITEM_SIZE size) = 0;
    virtual CAR_PARAMETER_FLOAT GetParameter(void) = 0;
    virtual CAR_PARAMETER_INT GetPlayerParameter(void) = 0;
};

// IDashBoardFunc: �_�b�V�������C���^�[�t�F�[�X
class IDashBoardFunc : virtual public IParameterInfo
{
public:
    virtual void AddDashMovePow(float maxSpeed) = 0;
};

// CharacterController: �v���C���[�̑���E��ԁE�p�����[�^�E�ԗ��Ǘ��Ȃǂ�S�����郁�C���R���g���[���[
class CharacterController : public ActorBase , public ICharacterInfo, public ICharacterMyCar, virtual public IParameterInfo, public IDashBoardFunc
{
public:
    CharacterController(std::string plnum, IChangeMode& camera, IGetInGameMode& getGameMode);
    ~CharacterController(void);
    void Init(void) override;
    void Update(void) override;
    void UpdateStop(void) override;
    void Draw(void) override;
    void OnCollision(Collider::TYPE_COLLIDER& myColliderType, Collider& someOneCollider, IActorInfo& someOne) override;
    std::string GetPlayerNum(void) const override { return myPlayerNumber_; }
    enum class ANIM_TYPE
    {
        NONE,
        IDLE,
        WALK,
        RUN,
        JUMP,
        GETUP,
        PAIN,
    };
    const std::weak_ptr<Transform> GetTransform(void) const override { return ActorBase::GetTransform(); };
    // --- �萔 ---
    static constexpr int ITEM_UP_SMALL = 1;
    static constexpr int ITEM_UP_MIDIUM = 2;
    static constexpr int ITEM_UP_LARGE = 4;
    static constexpr int ITEM_UP_GOD = 8;
    static constexpr int ITEM_PARAM_MAX = 60;
    static constexpr float PARAM_MIN = 0.01f;
    static constexpr float PARAM_MAX = 60.0f;
    static constexpr float PARAM_NORM_MIN = 0.1f;
    static constexpr float PARAM_NORM_MAX = 1.0f;
    static constexpr float SCALE_MIN = 1.0f / 3.0f;
    static constexpr float SCALE_MAX = 3.0f;
    static constexpr float BOOST_RATE = 2.0f;
    static constexpr float MOVE_YBOOST_THRESHOLD = 0.3f;
    static constexpr float MOVE_YBOOST_VALUE = 1.3f;
    static constexpr float INIT_SCALE = 0.2f;
    static constexpr float INIT_POS_Y = 100.0f;
    static constexpr float CAPSULE_TOP_Y = 20.0f;
    static constexpr float CAPSULE_DOWN_Y = 10.0f;
    static constexpr float CAPSULE_RADIUS = 10.0f;
    static constexpr int INIT_PARAM_VALUE = 30; // JSON�ŏ���������悤�ɂȂ�����s�v�ɂȂ�
protected:
    enum class EFFECT_TYPE
    {
    };
    IVehicleInfo& GetMyCar(void) override;
    void AddParameter(ITEM_TYPE type, ITEM_SIZE size) override;
    CAR_PARAMETER_FLOAT GetParameter(void) override;
    CAR_PARAMETER_INT GetPlayerParameter(void) override;
    void AddDashMovePow(float maxSpeed) override;
    void ChangeGetOnOff(CONTROLL_MODE mode);
    void SetParam(void) override;
    // �R���|�[�l���g�̏�����
    void LoadComponents(void);
    void DrawCommon(void);
    void InitAnimation(void);
    void InitEffect(void);
    // �����̃v���C���[�ԍ�"player�Z"
    std::string myPlayerNumber_;
    // Update�֐���؂�ւ��邽�߂̊֐��I�u�W�F�N�g
    std::function<void()> updateCharacterMode_;
    CONTROLL_MODE controllMode_;
    std::unordered_map<CONTROLL_MODE, Player*> controllMap_;
    // �A�j���[�V����
    std::unique_ptr<AnimationController> animation_;
    CollisionManager& colMng_;
    UIManager& UIMng_;
    std::unique_ptr<EffectController> effectController_;
    IChangeMode& changeCameraMode_;
    IVehicleInfo* myCar_;
    // �Ԗ��̃p�����[�^�Ƃ͕ʂ̃p�����[�^
    CAR_PARAMETER_INT myParam_;
};