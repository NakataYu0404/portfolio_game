﻿#include "../Manager/InputManager.h"
#include "../Manager/ResourceManager.h"
#include "../Object/Player/CharacterController.h"
#include "../Object/Player/Components/Player/Player.h"
#include "../../../CharacterInterfacePack.h"
#include "../Object/Interactable/Vehicle/VehicleBase.h"
#include "../Object/Components/GravityComponent.h"
#include "../../../../../Parameter/MoveData_Car.h"

#include "MoveCar_Idle.h"

// MoveCar_Idle: 車両のアイドル状態の移動ロジックを担当するコンポーネント
// ダッシュ減衰・加速度計算・速度補間など、アイドル特有の物理挙動を実装

MoveCar_Idle::MoveCar_Idle(IObjectBase& owner, ICharacterInfo& actorInfo, CharacterInterfacePack_Car& carInterface)
	: MoveBase(owner, actorInfo, std::variant<CharacterInterfacePack_Car*, CharacterInterfacePack_Driver*>{ &carInterface })
	, moveData_(carInterface.moveData), myCar_(carInterface.myCar), param_(carInterface.paramFunc), gravityFunc_(carInterface.gravityFunc)
{
}

MoveCar_Idle::~MoveCar_Idle()
{
}

// 毎フレームの一括更新処理
void MoveCar_Idle::UpdateBatch(void)
{
	gravityFunc_.SetGravityBase_HeavyParam(param_.GetParameter().heavy);
	UpdateDashPow();
	CalcSpeed();
	Move();
}

// 移動処理
void MoveCar_Idle::Move()
{
    Transform* transform = info_.GetTransform().lock().get();

    transform->SetPos(VAdd(transform->pos, moveData_.movePow_));

    transform->Update();
}

// 速度計算（アイドル特有の加速・減衰）
void MoveCar_Idle::CalcSpeed()
{
    CAR_PARAMETER_FLOAT param = param_.GetParameter();

    moveData_.acceleSpeed_ = (param.maxSpeed / ACCELE_DIVISOR) * (moveData_.enginePower_ / moveData_.MAX_POWER);

    if (moveData_.enginePower_ > 0.0f)
        moveData_.enginePower_ -= moveData_.DOWN_POWER;
    else
        moveData_.enginePower_ = 0.0f;

    int kiso = param.maxSpeed;
    speed_ = kiso + moveData_.acceleSpeed_;

    Transform* transform = info_.GetTransform().lock().get();
    VECTOR forward = transform->GetForward();

    moveData_.movePow_ =
        VAdd(
            VScale(forward, speed_),
            moveData_.dashPow_
        );
}

// ダッシュパワー更新（減衰・停止判定）
void MoveCar_Idle::UpdateDashPow()
{
    auto& moveData = moveData_;

    // 現在の向き
    Transform* transform = info_.GetTransform().lock().get();
    VECTOR forward = transform->GetForward();

    // XZ方向は向きに追従して毎フレーム決める
    VECTOR dashXZ = VScale(forward, moveData.dashXZSpeed_);

    moveData.dashPow_.x = dashXZ.x;
    moveData.dashPow_.z = dashXZ.z;

    //  減衰値 定数化
    float decay = DASH_DECAY;
    moveData.dashXZSpeed_ *= decay;
    moveData.dashPow_.y *= decay;

    if (moveData.dashXZSpeed_ < DASH_STOP_THRESHOLD)
        moveData.dashXZSpeed_ = 0.0f;

    if (abs(moveData.dashPow_.y) < DASH_STOP_THRESHOLD)
        moveData.dashPow_.y = 0.0f;

    if (dashXZ.x < DASH_STOP_THRESHOLD && dashXZ.z < DASH_STOP_THRESHOLD)
        int a = 0;
}