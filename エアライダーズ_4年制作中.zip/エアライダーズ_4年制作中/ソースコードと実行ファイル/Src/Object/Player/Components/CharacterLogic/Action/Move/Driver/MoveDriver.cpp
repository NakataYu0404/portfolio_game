﻿#include "../Utility/Utility.h"
#include "../Manager/InputManager.h"
#include "../Manager/SceneManager.h"
#include "../Manager/Camera/Camera.h"
#include "../Object/Player/CharacterController.h"
#include "MoveDriver.h"

// MoveDriver: プレイヤー（ドライバー）の移動ロジックを担当するコンポーネント
// カメラ方向に基づく移動・回転補間・速度制御などを実装

MoveDriver::MoveDriver(IObjectBase& owner, ICharacterInfo& actorInfo, CharacterInterfacePack_Driver& driver)
	: MoveBase(owner, actorInfo, std::variant<CharacterInterfacePack_Car*, CharacterInterfacePack_Driver*>{ &driver })
{

}

MoveDriver::~MoveDriver()
{

}

// 毎フレームの一括更新処理
void MoveDriver::UpdateBatch(void)
{
	Move();
}

// 移動処理（カメラ方向・入力に応じて移動・回転）
void MoveDriver::Move(void)
{
    auto& ins = InputManager::GetInstance();

    // カメラの回転情報を取得
    Quaternion cameraRot = SceneManager::GetInstance().GetCamera()->CalculateCameraRotation();

    // カメラの前方向をXZ平面に投影して正規化（y成分は0）
    VECTOR cameraForward = cameraRot.GetForward();
    cameraForward.y = 0.0f;
    cameraForward = Utility::VNormalize(cameraForward);

    // カメラの右方向を計算（Y軸と前方向の外積で右方向取得）
    VECTOR cameraRight = Utility::VNormalize(VCross(Utility::AXIS_Y, cameraForward));

    // 移動方向初期化
    VECTOR moveDir = Utility::VECTOR_ZERO;

    // 入力に応じて移動方向を加算（複数キー同時押しで斜め移動可能）
    if (ins.IsPress(KEY_INPUT_W)) moveDir = VAdd(moveDir, cameraForward);
    if (ins.IsPress(KEY_INPUT_S)) moveDir = VSub(moveDir, cameraForward);
    if (ins.IsPress(KEY_INPUT_D)) moveDir = VAdd(moveDir, cameraRight);
    if (ins.IsPress(KEY_INPUT_A)) moveDir = VSub(moveDir, cameraRight);

    // moveDirがゼロでなければ移動処理
    if (!Utility::EqualsVZero(moveDir))
    {
        moveDir = Utility::VNormalize(moveDir); // 正規化

        // 移動速度決定（Shiftキーでダッシュ）
        speed_ = SPEED;

        // Transform取得
        Transform* transform = info_.GetTransform().lock().get();

        // 位置を移動方向に沿って更新
        transform->SetPos(VAdd(transform->pos, VScale(moveDir, speed_)));

        if (!Utility::EqualsVZero(moveDir))
        {
            // 回転補間処理
            // moveDirのXZ平面上の角度を計算（atan2でx,zからY軸回転角度取得）
            VECTOR flatDir = Utility::VNormalize(VGet(moveDir.x, 0.0f, moveDir.z));
            float rotRad = atan2f(flatDir.x, flatDir.z);

            // 目標回転をクォータニオンで作成
            Quaternion targetRot = Quaternion::AngleAxis(rotRad, Utility::AXIS_Y);

            // 現在の回転
            Quaternion currentRot = transform->quaRot;

            // 補間係数（滑らかさ調整）
            float t = ROTATION_SPEED * DELTA_TIME;
            if (t > MAX_ROTATION_T) t = MAX_ROTATION_T;

            // 球面線形補間（Slerp）で回転更新
            transform->quaRot = Quaternion::Slerp(currentRot, targetRot, t);
        }

        // Transformの更新処理呼び出し
        transform->Update();
    }
}