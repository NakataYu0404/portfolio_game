#include "../Manager/InputManager.h"
#include "../Object/Player/CharacterController.h"
#include "../Object/Player/Components/Player/Player.h"
#include "../../CharacterInterfacePack.h"
#include "MoveBase.h"

MoveBase::MoveBase(IObjectBase& owner, ICharacterInfo& actorInfo, std::variant<CharacterInterfacePack_Car*, CharacterInterfacePack_Driver*> characterInterfacePack)
    : ActionBase(owner, actorInfo, characterInterfacePack),
    input_(InputManager::GetInstance())
{
}

MoveBase::~MoveBase()
{
}

void MoveBase::ChangeSpeed(float speed)
{
	speed_ = speed;
}
