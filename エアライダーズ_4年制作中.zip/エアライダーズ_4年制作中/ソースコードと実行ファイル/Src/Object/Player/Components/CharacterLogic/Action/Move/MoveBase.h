#pragma once
#include <DxLib.h>
#include "../ActionBase.h"

struct CharacterInterfacePack_Car;

class IObjectBase;
class ICharacterInfo;

class InputManager;

class IActionbyStateCommon;


class MoveBase : public ActionBase
{
public:
	MoveBase(IObjectBase& owner, ICharacterInfo& actorInfo, std::variant<CharacterInterfacePack_Car*, CharacterInterfacePack_Driver*> characterInterfacePack);
	~MoveBase();

	virtual void ChangeSpeed(float speed);

	void UpdateBatch(void) override = 0;

protected:
	virtual void Move(void) = 0;

	//	TODO:�X�s�[�h�̏�����(=10�̂Ƃ�)�������ł����
	float speed_ = 0;

	InputManager& input_;
};

