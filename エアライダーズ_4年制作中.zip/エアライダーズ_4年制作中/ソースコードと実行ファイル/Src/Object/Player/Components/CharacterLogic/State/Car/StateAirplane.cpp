#include "../Utility/Utility.h"
#include "../Manager/InputManager.h"
#include "../../../../CharacterController.h"
#include "../../../Player/Player.h"
#include "../../CharacterInterfacePack.h"
#include "../../Action/Move/car/MoveCar_Idle.h"
#include "../../Action/Turn/car/TurnAirplane.h"
#include "StateAirplane.h"

// StateAirplane: �؋�i�ԗ��j��ԁi�󒆑ҋ@�j���Ǘ�����X�e�[�g
// S�L�[�Ń`���[�W��Ԃ֑J��

StateAirplane::StateAirplane(IObjectBase& owner, ICharacterInfo& info, CharacterInterfacePack_Car& carInterface) 
    : StateBase(owner, info, std::variant<CharacterInterfacePack_Car*, CharacterInterfacePack_Driver*>{&carInterface})
{
    LoadComponents();
}

void StateAirplane::Enter(void)
{

}

void StateAirplane::UpdateManual(void)
{
    for (auto& c : components_)
    {
        c->UpdateBatch();
    }
    auto& ins = InputManager::GetInstance();
    // TODO: ���͎d�l�����\��
    if (ins.IsPress(KEY_INPUT_S))
    {
        commonFunc_.ChangeState(STATE_CAR::CHARGE);
    }
}

// �K�v�ȃR���|�[�l���g��ǉ�
void StateAirplane::LoadComponents(void)
{
    std::visit([this](auto* packPtr) {
        using T = std::decay_t<decltype(*packPtr)>;
        if constexpr (std::is_same_v<T, CharacterInterfacePack_Car>) {
            new MoveCar_Idle(*this, info_, *packPtr);
            new TurnAirplane(*this, info_, *packPtr);
        }
        }, characterInterfacePack_);
}