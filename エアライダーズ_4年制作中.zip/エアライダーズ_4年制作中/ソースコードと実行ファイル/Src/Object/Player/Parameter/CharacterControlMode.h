#pragma once

enum class CONTROLL_MODE
{
	DRIVER,
	CAR
};
