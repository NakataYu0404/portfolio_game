#pragma once
#include <variant>
#include <functional>
#include <type_traits>
#include <typeinfo>

enum class STATE_CAR
{
	IDLE,

    AIRPLANE,

	CHARGE,

	PAIN,

	BRAKE
};

enum class STATE_DRIVER
{
	IDLE,
	MOVE,
	JUMP,

	ATTACK,

	PAIN,
	DOWN,
	GETUP

};

namespace std {
    template <>
    struct hash<std::variant<STATE_DRIVER, STATE_CAR>> {
        size_t operator()(const std::variant<STATE_DRIVER, STATE_CAR>& v) const {
            return std::visit([](auto&& arg) -> size_t {
                using T = std::decay_t<decltype(arg)>;
                size_t typeHash = typeid(T).hash_code();
                size_t valueHash = std::hash<std::underlying_type_t<T>>{}(
                    static_cast<std::underlying_type_t<T>>(arg)
                    );
                return typeHash ^ (valueHash << 1);
                }, v);
        }
    };
}