#include "StopComponent.h"

StopComponent::StopComponent(IObjectBase& owner):ComponentBase(owner)
{
	stopFrame_ = 0;
	timer_ = 0;
	isStop_ = false;
}

void StopComponent::Stop(int stopFrame, STOP_TYPE type)
{
	stopFrame_ = stopFrame;
	isStop_ = true;
	timer_ = 0;
	type_ = type;
}

bool StopComponent::IsStop(void)
{
	return isStop_;
}

StopComponent::STOP_TYPE StopComponent::GetStopType(void)
{
	return type_;
}

void StopComponent::UpdateBatch(void)
{
	if (timer_ >= stopFrame_)
	{
		isStop_ = false;
	}

	timer_++;
}
