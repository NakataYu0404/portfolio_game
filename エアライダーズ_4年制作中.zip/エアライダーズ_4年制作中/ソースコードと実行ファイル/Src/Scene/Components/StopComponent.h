#pragma once
#include "../../Component/ComponentBase.h"

class IObjectBase;

class StopComponent:public ComponentBase
{
public:

	enum class STOP_TYPE
	{
		HITSTOP,
		ALLSTOP,
	};

	StopComponent(IObjectBase& owner);

	void UpdateBatch(void) override;

	void Stop(int stopFrame, STOP_TYPE type);

	bool IsStop(void);

	STOP_TYPE GetStopType(void);

private:

	int stopFrame_;
	int timer_;
	bool isStop_;
	STOP_TYPE type_;
};

