#include "GameScene.h"
#include "inGameScene/CityTrial/CityTrial.h"
#include "inGameScene/CityTrial/Result_CityTrial.h"
#include "inGameScene/JumpBattle/LongJumpBattle.h"

#include "../Manager/SceneManager.h"
#include "../Manager/UIManager.h"
#include "../Manager/Camera/Camera.h"
#include "../Object/Common/CollisionManager.h"
#include "Components/StopComponent.h"
#include "../Object/Interactable/Generator/InteractableGenerator.h"

GameScene::GameScene()
    : colMng_(CollisionManager::CreateInstance())
{
}

GameScene::~GameScene()
{
    colMng_.ClearCollider();
}

void GameScene::Init()
{
    LoadComponents();
    LoadInGameMode();

    InitUI();

    currentMode_ = INGAMEMODE::CITYTRIAL;
    inGame_[currentMode_]->Init();
}

void GameScene::InitUI()
{
    // �K�v��UI�������������
}

void GameScene::LoadComponents()
{
    new StopComponent(*this);
    new InteractableGenerator(*this, *this, *this);
}

void GameScene::LoadInGameMode()
{
    inGame_.emplace(INGAMEMODE::CITYTRIAL, std::make_unique<CityTrial>(*this, *this, *this));
    inGame_.emplace(INGAMEMODE::RESULT_CITY, std::make_unique<Result_CityTrial>(*this, *this, *this));
    inGame_.emplace(INGAMEMODE::JUMP_LONG, std::make_unique<LongJumpBattle>(*this,*this, *this));
}


void GameScene::Update()
{
    inGame_[currentMode_]->Update();

    AddRemoveActorUpdate();

	UIMng_.Update();
}

void GameScene::Draw()
{
    inGame_[currentMode_]->Draw();
	UIMng_.Draw();
}

void GameScene::AddActor(std::unique_ptr<ActorBase> actor, ActorCategory category)
{
    addActorsLater_[category].emplace_back(std::move(actor));
}

void GameScene::RemoveActor(ActorBase& actor)
{
    removeActorsLater_.emplace_back(&actor);
}

void GameScene::RemoveActor(ActorCategory category)
{
    removeCategoryLater_.emplace_back(category);
}

void GameScene::AddActorInit(std::unique_ptr<ActorBase> actor, ActorCategory category)
{
    activeActors_[category].emplace_back(std::move(actor));
}

void GameScene::AddRemoveActorUpdate()
{
    for (auto& actor : removeActorsLater_)
    {
        //  ����̃A�N�^�[���폜
        SceneBase::RemoveActor(*actor);
    }
    removeActorsLater_.clear();

    for (auto& cate : removeCategoryLater_)
    {
        //  ����̃J�e�S���[�̃A�N�^�[���폜
        SceneBase::RemoveActor(cate);
    }
    removeCategoryLater_.clear();

    for (auto& actors : addActorsLater_)
    {
        for (auto& actor : actors.second)
        {
            //  �z�����Actor��AddActor
            SceneBase::AddActor(std::move(actor), actors.first);
        }
        actors.second.clear();
    }
    addActorsLater_.clear();
}

void GameScene::NoticeEnd(void)
{
    inGame_[currentMode_]->Release();

    switch (currentMode_)
    {
    case INGAMEMODE::CITYTRIAL:
        currentMode_ = INGAMEMODE::RESULT_CITY;
        break;
    case INGAMEMODE::RESULT_CITY:
        currentMode_ = INGAMEMODE::JUMP_LONG;
        break;
    case INGAMEMODE::JUMP_LONG:
        SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::TITLE);
        return;
        break;
    default:
        break;
    }

    inGame_[currentMode_]->Init();
}

INGAMEMODE GameScene::GetMode(void)
{
    return currentMode_;
}
