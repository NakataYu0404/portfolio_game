#include "../Utility/Utility.h"
#include "../../GameScene.h"
#include "../Manager/Camera/Camera.h"
#include "../Object/Player/CharacterController.h"
#include "../Object/Stage/Stage.h"
#include "../Object/Stage/DashArea.h"
#include "../Object/Interactable/Generator/InteractableGenerator.h"
#include "../CommonUpdateLogics/CountDown3.h"
#include "../CityTrial/Update_CityTrial.h"
#include "../../PARAMATER_MODE/INGAMEMODE.h"
#include "CityTrial.h"

// CityTrial: �V�e�B�g���C�A���p�̃Q�[���V�[��
// �X�e�[�W�E�_�b�V���G���A�E�A�C�e�������E�v���C���[�������E�X�V�E�`��E�I������Ȃǂ�S��

CityTrial::CityTrial(GameScene& scene, INoticeEndGame& end, IGetInGameMode& getGameMode) : InGameBase(scene,end, getGameMode)
{
    
}

CityTrial::~CityTrial()
{
    delete gameLogic_[InGameLogicMode::UPDATE];
}

// ����������
void CityTrial::Init()
{

    LoadComponents();
    currentMode_ = InGameLogicMode::COUNTDOWN;
    GetComponent<CountDown3>()->Start(ActiveMode::MANUAL,COUNTEND_NEXTMODE::START,true);

    scene_.AddActorInit(std::make_unique<Stage>(INGAMEMODE::CITYTRIAL), ActorCategory::STAGE);
    scene_.AddActorInit(std::make_unique<DashArea>(VECTOR(0.0f,0.0f,0.0f), VECTOR(0.0f,0.0f,0.0f),DASHAREA_RADIUS,DASHAREA_MAXSPEED), ActorCategory::DASHAREA);   //  �}�W�b�N

    scene_.GetComponent<InteractableGenerator>()->Generate();

    scene_.AddActorInit(
        std::make_unique<CharacterController>(
            std::string(Utility::OBJECT_NAME::PLAYER_1),
            *SceneManager::GetInstance().GetCamera(),
            getGameMode_
        ), ActorCategory::PLAYER
    );

    if (!scene_.GetActor(ActorCategory::PLAYER).empty())
    {
        SceneManager::GetInstance().GetCamera()->SetFollow(
            scene_.GetActor(ActorCategory::PLAYER)[0]->GetTransform().lock().get()
        );
        SceneManager::GetInstance().GetCamera()->ChangeMode(CAMERA_MODE::FOLLOW_DRIVER);
    }

    for (auto& actors : scene_.GetActiveActors())
    {
        for (auto& actor : actors.second)
        {
            actor->Init();
        }
    }

}

// ���t���[���̍X�V����
void CityTrial::Update()
{
    for (auto& c : components_)
    {
        c->UpdateBatch();
    }

    gameLogic_[currentMode_]->Update();
}

// �`�揈��
void CityTrial::Draw()
{
    InGameBase::Draw(); // Actor�`��

    for (auto& c : components_)
    {
        c->DrawBatch();
    }

}

// �I�����̃��\�[�X�E�A�N�^�[���
void CityTrial::Release(void)
{
    // ColMng_���甲����GameScene���甲��
    for (auto& i : scene_.GetActor(ActorCategory::DASHAREA))
    {
        colMng_.Remove(*i);
    }
    for (auto& i : scene_.GetActor(ActorCategory::ITEM))
    {
        colMng_.Remove(*i);
    }
    for (auto& i : scene_.GetActor(ActorCategory::ITEM_BOX))
    {
        colMng_.Remove(*i);
    }
    for (auto& i : scene_.GetActor(ActorCategory::STAGE))
    {
        colMng_.Remove(*i);
    }
    scene_.RemoveActor(ActorCategory::DASHAREA);
    scene_.RemoveActor(ActorCategory::ITEM);
    scene_.RemoveActor(ActorCategory::ITEM_BOX);
    scene_.RemoveActor(ActorCategory::STAGE);
}

// �R���|�[�l���g������
void CityTrial::LoadComponents(void)
{
    new CountDown3(*this, *this,INGAMEMODE::CITYTRIAL);

    gameLogic_.emplace(InGameLogicMode::COUNTDOWN, GetComponent<CountDown3>());
    gameLogic_.emplace(InGameLogicMode::UPDATE, new Update_CityTrial(*this, *this));
}

// �Q�[���I���ʒm
void CityTrial::NoticeEnd(void)
{
    switch (currentMode_)
    {
    case InGameLogicMode::COUNTDOWN:
        currentMode_ = InGameLogicMode::UPDATE;
        break;
    case InGameLogicMode::UPDATE:
        end_.NoticeEnd(); 
        break;
    default:
        break;
    }
}

// �J�E���g�_�E���擾
CountDown3& CityTrial::GetCountDown(void)
{
    return *GetComponent<CountDown3>();
}
