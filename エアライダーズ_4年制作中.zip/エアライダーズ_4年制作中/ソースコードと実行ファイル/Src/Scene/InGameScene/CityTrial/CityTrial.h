#pragma once
#include "../InGameBase.h"

enum class ActorCategory;
class ActorBase;
class CountDown3;

class IGetActorInfo;

class IGetUpdateInfo_City : virtual public IGetActorInfo
{
public:
    virtual CountDown3& GetCountDown(void) = 0;
};

class CityTrial : public InGameBase , public IGetUpdateInfo_City
{
public:
    explicit CityTrial(GameScene& scene, INoticeEndGame& end, IGetInGameMode& getGameMode);
    ~CityTrial() override;

    void Init() override;
    void Update() override;
    void Draw() override;
    void Release(void) override;

    // --- �萔 ---
    static constexpr float DASHAREA_RADIUS = 60.0f;
    static constexpr float DASHAREA_MAXSPEED = 50.0f;

private:
    void LoadComponents(void) override;

    void NoticeEnd(void) override;

    CountDown3& GetCountDown(void) override;

    bool isFinished_ = false;

};