#include "../Manager/ResourceManager.h"
#include "UIResultParam.h"

UIResultParam::UIResultParam()
{
}

UIResultParam::~UIResultParam()
{
}

void UIResultParam::Init(void)
{
	imgMeterB_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::IMG_RESULT_CITY_METER_B).handleId_;
	imgMeterR_= ResourceManager::GetInstance().Load(ResourceManager::SRC::IMG_RESULT_CITY_METER_R).handleId_;
	imgBack_= ResourceManager::GetInstance().Load(ResourceManager::SRC::IMG_RESULT_CITY_BACK).handleId_;

}

void UIResultParam::Update(void)
{
}

void UIResultParam::Draw(void)
{
	DrawGraph(0, 0, imgBack_, true);
}
