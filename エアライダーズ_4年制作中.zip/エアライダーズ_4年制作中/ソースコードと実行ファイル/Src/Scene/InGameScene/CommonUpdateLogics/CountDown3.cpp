#include <DxLib.h>
#include "../Manager/SceneManager.h"
#include "../Manager/UIManager.h"
#include "../InGameBase.h"
#include "../../../UI/UICountDown.h"
#include "../../PARAMATER_MODE/INGAMEMODE.h"
#include "CountDown3.h"

CountDown3::CountDown3(INoticeEnd& noticeF, IObjectBase& owner, INGAMEMODE mode)
    : ComponentBase(owner), InGameLogicBase(), noticeFunc_(noticeF), currentCount_(5),
	prevCount_(5), elapsedTime_(0.0f), durationPerCount_(1.0f), gameMode_(mode)
{
	uiCountDown_ = std::make_shared<UICountDown>(*this, gameMode_);
	UIManager::GetInstance().AddUI(uiCountDown_);
}

void CountDown3::Start(ActiveMode mode, COUNTEND_NEXTMODE endMode, bool BeforeReady)
{
    if (BeforeReady)
    {
        currentCount_ = 5;
        prevCount_ = 5;
    }
    else
    {
        currentCount_ = 3;
        prevCount_ = 3;
	}

    elapsedTime_ = 0.0f;
    isActive_ = mode;
    uiCountDown_->SetVisible(true);
    endMode_ = endMode;
}

// ���t���[���̍X�V����
void CountDown3::Update()
{
    if (isActive_ == ActiveMode::NONE) return;

    elapsedTime_ += SceneManager::GetInstance().GetDeltaTime();

    if (elapsedTime_ >= durationPerCount_)
    {
        elapsedTime_ = 0.0f;
        prevCount_ = currentCount_;
        currentCount_--;

        if (currentCount_ < 0)
        {
            isActive_ = ActiveMode::NONE;
			uiCountDown_->SetVisible(false); // UI���\���ɂ���
            noticeFunc_.NoticeEnd();
        }
    }
}

// �o�b�`���[�h�p�X�V����
void CountDown3::UpdateBatch(void)
{
    if (isActive_ != ActiveMode::BATCH) return;

    Update();
}

// �J�E���g�_�E���`�揈��
void CountDown3::DrawBatch()
{
    if (isActive_ == ActiveMode::NONE) return;

    if (currentCount_ > 0)
    {
        DrawFormatString(DRAW_POS_X, DRAW_POS_Y, GetColor(DRAW_COLOR_R, DRAW_COLOR_G, DRAW_COLOR_B), "%d", currentCount_);
    }
    else
    {
        DrawFormatString(DRAW_POS_X, DRAW_POS_Y, GetColor(DRAW_COLOR_R, DRAW_COLOR_G, DRAW_COLOR_B), "GO!");
    }

}

int CountDown3::GetCurrentCount() const
{
    return currentCount_;
}

COUNTEND_NEXTMODE CountDown3::GetEndMode() const
{
    return endMode_;
}
