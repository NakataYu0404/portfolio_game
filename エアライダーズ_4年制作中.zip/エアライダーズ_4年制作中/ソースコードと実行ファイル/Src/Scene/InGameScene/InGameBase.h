#pragma once  
#include <memory>  
#include <unordered_map>  
#include "../Object/ActorBase.h"  
#include "../Common/ObjectBase.h"  
#include "../Object/Common/ActorCategory.h"  
#include "../Object/Common/CollisionManager.h"  
#include "CommonUpdateLogics/InGameLogicBase.h"  
#include "../PARAMATER_MODE/InGameLogicMode.h"  

class GameScene;  
class CollisionManager;  

class INoticeEndGame;  

class IGetInGameMode;  

class InGameLogicBase;  

class INoticeEnd  
{  
public:  
    virtual void NoticeEnd(void) = 0;  
};  

class IGetActorInfo  
{  
public:  
    virtual const std::unordered_map<ActorCategory, std::vector<std::unique_ptr<ActorBase>>>& GetActors(void) const = 0;  
};  

class InGameBase : public ObjectBase, public INoticeEnd, virtual public IGetActorInfo
{  
public:  
    InGameBase(GameScene& scene, INoticeEndGame& end, IGetInGameMode& getGameMode);  
    virtual ~InGameBase() = default;  

    virtual void Init();  
    virtual void Update();  
    virtual void Draw();  
    virtual void Release();  

protected:  

    virtual void LoadComponents(void);  

    virtual void NoticeEnd(void) override;  

    const std::unordered_map<ActorCategory, std::vector<std::unique_ptr<ActorBase>>>& GetActors(void) const override;  

    std::unordered_map<InGameLogicMode, InGameLogicBase*> gameLogic_;  
    InGameLogicMode currentMode_ = InGameLogicMode::NONE;  

    GameScene& scene_;  
    CollisionManager& colMng_;  
    INoticeEndGame& end_;  

    IGetInGameMode& getGameMode_;  
};
