#include "../Manager/ResourceManager.h"
#include "DrawResultJump.h"
#include <vector>
#include <algorithm>
#include <cmath>

DrawResultJump::DrawResultJump(){}

DrawResultJump::DrawResultJump(VECTOR pos) :DrawResultJump()
{
    goalPosZ_ = (int)pos.z;
}

DrawResultJump::~DrawResultJump()
{
}

void DrawResultJump::Init(void)
{
    ResourceManager& resMng = ResourceManager::GetInstance();
    for (int a = 0; a < 10; a++)
    {
        ResourceManager::SRC src = static_cast<ResourceManager::SRC>(static_cast<int>(ResourceManager::SRC::IMG_0_R) + a);
        numHdl_[a] = resMng.Load(src).handleId_;
    }

    backHdl_ = resMng.Load(ResourceManager::SRC::IMG_RESULT_JUMP).handleId_;

	posZ_ = 0;
}

void DrawResultJump::Update(void)
{

    if (posZ_ < goalPosZ_)
    {
        posZ_ += goalPosZ_ / 300;
    }
    else
    {
        posZ_ = goalPosZ_;
    }

    DrawFormatString(0, 40, GetColor(255, 255, 255), "Result: %.f", goalPosZ_);
}

void DrawResultJump::Draw(void)
{
    DrawGraph(0, 0, backHdl_, true);

    // posZ_��10�i���̊e���ɕ���
    int value = std::abs(posZ_);
    std::vector<int> digits;

    // �����𑵂���i��F5���\���j
    const int keta = 5;
    for (int i = 0; i < keta; ++i) {
        digits.push_back(value % 10);
        value /= 10;
    }
    std::reverse(digits.begin(), digits.end());

    // ���������ɕ��ׂĕ`��i��F1����40px�j
    int x = 700;
    const int digitWidth = 40;
    for (int d : digits) {
        DrawGraph(x, 500, numHdl_[d], true);
        x += digitWidth;
    }
}