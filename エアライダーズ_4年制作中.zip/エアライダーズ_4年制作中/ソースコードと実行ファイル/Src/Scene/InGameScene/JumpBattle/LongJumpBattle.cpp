#include "../Utility/Utility.h"
#include "../Manager/ResourceManager.h"
#include "../../GameScene.h"
#include "../Object/Stage/Stage.h"
#include "../Object/Stage/DashArea.h"
#include "../Object/Interactable/Generator/InteractableGenerator.h"
#include "../CommonUpdateLogics/CountDown3.h"
#include "Update_LongJumpBattle.h"
#include "Result_LongJumpBattle.h"
#include "../Object/Stage/JumpGame_Land.h"
#include "../../PARAMATER_MODE/INGAMEMODE.h"
#include "LongJumpBattle.h"

// LongJumpBattle: �W�����v�o�g���p�̃Q�[���V�[��
// �X�e�[�W�E�_�b�V���G���A�E�v���C���[�������E�X�V�E�`��E�I������Ȃǂ�S��

LongJumpBattle::LongJumpBattle(GameScene& scene, INoticeEndGame& end, IGetInGameMode& getGameMode) : InGameBase(scene,end, getGameMode)
{
}

LongJumpBattle::~LongJumpBattle()
{
    // CountDown3 �͍폜���Ȃ��I�icomponents_�����L�j
    delete gameLogic_[InGameLogicMode::UPDATE];
    delete gameLogic_[InGameLogicMode::RESULT];

    gameLogic_.clear();
}

void LongJumpBattle::Init()
{
    LoadComponents();
    currentMode_ = InGameLogicMode::COUNTDOWN;
    GetComponent<CountDown3>()->Start(ActiveMode::MANUAL,COUNTEND_NEXTMODE::START,true);


    scene_.AddActorInit(std::make_unique<Stage>(INGAMEMODE::JUMP_LONG), ActorCategory::STAGE);
    scene_.AddActorInit(std::make_unique<DashArea>(VECTOR(0, 800, 0), VECTOR(0, 300, -500), 600.0f, 200.0f), ActorCategory::DASHAREA);
    
    for (int i = 0; auto & actor : scene_.GetActor(ActorCategory::PLAYER))
    {
        actor->SetPos({ 0,0.0f,-4000.0f });
        actor->GetTransform().lock()->quaRot = Quaternion();
        i++;
    }


    for (auto & a : scene_.GetActiveActors())
    {
        for (auto& b : a.second)
        {
            b->GetTransform().lock()->pos.y += ACTOR_POS_Y_OFFSET;
            b->GetTransform().lock()->Update();
        }
    }

    scene_.AddActorInit(std::make_unique<JumpGame_Land>(INGAMEMODE::JUMP_LONG), ActorCategory::STAGE);
}

// ���t���[���̍X�V����
void LongJumpBattle::Update()
{
    for (auto& c : components_)
    {
        c->UpdateBatch();
    }

    gameLogic_[currentMode_]->Update();

}

void LongJumpBattle::Draw()
{
    InGameBase::Draw(); // Actor�`��
}

void LongJumpBattle::LoadComponents(void)
{
    new CountDown3(*this, *this,INGAMEMODE::JUMP_LONG);

    gameLogic_.emplace(InGameLogicMode::COUNTDOWN, GetComponent<CountDown3>());
    gameLogic_.emplace(InGameLogicMode::UPDATE, new Update_LongJumpBattle(*this, *this));
    gameLogic_.emplace(InGameLogicMode::RESULT, new Result_LongJumpBattle(*this, *this));
}

void LongJumpBattle::NoticeEnd(void)
{
    switch (currentMode_)
    {
    case InGameLogicMode::COUNTDOWN:
        currentMode_ = InGameLogicMode::UPDATE;
        gameLogic_[currentMode_]->Enter();
        break;
    case InGameLogicMode::UPDATE:
        currentMode_ = InGameLogicMode::RESULT;
        gameLogic_[currentMode_]->Enter();
        break;
    case InGameLogicMode::RESULT:
        end_.NoticeEnd();
        break;
    default:
        break;
	}

}

const std::vector<ActorBase*> LongJumpBattle::GetActor(ActorCategory category)
{
    return scene_.GetActor(category);
}

CountDown3& LongJumpBattle::GetCountDown(void)
{
    return *GetComponent<CountDown3>();
}
