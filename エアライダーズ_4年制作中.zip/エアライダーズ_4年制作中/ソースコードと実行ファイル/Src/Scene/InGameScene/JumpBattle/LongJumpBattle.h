#pragma once
#include <memory>
#include "../InGameBase.h"

class INoticeEndGame;
class IGetActorInfo;
class CountDown3;

class IGetUpdateInfo_LJump : virtual public IGetActorInfo
{
public:
    virtual const std::vector<ActorBase*> GetActor(ActorCategory category) = 0;
    virtual CountDown3& GetCountDown(void) = 0;
};

class LongJumpBattle : public InGameBase, public IGetUpdateInfo_LJump
{
public:
    LongJumpBattle(GameScene& scene, INoticeEndGame& end, IGetInGameMode& getGameMode);
    ~LongJumpBattle() override;

    void Init() override;
    void Update() override;
    void Draw() override;

    // --- �萔 ---
    static constexpr float DASHAREA_RADIUS = 600.0f;
    static constexpr float DASHAREA_MAXSPEED = 200.0f;
    static constexpr float PLAYER_INIT_POS_Y = 4000.0f;
    static constexpr float PLAYER_INIT_POS_Z = -4000.0f;
    static constexpr float ACTOR_POS_Y_OFFSET = 8000.0f;
    static constexpr float PLAYER_POS_Y_THRESHOLD = 0.5f;
    static constexpr int INIT_X = 10;
    static constexpr int PLAYER_POS_X = 0;
    static constexpr int PLAYER_POS_Z = 0;
    static constexpr int DASHAREA_POS1_Y = 800;
    static constexpr int DASHAREA_POS2_Y = 300;
    static constexpr int DASHAREA_POS2_Z = -500;

private:
    void LoadComponents(void) override;

    void NoticeEnd(void) override;

    const std::vector<ActorBase*> GetActor(ActorCategory category) override;
    CountDown3& GetCountDown(void) override;

    bool isFinished_ = false;

    int x = 10;
};