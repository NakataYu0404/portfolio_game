#include "../Manager/InputManager.h"
#include "../Manager/UIManager.h"
#include "LongJumpBattle.h"
#include "../CommonUpdateLogics/CountDown3.h"
#include "DrawResultJump.h"
#include "Result_LongJumpBattle.h"

Result_LongJumpBattle::Result_LongJumpBattle(INoticeEnd& noticeF, IGetUpdateInfo_LJump& getInfoF)
    : noticeFunc_(noticeF)
    , getInfoFunc_(getInfoF)
{

}

void Result_LongJumpBattle::Enter()
{
	UIManager::GetInstance().AddUI(std::make_shared<DrawResultJump>(getInfoFunc_.GetActor(ActorCategory::PLAYER)[0]->GetTransform().lock()->pos));
}

void Result_LongJumpBattle::Update()
{
    if (InputManager::GetInstance().IsPress(KEY_INPUT_SPACE)) {
        noticeFunc_.NoticeEnd();
    }
}