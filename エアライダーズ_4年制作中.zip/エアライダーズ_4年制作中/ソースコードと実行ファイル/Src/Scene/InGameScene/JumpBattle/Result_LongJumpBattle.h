#pragma once
#include <memory>
#include "../CommonUpdateLogics/InGameLogicBase.h"

class INoticeEnd;
class IGetUpdateInfo_LJump;

class Result_LongJumpBattle : public InGameLogicBase
{
public:
    Result_LongJumpBattle(INoticeEnd& noticeF, IGetUpdateInfo_LJump& getInfoF);

    void Enter() override;
    void Update() override;

private:

    INoticeEnd& noticeFunc_;
    IGetUpdateInfo_LJump& getInfoFunc_;

};