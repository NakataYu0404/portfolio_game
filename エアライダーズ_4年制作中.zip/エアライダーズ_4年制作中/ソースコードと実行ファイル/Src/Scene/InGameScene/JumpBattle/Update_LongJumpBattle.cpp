#include "../Object/Common/CollisionManager.h"
#include "LongJumpBattle.h"
#include "../CommonUpdateLogics/CountDown3.h"
#include "Update_LongJumpBattle.h"


Update_LongJumpBattle::Update_LongJumpBattle(INoticeEnd& noticeF, IGetUpdateInfo_LJump& getInfoF) : noticeFunc_(noticeF), getInfoFunc_(getInfoF), colMng_(CollisionManager::GetInstance()) {}

void Update_LongJumpBattle::Update()
{
    // InGameBase ���� Actor �X�V
	for (auto& actors : getInfoFunc_.GetActors())
    {
        for (auto& actor : actors.second)
        {
            actor->Update();
        }
    }

    colMng_.Update();

    for (auto& p : getInfoFunc_.GetActor(ActorCategory::PLAYER))
    {
        VECTOR pos = p->GetTransform().lock()->pos;
        if (pos.y <= 0.5f)
        {
            jumpEndCount_--;
        }
        else
        {
            jumpEndCount_ = JUMP_END_COUNT;
        }
        if (jumpEndCount_ <= 0)
        {
            noticeFunc_.NoticeEnd();
        }
    }
}

