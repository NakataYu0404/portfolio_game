#pragma once
#include "../CommonUpdateLogics/InGameLogicBase.h"

class INoticeEnd;
class IGetUpdateInfo_LJump;
class CollisionManager;

class Update_LongJumpBattle : public InGameLogicBase
{
public:
    Update_LongJumpBattle(INoticeEnd& noticeF, IGetUpdateInfo_LJump& getInfoF);

    void Update() override;

private:
    INoticeEnd& noticeFunc_;
    IGetUpdateInfo_LJump& getInfoFunc_;

    CollisionManager& colMng_;

	static constexpr int JUMP_END_COUNT = 10;

    int jumpEndCount_ = JUMP_END_COUNT;
};