#pragma once

enum class INGAMEMODE
{
    CITYTRIAL,
    RESULT_CITY,
    JUMP_LONG,
};
