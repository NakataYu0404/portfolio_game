#include "../Manager/ResourceManager.h"
#include "../Manager/UIManager.h"
#include "../Object/Common/CollisionManager.h"
#include "SceneBase.h"

SceneBase::SceneBase(void) : resMng_(ResourceManager::GetInstance()), UIMng_(UIManager::CreateInstance())
{
}

SceneBase::~SceneBase()
{
}

void SceneBase::SetPlayerNum(SceneManager::PLNUM num)
{
	plNum_ = num;
}

void SceneBase::AddActor(std::unique_ptr<ActorBase> actor, ActorCategory category)
{
	actor->Init();
	activeActors_[category].emplace_back(std::move(actor));
}

const std::vector<ActorBase*> SceneBase::GetActor(ActorCategory category)
{
	std::vector<ActorBase*> actors;
	for (auto& a : activeActors_)
	{
		if (a.first != category) continue;

		for (auto& b : a.second)
		{
			actors.emplace_back(b.get());
		}

	}
	return actors;
}

void SceneBase::RemoveActor(ActorBase& actor)
{
	for (auto& [category, vec] : activeActors_)
	{
		auto it = std::remove_if(vec.begin(), vec.end(),
			[&](const std::unique_ptr<ActorBase>& ptr) {
				return ptr.get() == &actor;
			});
		if (it != vec.end()) {
			vec.erase(it, vec.end());
			vec.shrink_to_fit();
			break;
		}
	}
}

void SceneBase::RemoveActor(ActorCategory category)
{
	for (auto& [cate, vec] : activeActors_)
	{
		if (cate != category) continue;

		vec.clear();
	}
}
