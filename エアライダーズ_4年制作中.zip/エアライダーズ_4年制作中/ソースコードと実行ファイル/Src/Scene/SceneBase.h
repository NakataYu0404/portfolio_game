#pragma once
#include<memory>
#include <functional>
#include "../Common/ObjectBase.h"
#include "../Manager/SceneManager.h"
#include "../Object/ActorBase.h"
#include "../Object/Common/ActorCategory.h"

class ResourceManager;
class UIManager;
class ActorBase;

class ActorAddInterface
{
public:
	virtual void AddActor(std::unique_ptr<ActorBase> actor, ActorCategory category) = 0;
};

class ActorGetInterface
{
public:
	virtual const std::vector<ActorBase*> GetActor(ActorCategory category) = 0;
};

class ActorRemoveInterface
{
public:
	virtual void RemoveActor(ActorBase& actor) = 0;
	virtual void RemoveActor(ActorCategory category) = 0;
};

class SceneBase : public ObjectBase,public ActorAddInterface,public ActorGetInterface, public ActorRemoveInterface
{

public:

	//	�R���X�g���N�^
	SceneBase(void);

	//	�f�X�g���N�^
	virtual ~SceneBase(void) = 0;

	//	������
	virtual void Init(void) = 0;
	virtual void InitUI(void) = 0;

	//	�X�V
	virtual void Update(void) = 0;

	//	�`��
	virtual void Draw(void) = 0;


	void SetPlayerNum(SceneManager::PLNUM num);

	const std::vector<ActorBase*> GetActor(ActorCategory category) override;

protected:

	//	�A�N�^�[�̒ǉ�
	void AddActor(std::unique_ptr<ActorBase> actor, ActorCategory category) override;


	void RemoveActor(ActorBase& actor) override;
	void RemoveActor(ActorCategory category) override;

	//	�������addActor���邽�߂̔z��
	std::unordered_map<ActorCategory, std::vector<std::unique_ptr<ActorBase>>> addActorsLater_;
	std::vector<ActorBase*> removeActorsLater_;
	std::vector<ActorCategory> removeCategoryLater_;

	//	�A�N�^�[
	std::unordered_map<ActorCategory, std::vector<std::unique_ptr<ActorBase>>> activeActors_;

	//	���\�[�X�}�l�[�W���[
	ResourceManager& resMng_;

	//	UI�}�l�[�W���[
	UIManager& UIMng_;

	SceneManager::PLNUM plNum_;
};
