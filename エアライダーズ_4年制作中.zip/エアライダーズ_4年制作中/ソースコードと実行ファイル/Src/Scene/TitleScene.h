#pragma once
#include "SceneBase.h"
#include "../Object/Common/Transform.h"
class SceneManager;
class SkyDome;


class TitleScene : public SceneBase
{

public:

	//	�R���X�g���N�^
	TitleScene(void);

	//	�f�X�g���N�^
	~TitleScene(void);

	void Init(void) override;
	void InitUI(void) override;
	void Update(void) override;
	void Draw(void) override;

	// --- �萔 ---
	static constexpr int SCREEN_CENTER_Y = 300;
	static constexpr int PUSH_KEY_Y = 700;
	static constexpr float DRAW_SCALE = 1.0f;
	static constexpr float DRAW_ROT = 0.0f;
	static constexpr int CNT_MOD = 30;
	static constexpr int CNT_THRESHOLD = 20;
	static constexpr int ABANDONED_TIMER_INIT = 1800;
	static constexpr float INIT_PAD_STICK_Y = 0.0f;
	static constexpr float PLAYER_INPUT_STICK_THRESHOLD = 0.01f;
	static constexpr int PLAYER_INIT_X = 0;
	static constexpr int PLAYER_INIT_Y = 0;

private:

	enum class InScene
	{
		PUSHKEY,
		PLNUMSELECT,
	};

	SceneManager::PLNUM plnum_;
	InScene inScene_;

	float oldPadStickY_;

	int imgTitleHdl_;
	int imgPushHdl_;

	int imgEveryone_;
	int imgSolo_;

	int cnt_;
	int abandonedTimer_;

};
