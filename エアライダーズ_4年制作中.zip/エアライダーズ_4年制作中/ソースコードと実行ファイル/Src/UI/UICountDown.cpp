#include <DxLib.h>
#include "../Scene/InGameScene/CommonUpdateLogics/CountDown3.h"
#include "../Scene/PARAMATER_MODE/INGAMEMODE.h"
#include "UICountDown.h"

UICountDown::UICountDown(const IGetCountDownFunc& countDown, INGAMEMODE gameMode) : UIBase(), countDown_(countDown),resMng_(ResourceManager::GetInstance()), gameMode_(gameMode)
{
    zBuffer_ = ZBuffer::FRONT; // �`�揇���őO�ʂɐݒ�
    isVisible_ = true; // ������Ԃŕ\��

    for (auto& i : numImgs_)
    {
        i = -1; // ������
    }
}

void UICountDown::Init()
{
    LoadImages();
}

void UICountDown::Update()
{
}

void UICountDown::Draw()
{
    int count = countDown_.GetCurrentCount();
    int handle = -1;
    if (count > 0 && count <= 3)
    {
        handle = numImgs_[3 - count];
    }
    else if (count <= 0)
    {
        if (countDown_.GetEndMode() == COUNTEND_NEXTMODE::START)
        {
            handle = endImg_[0];
        }
        else
        {
            handle = endImg_[1];
        }
    }
    else
    {
        //  �Q�[�����[�h����ready
        handle = readyImg_;
    }

    if (handle != -1)
    {
        DrawGraph(0, 0, handle, TRUE);
    }

}

void UICountDown::LoadImages(void)
{
	numImgs_[0] = resMng_.Load(ResourceManager::SRC::IMG_3_R).handleId_; // 3
	numImgs_[1] = resMng_.Load(ResourceManager::SRC::IMG_2_R).handleId_; // 2
	numImgs_[2] = resMng_.Load(ResourceManager::SRC::IMG_1_R).handleId_; // 1

    switch (gameMode_)
    {
    case INGAMEMODE::CITYTRIAL:
        readyImg_ = resMng_.Load(ResourceManager::SRC::IMG_READY_CITY).handleId_;

        break;
    case INGAMEMODE::JUMP_LONG:
        readyImg_ = resMng_.Load(ResourceManager::SRC::IMG_READY_LJUMP).handleId_;

        break;
    }

    endImg_[0] = resMng_.Load(ResourceManager::SRC::IMG_START).handleId_;
    endImg_[1] = resMng_.Load(ResourceManager::SRC::IMG_READY).handleId_;
}
