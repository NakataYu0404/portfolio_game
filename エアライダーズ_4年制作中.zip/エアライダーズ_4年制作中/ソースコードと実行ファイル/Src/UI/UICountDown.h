#pragma once
#include "UIBase.h"
#include "../Manager/ResourceManager.h"
#include <array>

class IGetCountDownFunc;
enum class INGAMEMODE;

class UICountDown : public UIBase
{
public:
    UICountDown(const IGetCountDownFunc& countDown, INGAMEMODE gameMode);

    void Init() override;
    void Update() override;
    void Draw() override;

private:

    enum class TYPE_START
    {
		CITYTRIAL,
		LONGJUMP,
	};
    enum class TYPE_END
    {
        
	};
    void LoadImages(void);

    const IGetCountDownFunc& countDown_;
    std::array<int, 3> numImgs_;
    int readyImg_ = -1;
    int endImg_[2];

    INGAMEMODE gameMode_;

    ResourceManager& resMng_;
};