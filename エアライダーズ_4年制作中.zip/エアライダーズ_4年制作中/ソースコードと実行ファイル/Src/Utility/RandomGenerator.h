#pragma once
#include <random>
#include <cmath>

class RandomGenerator {
public:
    RandomGenerator();

    int GetRandomNum(int min = 0,int max = 0);
    float GetRandomNumf(float min, float max, int precision = 1);

    // --- �萔 ---
    static constexpr float POW_BASE = 10.0f;

private:
    std::mt19937 gen_;
};

