#pragma once
#include <string>
#include <vector>
#include <DxLib.h>
#include "../Common/Vector2.h"
#include "../Common/Vector2F.h"
#include "../Common/Quaternion.h"

class RandomGenerator;

class Utility
{

public:

	struct OBJECT_NAME
	{
		static constexpr std::string_view PLAYER_1 = "player1";
		static constexpr std::string_view PLAYER_2 = "player2";
		static constexpr std::string_view PLAYER_3 = "player3";
		static constexpr std::string_view PLAYER_4 = "player4";
		static constexpr std::string_view STAGE = "stage";
	};

	//	���W�A��(rad)�E�x(deg)�ϊ��p
	static constexpr float RAD2DEG = (180.0f / DX_PI_F);
	static constexpr float DEG2RAD = (DX_PI_F / 180.0f);

	static constexpr VECTOR VECTOR_ZERO = { 0.0f, 0.0f, 0.0f };
	static constexpr VECTOR VECTOR_ONE = { 1.0f, 1.0f, 1.0f };

	//	��]��
	static constexpr VECTOR AXIS_X = { 1.0f, 0.0f, 0.0f };
	static constexpr VECTOR AXIS_Y = { 0.0f, 1.0f, 0.0f };
	static constexpr VECTOR AXIS_Z = { 0.0f, 0.0f, 1.0f };

	//	����
	static constexpr VECTOR DIR_F = { 0.0f, 0.0f, 1.0f };
	static constexpr VECTOR DIR_B = { 0.0f, 0.0f, -1.0f };
	static constexpr VECTOR DIR_R = { 1.0f, 0.0f, 0.0f };
	static constexpr VECTOR DIR_L = { -1.0f, 0.0f, 0.0f };
	static constexpr VECTOR DIR_U = { 0.0f, 1.0f, 0.0f };
	static constexpr VECTOR DIR_D = { 0.0f, -1.0f, 0.0f };

	static constexpr float ROT_QUARTER_DEG = 90.0f;
	static constexpr float ROT_HALF_DEG = 180.0f;
	static constexpr VECTOR POS_FARAWAY = { -9999.9f,-9999.9f,-9999.9f };

	static constexpr float kEpsilonNormalSqrt = 1e-15F;

	static constexpr int GAME_FRAMERATE = 60;
	static constexpr int ROUND_COUNT = 99;

	//	360�x�������W�����ɕ��������̂��ꂼ��̌���
	static constexpr std::pair<float, float> SEPARETE_STICK8_U = { 337.5f, 22.5f };   // ��
	static constexpr std::pair<float, float> SEPARETE_STICK8_UR = { 22.5f, 67.5f };    // �E��
	static constexpr std::pair<float, float> SEPARETE_STICK8_R = { 67.5f, 112.5f };   // �E
	static constexpr std::pair<float, float> SEPARETE_STICK8_DR = { 112.5f, 157.5f };  // �E��
	static constexpr std::pair<float, float> SEPARETE_STICK8_D = { 157.5f, 202.5f };  // ��
	static constexpr std::pair<float, float> SEPARETE_STICK8_DL = { 202.5f, 247.5f };  // ����
	static constexpr std::pair<float, float> SEPARETE_STICK8_L = { 247.5f, 292.5f };  // ��
	static constexpr std::pair<float, float> SEPARETE_STICK8_UL = { 292.5f, 337.5f };  // ����

	static constexpr float CIRCLE = 360.0f;

	//	�����_���Ȑ����擾
	static int GetRandomNum(int min ,int max);

	//	precision = �����_�扽�ʂ܂łƂ邩�B1����0.1�A2����0.11
	static float GetRandomNumf(float min ,float max,float precision = 1);

	static float ClampAngleRad(float angle);

	static float VSizeSq(const VECTOR& vec);

	//	�l�̌ܓ�
	static int Round(float v);

	//	10,100����1
	static float ScaleDownTen(float i);
	static float ScaleDownHundled(float i);
	static int ScaleDownTen(int i);
	static int ScaleDownHundled(int i);

	//	10,100����1�]��
	static int ModuleTen(int i);
	static int ModuleHundled(int i);

	//	������̕���
	static std::vector <std::string> Split(std::string& line, char delimiter);

	//	���W�A��(rad)����x(deg)
	static float Rad2DegD(float rad);
	static float Rad2DegF(float rad);
	static int Rad2DegI(int rad);

	//	�x(deg)���烉�W�A��(rad)
	static float Deg2RadD(float deg);
	static float Deg2RadF(float deg);
	static int Deg2RadI(int deg);

	//	0�`360�x�͈̔͂Ɏ��߂�
	static float DegIn360(float deg);

	//	0(0)�`2��(360�x)�͈̔͂Ɏ��߂�
	static float RadIn2PI(float rad);

	//	��]�����Ȃ����̉�]�������擾����(���v���:1�A�����v���:-1)
	static int DirNearAroundRad(float from, float to);
	
	//	��]�����Ȃ����̉�]�������擾����(���v���:1�A�����v���:-1)
	static int DirNearAroundDeg(float from, float to);
	
	//	���`���
	static int Lerp(int start, int end, float t);
	static double Lerp(double start, double end, double t);
	static float Lerp(float start, float end, float t);
	static Vector2 Lerp(const Vector2& start, const Vector2& end, float t);
	static VECTOR Lerp(const VECTOR& start, const VECTOR& end, float t);

	//	�p�x�̐��`���
	static float LerpDeg(float start, float end, float t);

	//	�F�̐��`���
	static COLOR_F Lerp(const COLOR_F& start, const COLOR_F& end, float t);

	//	�x�W�F�Ȑ�
	static Vector2 Bezier(const Vector2& p1, const Vector2& p2, const Vector2& p3, float t);
	static VECTOR Bezier(const VECTOR& p1, const VECTOR& p2, const VECTOR& p3, float t);
	
	//	Y����]
	static VECTOR RotXZPos(const VECTOR& centerPos, const VECTOR& radiusPos, float rad);

	//	�x�N�g���̒���
	static float Magnitude(const Vector2& v);
	static float Magnitude(const VECTOR& v);
	static float MagnitudeF(const VECTOR& v);
	static int SqrMagnitude(const Vector2& v);
	static float SqrMagnitudeF(const VECTOR& v);
	static float SqrMagnitude(const VECTOR& v);
	static float SqrMagnitude(const VECTOR& v1, const VECTOR& v2);
	static float Distance(const Vector2& v1, const Vector2& v2,bool doFabsf = false);
	static float Distance(const VECTOR& v1, const VECTOR& v2, bool doFabsf = false);

	static VECTOR DistanceV(const VECTOR& v1, const VECTOR& v2, bool doFabsf = false);

	//	���̓��m�̏Փ˔���
	static bool IsHitSpheres(
		const VECTOR& pos1, float radius1, const VECTOR& pos2, float radius2);

	//	���̂ƃJ�v�Z���̏Փ˔���
	static bool IsHitSphereCapsule(
		const VECTOR& sphPos, float sphRadius, 
		const VECTOR& capPos1, const VECTOR& capPos2, float capRadius);

	//	��r
	static bool Equals(const VECTOR& v1, const VECTOR& v2);
	static bool EqualsVZero(const VECTOR& v1);

	//	���K��
	static VECTOR Normalize(const Vector2& v);
	static VECTOR VNormalize(const VECTOR& v);

	static VECTOR VDiv(const VECTOR& v, const float i);
	static VECTOR VDiv(const VECTOR& v, const VECTOR v2);

	//	2�̃x�N�g���̊Ԃ̊p�x
	static float AngleDeg(const VECTOR& from, const VECTOR& to);

	//	�`��n
	static void DrawLineDir(const VECTOR& pos, const VECTOR& dir, int color, float len = 50.0f);
	static void DrawLineXYZ(const VECTOR& pos, const MATRIX& rot, float len = 50.0f);
	static void DrawLineXYZ(const VECTOR& pos, const Quaternion& rot, float len = 50.0f);

	static RandomGenerator randGen_;
};

