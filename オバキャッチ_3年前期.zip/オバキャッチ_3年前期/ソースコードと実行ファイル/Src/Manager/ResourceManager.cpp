#include <DxLib.h>
#include "../Application.h"
#include "Resource.h"
#include "ResourceManager.h"

ResourceManager* ResourceManager::instance_ = nullptr;

void ResourceManager::CreateInstance(void)
{
	if (instance_ == nullptr)
	{
		instance_ = new ResourceManager();
	}
	instance_->Init();
}

ResourceManager& ResourceManager::GetInstance(void)
{
	return *instance_;
}

void ResourceManager::Init(void)
{
	using RES = Resource;
	using RES_T = RES::TYPE;
	static std::string PATH_IMG = Application::PATH_IMAGE;
	static std::string PATH_MDL = Application::PATH_MODEL;
	static std::string PATH_EFF = Application::PATH_EFFECT;
	static std::string PATH_SND = Application::PATH_SOUND;

	Resource* res;
	
	//	�^�C�g���摜
	res = new RES(RES_T::IMG, PATH_IMG + "-1");
	resourcesMap_.emplace(SRC::IMG_NONE, res);
	res = new RES(RES_T::IMG, PATH_MDL + "-1");
	resourcesMap_.emplace(SRC::MDL_NONE, res);
	res = new RES(RES_T::IMG, PATH_EFF + "-1");
	resourcesMap_.emplace(SRC::EFF_NONE, res);

	//	�^�C�g���摜
	res = new RES(RES_T::IMG, PATH_IMG + "Title/Title.png");
	resourcesMap_.emplace(SRC::IMG_TITLE, res);

	res = new RES(RES_T::IMG, PATH_IMG + "Title/hitoride.png");
	resourcesMap_.emplace(SRC::IMG_TITLE_HITORI, res);

	res = new RES(RES_T::IMG, PATH_IMG + "Title/minnnade.png");
	resourcesMap_.emplace(SRC::IMG_TITLE_MINNNA, res);

	res = new RES(RES_T::IMG, PATH_IMG + "heartpink.png");
	resourcesMap_.emplace(SRC::IMG_HEART_PINK, res);

	res = new RES(RES_T::IMG, PATH_IMG + "heartgray.png");
	resourcesMap_.emplace(SRC::IMG_HEART_GRAY, res);
	
	res = new RES(RES_T::IMG, PATH_IMG + "battery.png");
	resourcesMap_.emplace(SRC::IMG_BATTERY, res);
	
	res = new RES(RES_T::IMG, PATH_IMG + "batteryRed.png");
	resourcesMap_.emplace(SRC::IMG_BATTERY_RED, res);
	
	res = new RES(RES_T::IMG, PATH_IMG + "batteryEmpty.png");
	resourcesMap_.emplace(SRC::IMG_BATTERY_EMPTY, res);
	
	//	PushSpace
	res = new RES(RES_T::IMG, PATH_IMG + "Title/PushSpace.png");
	resourcesMap_.emplace(SRC::IMG_PUSHSPACE, res);

	res = new RES(RES_T::IMG, PATH_IMG + "raiderSousa.png");
	resourcesMap_.emplace(SRC::IMG_RAIDER_OPERATE, res);
	res = new RES(RES_T::IMG, PATH_IMG + "survivorSousa.png");
	resourcesMap_.emplace(SRC::IMG_SURVIVOR_OPERATE, res);

	res = new RES(RES_T::IMG, PATH_IMG + "uikara.png");
	resourcesMap_.emplace(SRC::IMG_UI_FRAME, res);

	res = new RES(RES_T::IMG, PATH_IMG + "gauge0.png");
	resourcesMap_.emplace(SRC::IMG_GAUGE_MAGIC_BASE, res);
	res = new RES(RES_T::IMG, PATH_IMG + "gauge1.png");
	resourcesMap_.emplace(SRC::IMG_GAUGE_MAGIC_1, res);
	res = new RES(RES_T::IMG, PATH_IMG + "gauge2.png");
	resourcesMap_.emplace(SRC::IMG_GAUGE_MAGIC_2, res);
	res = new RES(RES_T::IMG, PATH_IMG + "gauge3.png");
	resourcesMap_.emplace(SRC::IMG_GAUGE_MAGIC_3, res);
	res = new RES(RES_T::IMG, PATH_IMG + "gauge4.png");
	resourcesMap_.emplace(SRC::IMG_GAUGE_MAGIC_4, res);
	res = new RES(RES_T::IMG, PATH_IMG + "gauge5.png");
	resourcesMap_.emplace(SRC::IMG_GAUGE_MAGIC_5, res);
	res = new RES(RES_T::IMG, PATH_IMG + "gauge6.png");
	resourcesMap_.emplace(SRC::IMG_GAUGE_MAGIC_MAX, res);

	res = new RES(RES_T::IMG, PATH_IMG + "raizyunbi.png");
	resourcesMap_.emplace(SRC::IMG_ALREADY_RAIDER, res);
	res = new RES(RES_T::IMG, PATH_IMG + "surzyunbi.png");
	resourcesMap_.emplace(SRC::IMG_ALREADY_SURVIVOR, res);
	res = new RES(RES_T::IMG, PATH_IMG + "ok.png");
	resourcesMap_.emplace(SRC::IMG_OK, res);

	res = new RES(RES_T::IMG, PATH_IMG + "draw.png");
	resourcesMap_.emplace(SRC::IMG_WIN_DRAW, res);
	res = new RES(RES_T::IMG, PATH_IMG + "winobake.png");
	resourcesMap_.emplace(SRC::IMG_WIN_RAIDER, res);
	res = new RES(RES_T::IMG, PATH_IMG + "winhuman.png");
	resourcesMap_.emplace(SRC::IMG_WIN_SURVIVOR, res);

	res = new RES(RES_T::IMG, PATH_IMG + "raider.png");
	resourcesMap_.emplace(SRC::IMG_RAIDER, res);

	res = new RES(RES_T::IMGS, PATH_IMG + "numenemy.png", IMG_NUMBER_NUMX, IMG_NUMBER_NUMY, IMG_NUMBER_SIZEX, IMG_NUMBER_SIZEY);
	resourcesMap_.emplace(SRC::imgSHdl_NUM_ENEMY, res);
	res = new RES(RES_T::IMGS, PATH_IMG + "numtime.png", IMG_NUMBER_NUMX, IMG_NUMBER_NUMY, IMG_NUMBER_SIZEX, IMG_NUMBER_SIZEY);
	resourcesMap_.emplace(SRC::imgSHdl_NUM_TIME, res);


	res = new RES(RES_T::IMG, PATH_IMG + "hatena.png");
	resourcesMap_.emplace(SRC::IMG_SURVIVOR_HATENA, res);

	res = new RES(RES_T::IMG, PATH_IMG + "bikkuri.png");
	resourcesMap_.emplace(SRC::IMG_SURVIVOR_BIKKURI, res);

	res = new RES(RES_T::IMG, PATH_IMG + "bikkuri2.png");
	resourcesMap_.emplace(SRC::IMG_SURVIVOR_BIKKURI2, res);
	
	//	�v���C���[1
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Survivor/1.mv1");
	resourcesMap_.emplace(SRC::MDL_SURVIVOR_1, res);
	//	�v���C���[2
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Survivor/2.mv1");
	resourcesMap_.emplace(SRC::MDL_SURVIVOR_2, res);
	//	�v���C���[3
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Survivor/3.mv1");
	resourcesMap_.emplace(SRC::MDL_SURVIVOR_3, res);

	//	�v���C���[���S��1
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Survivor/death1.mv1");
	resourcesMap_.emplace(SRC::MDL_SURVIVOR_1_DEAD, res);
	//	�v���C���[���S��2
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Survivor/death2.mv1");
	resourcesMap_.emplace(SRC::MDL_SURVIVOR_2_DEAD, res);
	//	�v���C���[���S��3
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Survivor/death3.mv1");
	resourcesMap_.emplace(SRC::MDL_SURVIVOR_3_DEAD, res);

	//	�d�r
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Victim/Battery.mv1");
	resourcesMap_.emplace(SRC::MDL_BATTERY, res);

	//	���C�_�[
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Raider/raid.mv1");
	resourcesMap_.emplace(SRC::MDL_RAIDER_LV1, res);
	//	
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Raider/deathRai.mv1");
	resourcesMap_.emplace(SRC::MDL_RAIDER_DEAD, res);

	//	�v���C���[�e
	res = new RES(RES_T::IMG, PATH_IMG + "Shadow.png");
	resourcesMap_.emplace(SRC::IMG_PLAYERSHADOW, res);

	//	�X�J�C�h�[��
	res = new RES(RES_T::MODEL, PATH_MDL + "SkyDome/SkyDome.mv1");
	resourcesMap_.emplace(SRC::MDL_SKYDOME, res);

	//	stage
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/stage/stagenocandle5.mv1");
	resourcesMap_.emplace(SRC::MDL_STAGE, res);

	//	stage
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/stage/candle.mv1");
	resourcesMap_.emplace(SRC::MDL_STAGECANDLE, res);

	//	stagecol
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/stagecollider2.mv1");
	resourcesMap_.emplace(SRC::MDL_STAGE_COLLIDER, res);


	//	�G�t�F�N�g�́A���o�[�W�����ł�.efkefc��efkproj�ŕ�����Ă��܂������A���܂͓�������efkproj�Ŏg����

	//	��
	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "Smoke/Smoke.efkefc");
	resourcesMap_.emplace(SRC::EFF_SMOKE, res);

	//	�����̒��ɕ����z�R���I�Ȃ��
	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "Dust/Atmosphere.efkproj");
	resourcesMap_.emplace(SRC::EFF_DUST, res);
	//	�����@80�t��~110�t�����g�p
	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "Torch/Flame.efkproj");
	resourcesMap_.emplace(SRC::EFF_TORCH, res);
	//	�����@80�t��~110�t�����g�p
	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "TorchBlue/Flame.efkproj");
	resourcesMap_.emplace(SRC::EFF_TORCHDARK, res);
	//	
	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "Evaporate/evaporate.efkefc");
	resourcesMap_.emplace(SRC::EFF_EVAPORATE, res);
	//	
	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "DarkLight/darklight.efkefc");
	resourcesMap_.emplace(SRC::EFF_DARKLIGHT, res);

	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "CosmicSmoke/cosmicSmoke.efkefc");
	resourcesMap_.emplace(SRC::EFF_COSMICSMOKE, res);

	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "BlueBlood/blueBlood.efkefc");
	resourcesMap_.emplace(SRC::EFF_BLUEBLOOD, res);

	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "PowerUp/PowerUp.efkproj");
	resourcesMap_.emplace(SRC::EFF_POWERUP, res);

	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "Heal/HealPotion2.efkproj");
	resourcesMap_.emplace(SRC::EFF_HEAL, res);

	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "MagicShot/magicshot.efkefc");
	resourcesMap_.emplace(SRC::EFF_MAGICSHOT, res);

	res = new RES(RES_T::SOUND, PATH_SND + "bgm.mp3");
	resourcesMap_.emplace(SRC::SND_BGM, res);

	res = new RES(RES_T::SOUND, PATH_SND + "draw.mp3");
	resourcesMap_.emplace(SRC::SND_WIN_DRAW, res);

	res = new RES(RES_T::SOUND, PATH_SND + "raiderwin.mp3");
	resourcesMap_.emplace(SRC::SND_WIN_RAIDER, res);

	res = new RES(RES_T::SOUND, PATH_SND + "survivorwin.mp3");
	resourcesMap_.emplace(SRC::SND_WIN_SURVIVOR, res);

	res = new RES(RES_T::SOUND, PATH_SND + "raiderattack.mp3");
	resourcesMap_.emplace(SRC::SND_ATTACK_RAIDER, res);

	res = new RES(RES_T::SOUND, PATH_SND + "raiderattack2.mp3");
	resourcesMap_.emplace(SRC::SND_ATTACK_RAIDER2, res);

	res = new RES(RES_T::SOUND, PATH_SND + "survivorattack.mp3");
	resourcesMap_.emplace(SRC::SND_ATTACK_SURVIVOR, res);

	res = new RES(RES_T::SOUND, PATH_SND + "heal.mp3");
	resourcesMap_.emplace(SRC::SND_HEAL, res);

	res = new RES(RES_T::SOUND, PATH_SND + "getbattery.mp3");
	resourcesMap_.emplace(SRC::SND_GETBATTERY, res);
}

void ResourceManager::Release(void)
{
	for (auto& p : loadedMap_)
	{
		p.second.Release();
	}

	loadedMap_.clear();
}

void ResourceManager::Destroy(void)
{
	Release();
	for (auto& res : resourcesMap_)
	{
		res.second->Release();
		delete res.second;
	}
	resourcesMap_.clear();
	delete instance_;
}

const Resource& ResourceManager::Load(SRC src)
{
	Resource& res = _Load(src);
	if (res.type_ == Resource::TYPE::NONE)
	{
		return dummy_;
	}
	return res;
}

int ResourceManager::LoadModelDuplicate(SRC src)
{
	Resource& res = _Load(src);
	if (res.type_ == Resource::TYPE::NONE)
	{
		return -1;
	}

	int duId = MV1DuplicateModel(res.handleId_);
	res.duplicateModelIds_.push_back(duId);

	return duId;
}

ResourceManager::ResourceManager(void)
{
}

Resource& ResourceManager::_Load(SRC src)
{

	//	���[�h�ς݃`�F�b�N
	const auto& lPair = loadedMap_.find(src);
	if (lPair != loadedMap_.end())
	{
		return *resourcesMap_.find(src)->second;
	}

	//	���\�[�X�o�^�`�F�b�N
	const auto& rPair = resourcesMap_.find(src);
	if (rPair == resourcesMap_.end())
	{
		//	�o�^����Ă��Ȃ�
		return dummy_;
	}

	//	���[�h����
	rPair->second->Load();

	//	�O�̂��߃R�s�[�R���X�g���N�^
	loadedMap_.emplace(src, *rPair->second);

	return *rPair->second;

}
