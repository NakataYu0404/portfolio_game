#include <Dxlib.h>
#include <EffekseerForDXLib.h>
#include "../../Application.h"
#include "../../Utility/Utility.h"
#include "../../Manager/ResourceManager.h"
#include "../Common/AnimationController.h"
#include "../../Manager/InputManager.h"
#include "../Common/CollisionManager.h"
#include "FlashLight.h"


FlashLight::FlashLight(std::weak_ptr<Transform> tran,int handBoneNum)
{
	//	�����d���̐������Ƀv���C���[�̎�̈ʒu���Q�Ƃ��邽�߂�Transform�ƃ{�[���ԍ����擾
	survivorTran_ = tran;
	handBoneNum_ = handBoneNum;
}

FlashLight::~FlashLight()
{
}

void FlashLight::Init()
{
	transform_ = std::make_shared<Transform>();

	//	���f���̊�{�ݒ�
	transform_->SetModel(resMng_.LoadModelDuplicate(
		ResourceManager::SRC::MDL_NONE));
	transform_->scl = { 1.0f,1.0f,1.0f };
	transform_->pos = MV1GetFramePosition(survivorTran_.lock()->modelId, handBoneNum_);
	transform_->quaRot = survivorTran_.lock()->quaRot;
	transform_->quaRotLocal =
		Quaternion::Euler({ 0.0f, Utility::Deg2RadF(Utility::ROT_HALF_DEG), 0.0f });
	transform_->Update();
	//	�����̃��C�g�p���[�ݒ�
	fineLightPow_ = pow_.Normal;
	lightPower_ = pow_.Normal;

	//	���f���̒��_�����擾
	poly = MV1GetReferenceMesh(transform_->modelId, -1, true);
	vertNum_ = poly.VertexNum;
	for (int i = 0; i < poly.PolygonNum; i++)
	{

		for (int p = 0; p < PLAYER_NUM; p++)
		{
			//���_�̗v�f�ԍ����擾
			vIndex_ = poly.Polygons[i].VIndex[p];

			//�擾�������_�̗v�f�ԍ����g���āA���_�����擾
			verRef_ = poly.Vertexs[vIndex_];

			//���_���֕ϊ�
			VERTEX3D v;
			v.pos = verRef_.Position;
			v.dif = verRef_.DiffuseColor;
			v.spc = verRef_.SpecularColor;
			v.norm = verRef_.Normal;
			v.u = verRef_.TexCoord[0].u;
			v.v = verRef_.TexCoord[0].v;

			//���I�z��Ɋi�[
			vert_.emplace_back(v);
		}
	}

	//	���C�g�̂��ꂼ��̌�����ݒ�
	light_.lightVec_.CC = LIGHT_DIR_CC;
	light_.lightVec_.CCL = LIGHT_DIR_CCL;
	light_.lightVec_.CL = LIGHT_DIR_CL;
	light_.lightVec_.CCR = LIGHT_DIR_CCR;
	light_.lightVec_.CR = LIGHT_DIR_CR;

	//	�������
	SwitchLight(STATE::ON);

}

// �X�V����
void FlashLight::Update()
{
	UpdatePlay(); // ���C�g�̃p���[���Ԃ��X�V
	transform_->Update(); // ���f������̍X�V
	PosUpdate(); // �����d���̈ʒu�����X�V
	LightCollision(); // ���C�g�̓����蔻�������
}

void FlashLight::Draw(bool isDrawRaiderWindow, int screenH)
{
	//	���f���̕`��
	if (state_ == STATE::ON)
	{
		// �y�o�b�t�@��L���ɂ���
		SetUseZBuffer3D(TRUE);

		// �y�o�b�t�@�ւ̏������݂�L���ɂ���
		SetWriteZBuffer3D(TRUE);

		int color = 0xddbb88;
		if (lightPower_ >= pow_.Hi)
		{
			color = 0xffeebb;
		}
		if (lightPower_ <= pow_.Low)
		{
			color = 0xbb8300;
		}

		// ���C�g�̌���ʂŕ`��
		DrawTriangle3D(start_, light_.lightPos_.CCR, light_.lightPos_.CR, color, true);
		DrawTriangle3D(start_, light_.lightPos_.CL, light_.lightPos_.CCL, color, true);
		DrawTriangle3D(start_, light_.lightPos_.CCL, light_.lightPos_.CC, color, true);
		DrawTriangle3D(start_, light_.lightPos_.CC, light_.lightPos_.CCR, color, true);

	}
}

void FlashLight::SetParam()
{
}

void FlashLight::SwitchLight(STATE state, bool operate)
{
	auto& ins = InputManager::GetInstance();

	if (state != STATE::NONE)
	{
		switch (state)
		{
		case FlashLight::STATE::ON:
			TurnOn();
			return;
		case FlashLight::STATE::OFF:
			TurnOff();
			return;
		}
	}

	switch (state_)
	{
	case FlashLight::STATE::ON:
		TurnOff();
		break;
	case FlashLight::STATE::OFF:
		TurnOn();
		break;
	}
}

FlashLight::STATE FlashLight::GetState(void)
{
	return state_;
}

void FlashLight::AddPower(float pow)
{
	fineLightPow_ += pow;
}

int FlashLight::GetLightPow(void)
{
	return lightPower_;
}

void FlashLight::SetLightPow(int pow)
{
	fineLightPow_ = pow;
}

void FlashLight::LightCollision(void)
{
	if (state_ != STATE::ON)
	{
		return;
	}

	auto& col = CollisionManager::GetInstance();

	auto colActC = col.Line2Collider_Actor(Collider::Category::RAIDER, start_, light_.lightPos_.CC);
	auto colActL = col.Line2Collider_Actor(Collider::Category::RAIDER, start_, light_.lightPos_.CL);
	auto colActR = col.Line2Collider_Actor(Collider::Category::RAIDER, start_, light_.lightPos_.CR);
	if (colActC.size() > 0 || colActL.size() > 0 || colActR.size() > 0)
	{
		if (colActC.size() > 0)
		{

			for (auto& i : colActC)
			{
				i.lock()->OnCollision(Collider::Category::LIGHT);
			}
		}
		else if (colActL.size() > 0)
		{
			for (auto& i : colActL)
			{
				i.lock()->OnCollision(Collider::Category::LIGHT);
			}
		}
		else
		{
			for (auto& i : colActR)
			{
				i.lock()->OnCollision(Collider::Category::LIGHT);
			}
		}
	}

	colActC = col.Line2Collider_Actor(Collider::Category::SURVIVOR, start_, light_.lightPos_.CC);
	colActL = col.Line2Collider_Actor(Collider::Category::SURVIVOR, start_, light_.lightPos_.CL);
	colActR = col.Line2Collider_Actor(Collider::Category::SURVIVOR, start_, light_.lightPos_.CR);
	if (colActC.size() > 0 || colActL.size() > 0 || colActR.size() > 0)
	{
		if (colActC.size() > 0)
		{
			for (auto& i : colActC)
			{
				i.lock()->OnCollision(Collider::Category::LIGHT);
			}
		}
		else if (colActL.size() > 0)
		{
			for (auto& i : colActL)
			{
				i.lock()->OnCollision(Collider::Category::LIGHT);
			}
		}
		else
		{
			for (auto& i : colActR)
			{
				i.lock()->OnCollision(Collider::Category::LIGHT);
			}
		}
	}

}

void FlashLight::ChangeStateNone(void)
{
}

void FlashLight::ChangeStatePlay(void)
{
}

void FlashLight::PosUpdate(void)
{
	start_ = MV1GetFramePosition(survivorTran_.lock()->modelId, handBoneNum_);

	//	struct����߂Ĕz��ō�����ق������炩�ɃR�[�h�͒Z���Ȃ邯�Ǖ�����Â炢�c

	LightDir_ = VScale(light_.lightVec_.CC, (float)lightPower_);
	//	�����d��pos����VAdd�ł܂������L�΂������W��PosAxis�Ńv���C���[�̐��ʂ܂ŉ�]
	light_.lightPos_.CC = VAdd(start_, Quaternion::PosAxis(survivorTran_.lock()->quaRot, LightDir_));
	auto col = CollisionManager::GetInstance().Line2Collider_ColInfo(Collider::Category::STAGE, start_, light_.lightPos_.CC);
	if (col.HitFlag == true)
	{
		light_.lightPos_.CC = col.HitPosition;
	}

	LightDir_ = VScale(light_.lightVec_.CCL, (float)lightPower_);
	light_.lightPos_.CCL = VAdd(start_, Quaternion::PosAxis(survivorTran_.lock()->quaRot, LightDir_));
	 col = CollisionManager::GetInstance().Line2Collider_ColInfo(Collider::Category::STAGE, start_, light_.lightPos_.CCL);
	if (col.HitFlag == true)
	{
		light_.lightPos_.CCL = col.HitPosition;
	}

	LightDir_ = VScale(light_.lightVec_.CCR, (float)lightPower_);
	light_.lightPos_.CCR = VAdd(start_, Quaternion::PosAxis(survivorTran_.lock()->quaRot, LightDir_));
	 col = CollisionManager::GetInstance().Line2Collider_ColInfo(Collider::Category::STAGE, start_, light_.lightPos_.CCR);
	if (col.HitFlag == true)
	{
		light_.lightPos_.CCR = col.HitPosition;
	}

	LightDir_ = VScale(light_.lightVec_.CL, (float)lightPower_);
	light_.lightPos_.CL = VAdd(start_, Quaternion::PosAxis(survivorTran_.lock()->quaRot, LightDir_));
	 col = CollisionManager::GetInstance().Line2Collider_ColInfo(Collider::Category::STAGE, start_, light_.lightPos_.CL);
	if (col.HitFlag == true)
	{
		light_.lightPos_.CL = col.HitPosition;
	}

	LightDir_ = VScale(light_.lightVec_.CR, (float)lightPower_);
	light_.lightPos_.CR = VAdd(start_, Quaternion::PosAxis(survivorTran_.lock()->quaRot, LightDir_));
	 col = CollisionManager::GetInstance().Line2Collider_ColInfo(Collider::Category::STAGE, start_, light_.lightPos_.CR);
	if (col.HitFlag == true)
	{
		light_.lightPos_.CR = col.HitPosition;
	}
}

void FlashLight::UpdatePlay(void)
{

	if (fineLightPow_ > FINE_LIGHTPOW_NORMAL)
	{
		lightPower_ = pow_.Hi;
	}
	else if (fineLightPow_ >= FINE_LIGHTPOW_LOW)
	{
		lightPower_ = pow_.Normal;
	}
	else if (fineLightPow_ >= FINE_LIGHTPOW_EMPTY)
	{
		lightPower_ = pow_.Low;
	}
	else
	{
		lightPower_ = pow_.Empty;
		SwitchLight(STATE::OFF);
	}

	if (state_ == STATE::ON)
	{
		fineLightPow_ -= (FINE_LIGHTPOW_NORMAL / FINE_LIGHTPOW_DIV) * 2.0f;

		transform_->pos = MV1GetFramePosition(survivorTran_.lock()->modelId, handBoneNum_);
		transform_->quaRot = survivorTran_.lock()->quaRot;
	}
	else
	{
		//	�ǂ������Ȃ���������Ȃ��̂ɁA�Փˁ����C�g��ON�����������Ɨ]�v�Ȏ��Ԃ������邩���Γ�����Ȃ��ꏊ�ɐ�����΂�
		transform_->pos = Utility::POS_FARAWAY;
	}
}

void FlashLight::TurnOn(void)
{
	if (lightPower_ <= 0)
	{
		return;
	}

	state_ = STATE::ON;
}

void FlashLight::TurnOff(void)
{
	state_ = STATE::OFF;
}

