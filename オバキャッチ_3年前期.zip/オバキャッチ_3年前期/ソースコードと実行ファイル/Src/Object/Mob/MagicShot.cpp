#include <Dxlib.h>
#include <EffekseerForDXLib.h>
#include "../../Application.h"
#include "../../Utility/Utility.h"
#include "../../Manager/ResourceManager.h"
#include "../Common/EffectController.h"
#include "../Common/AnimationController.h"
#include "../Common/Capsule.h"
#include "MagicShot.h"

MagicShot::MagicShot()
{
	animationController_ = nullptr;
}

MagicShot::~MagicShot()
{
}

void MagicShot::Init()
{
	transform_ = std::make_shared<Transform>();

	//	���f���̊�{�ݒ�
	transform_->SetModel(resMng_.LoadModelDuplicate(
		ResourceManager::SRC::MDL_NONE));
	transform_->scl = { 1.0f,1.0f,1.0f };
	transform_->pos = { 0.0f, 0.0f, 0.0f };
	transform_->headPos = transform_->pos;
	transform_->quaRot = Quaternion();
	transform_->quaRotLocal =
		Quaternion::Euler({ 0.0f, Utility::Deg2RadF(Utility::ROT_HALF_DEG), 0.0f });
	transform_->Update();

	transform_->MakeCollider(Collider::Category::MAGICSHOT, Collider::TYPE::CAPSULE);

	//	�J�v�Z���R���C�_
	capsule_ = std::make_shared<Capsule>(transform_);
	capsule_->SetLocalPosTop(COLCAPSULE_TOP);
	capsule_->SetLocalPosDown(COLCAPSULE_BOTTOM);
	capsule_->SetRadius(COLCAPSULE_RADIUS);

	//	�ۉe�摜
	imgShadowHdl_ = resMng_.Load(ResourceManager::SRC::IMG_PLAYERSHADOW).handleId_;


	//	�������
	ChangeState(STATE::PLAY);

	SetParam();
}

void MagicShot::Update()
{
	if (!isAlive_)
	{
		return;
	}

	//	�X�V�X�e�b�v
	switch (state_)
	{
	case MagicShot::STATE::NONE:
		UpdateNone();
		break;
	case MagicShot::STATE::PLAY:
		UpdatePlay();
		break;
	}
	//	���f������X�V
	transform_->Update();

}

void MagicShot::Draw(bool isDrawRaiderWindow, int screenH)
{
	if (!isAlive_)
	{
		return;
	}

	effectController_->Draw();
}

void MagicShot::SetParam()
{
	isAlive_ = true;

}

void MagicShot::OnCollision(std::weak_ptr<Collider> collider)
{
	switch (collider.lock()->category_)
	{
	case Collider::Category::SURVIVOR:
		break;
	case Collider::Category::RAIDER:
		break;
	case Collider::Category::BATTERY:
		break;
	case Collider::Category::STAGE:
		transform_->pos = collider.lock()->hitInfo_.movedPos;
		transform_->Update();
		break;
	default:
		break;
	}
}

void MagicShot::OnCollision(Collider::Category category)
{
	switch (category)
	{
	case Collider::Category::RAIDER:
		break;
	case Collider::Category::SURVIVOR:
		break;
	case Collider::Category::STAGE:
		break;
	case Collider::Category::LIGHT:
		break;
	default:
		break;
	}
}

bool MagicShot::IsAlive(void)
{
	return isAlive_;
}

void MagicShot::SetAlive(bool alive)
{
	isAlive_ = alive;
}

void MagicShot::SetPos(VECTOR pos)
{
	transform_->pos = pos;
	transform_->Update();
	EffectInit();
	StartEffect(EFFECT_TYPE::MAGICSHOT);

}

void MagicShot::EffectInit(void)
{
	effectController_ = std::make_shared<EffectController>();

	EffmagicId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_MAGICSHOT).handleId_;

	effectController_->Add((int)EFFECT_TYPE::MAGICSHOT, EffmagicId_);
}

void MagicShot::StartEffect(EFFECT_TYPE type)
{
	switch (type)
	{
	case MagicShot::EFFECT_TYPE::MAGICSHOT:
		effectController_->Play((int)EFFECT_TYPE::MAGICSHOT, false,0,EFFECT_END,EFFECT_SPEED);
		effectController_->TransUpdate((int)EFFECT_TYPE::MAGICSHOT, transform_->pos, EFFECT_SCALE, { 0,0,0 });
		break;
	}
}

void MagicShot::ChangeState(STATE state)
{
	state_ = state;
}

void MagicShot::ChangeStateNone(void)
{
}

void MagicShot::ChangeStatePlay(void)
{
}

void MagicShot::UpdateNone(void)
{
}

void MagicShot::UpdatePlay(void)
{
	if (effectController_->IsEnd((int)EFFECT_TYPE::MAGICSHOT))
	{
		SetAlive(false);
	}

	if (!isAlive_)
	{
		transform_->pos = Utility::POS_FARAWAY;
	}

	effectController_->Update();
	transform_->Update();
}

void MagicShot::DrawShadow(void)
{
}
