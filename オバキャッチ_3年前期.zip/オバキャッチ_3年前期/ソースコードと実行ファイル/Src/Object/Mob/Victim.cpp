#include <Dxlib.h>
#include <EffekseerForDXLib.h>
#include "../../Application.h"
#include "../../Utility/Utility.h"
#include "../../Manager/ResourceManager.h"
#include "../Common/EffectController.h"
#include "../Common/AnimationController.h"
#include "../Common/Capsule.h"
#include "Victim.h"

Battery::Battery()
{
	animationController_ = nullptr;
}

Battery::~Battery()
{
}

void Battery::Init()
{
	transform_ = std::make_shared<Transform>();

	//	���f���̊�{�ݒ�
	transform_->SetModel(resMng_.LoadModelDuplicate(
		ResourceManager::SRC::MDL_BATTERY));
	transform_->scl = SCALE;
	transform_->pos = Utility::POS_FARAWAY;
	transform_->headPos = transform_->pos;
	transform_->quaRot = Quaternion();
	transform_->quaRotLocal =
		Quaternion::Euler({ 0.0f, Utility::Deg2RadF(Utility::ROT_HALF_DEG), 0.0f });
	transform_->Update();

	transform_->MakeCollider(Collider::Category::BATTERY, Collider::TYPE::CAPSULE);

	//	�J�v�Z���R���C�_
	capsule_ = std::make_shared<Capsule>(transform_);
	capsule_->SetLocalPosTop(CAPSULE_TOP);
	capsule_->SetLocalPosDown(CAPSULE_BOTTOM);
	capsule_->SetRadius(CAPSULE_RADIUS);

	//	�ۉe�摜
	imgShadowHdl_ = resMng_.Load(ResourceManager::SRC::IMG_PLAYERSHADOW).handleId_;


	//	�������
	ChangeState(STATE::PLAY);

	SetParam();
}

void Battery::Update()
{
	if (!isAlive_)
	{
		return;
	}

	//	�X�V�X�e�b�v
	switch (state_)
	{
	case Battery::STATE::NONE:
		UpdateNone();
		break;
	case Battery::STATE::PLAY:
		UpdatePlay();
		break;
	}
	//	���f������X�V
	transform_->Update();

}

void Battery::Draw(bool isDrawRaiderWindow, int screenH)
{
	if (!isAlive_)
	{
		return;
	}
	
	//	���f���̕`��
	MV1DrawModel(transform_->modelId);
	
	effectController_->Draw();
}

void Battery::SetParam()
{
	isAlive_ = true;
	cnt_ = 0;

}

void Battery::OnCollision(std::weak_ptr<Collider> collider)
{
	switch (collider.lock()->category_)
	{
	case Collider::Category::SURVIVOR:
		SetAlive(false);
		break;
	case Collider::Category::RAIDER:
		break;
	case Collider::Category::BATTERY:
		break;
	case Collider::Category::STAGE:
		transform_->pos = collider.lock()->hitInfo_.movedPos;
		transform_->Update();
		break;
	default:
		break;
	}
}

void Battery::OnCollision(Collider::Category category)
{
	switch (category)
	{
	case Collider::Category::RAIDER:
		break;
	case Collider::Category::SURVIVOR:
		break;
	case Collider::Category::STAGE:
		break;
	case Collider::Category::LIGHT:
		break;
	default:
		break;
	}
}

bool Battery::IsAlive(void)
{
	return isAlive_;
}

void Battery::SetAlive(bool alive)
{
	isAlive_ = alive;
}

void Battery::SetPos(VECTOR pos)
{
	transform_->pos = pos;
	transform_->Update();
	EffectInit();
	StartEffect(EFFECT_TYPE::POWERUP);

}

void Battery::EffectInit(void)
{
	effectController_ = std::make_shared<EffectController>();

	EffpowerupId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_POWERUP).handleId_;

	effectController_->Add((int)EFFECT_TYPE::POWERUP, EffpowerupId_);
}

void Battery::StartEffect(EFFECT_TYPE type)
{
	switch (type)
	{
	case Battery::EFFECT_TYPE::POWERUP:
		effectController_->Play((int)EFFECT_TYPE::POWERUP, false);
		effectController_->TransUpdate((int)EFFECT_TYPE::POWERUP, transform_->pos, EFFECT_SIZE, { 0,0,0 });
		break;
	}
}

void Battery::ChangeState(STATE state)
{
	state_ = state;
}

void Battery::ChangeStateNone(void)
{
}

void Battery::ChangeStatePlay(void)
{
}

void Battery::UpdateNone(void)
{
}

void Battery::UpdatePlay(void)
{
	effectController_->Update();

	transform_->quaRot = Quaternion::AngleAxis(Utility::ROT_QUARTER_DEG, Utility::AXIS_X);
	transform_->quaRot = Quaternion::AngleAxis(cnt_ / ROT_TIME_DIV, transform_->GetForward());

	transform_->Update();
	cnt_++;
}

void Battery::DrawShadow(void)
{

}
