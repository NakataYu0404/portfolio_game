#include <string>
#include <DxLib.h>
#include <EffekseerForDXLib.h>
#include "../../Application.h"
#include "../../Utility/Utility.h"
#include "../../Manager/InputManager.h"
#include "../../Manager/SceneManager.h"
#include "../../Manager/ResourceManager.h"
#include "../../Manager/Camera.h"
#include "../Common/CollisionManager.h"
#include "../Common/EffectController.h"
#include "../Common/AnimationController.h"
#include "../Common/Capsule.h"
#include "../Common/Sphere.h"
#include "../Common/Collider.h"
#include "../Common/CollisionManager.h"
#include "../Mob/Victim.h"
#include "../Mob/MagicShot.h"
#include "Survivor.h"
#include "Raider.h"

Raider::Raider(void)
{
	SetParam();
}

Raider::~Raider(void)
{
}

void Raider::Init(void)
{
	transform_ = std::make_shared<Transform>();

	//	���f���̊�{�ݒ�
	transform_->SetModel(resMng_.LoadModelDuplicate(
		ResourceManager::SRC::MDL_RAIDER_LV1));
	transform_->scl = MODEL_SIZE;
	transform_->pos = { 0.0f, 0.0f, 0.0f };
	transform_->headPos = MV1GetFramePosition(transform_->modelId, FRAME_HEAD);
	transform_->quaRot = Quaternion();
	transform_->quaRotLocal =
		Quaternion::Euler({ 0.0f, Utility::Deg2RadF(Utility::ROT_HALF_DEG), 0.0f });
	transform_->Update();

	//	�A�j���[�V�����̐ݒ�
	InitAnimation();

	transform_->MakeCollider(Collider::Category::RAIDER, Collider::TYPE::CAPSULE);


	capSize_.top = CAPSULE_TOP;
	capSize_.bot = CAPSULE_BOTTOM;
	capSize_.rad = CAPSULE_RADIUS;

	//	�J�v�Z���R���C�_
	capsule_ = std::make_shared<Capsule>(transform_);
	
	capsule_->SetLocalPosTop(capSize_.top);
	capsule_->SetLocalPosDown(capSize_.bot);
	capsule_->SetRadius(capSize_.rad);
	
	//	�ۉe�摜
	imgShadowHdl_ = resMng_.Load(ResourceManager::SRC::IMG_PLAYERSHADOW).handleId_;

	deadModelId_ = resMng_.LoadModelDuplicate(ResourceManager::SRC::MDL_RAIDER_DEAD);

	sndAttackHdl_ = resMng_.Load(ResourceManager::SRC::SND_ATTACK_RAIDER).handleId_;
	sndAttack2Hdl_ = resMng_.Load(ResourceManager::SRC::SND_ATTACK_RAIDER2).handleId_;
	sndSurAttackHdl_ = resMng_.Load(ResourceManager::SRC::SND_ATTACK_SURVIVOR).handleId_;

	imgGaugeBaseHdl_ = resMng_.Load(ResourceManager::SRC::IMG_GAUGE_MAGIC_BASE).handleId_;
	imgGauge1Hdl_ = resMng_.Load(ResourceManager::SRC::IMG_GAUGE_MAGIC_1).handleId_;
	imgGauge2Hdl_ = resMng_.Load(ResourceManager::SRC::IMG_GAUGE_MAGIC_2).handleId_;
	imgGauge3Hdl_ = resMng_.Load(ResourceManager::SRC::IMG_GAUGE_MAGIC_3).handleId_;
	imgGauge4Hdl_ = resMng_.Load(ResourceManager::SRC::IMG_GAUGE_MAGIC_4).handleId_;
	imgGauge5Hdl_ = resMng_.Load(ResourceManager::SRC::IMG_GAUGE_MAGIC_5).handleId_;
	imgGaugeMaxHdl_ = resMng_.Load(ResourceManager::SRC::IMG_GAUGE_MAGIC_MAX).handleId_;

	EffectInit();

	//	�������
	ChangeState(STATE::PLAY);

}

void Raider::SetParam(void)
{

	ForwardKey_ = KEY_INPUT_UP;
	BackKey_ = KEY_INPUT_DOWN;
	RightKey_ = KEY_INPUT_RIGHT;
	LeftKey_ = KEY_INPUT_LEFT;

	animationController_ = nullptr;
	state_ = STATE::NONE;
	statePlay_ = STATE_INPLAY::IDLE;

	speed_ = SPEED_RUN;
	moveDir_ = Utility::VECTOR_ZERO;
	movePow_ = Utility::VECTOR_ZERO;
	movedPos_ = Utility::VECTOR_ZERO;

	playerRotY_ = Quaternion();
	goalQuaRot_ = Quaternion();
	stepRotTime_ = 0.0f;

	//	�Փ˃`�F�b�N
	gravHitPosDown_ = Utility::VECTOR_ZERO;
	gravHitPosUp_ = Utility::VECTOR_ZERO;

	imgShadowHdl_ = -1;

	evasionCnt_ = 0.0f;

	gravityPow_ = DEFAULT_GRAVITY_POW;

	rotRad_ = 0.0f;

	hp_ = MAX_HP;

	for (int i = 0; i < SURVIVOR_NUM; i++)
	{
		R2SDistance_[i] = 0.0f;
	}

	nowCatchSurvNum_ = -1;
	peekabooType_ = PEEKABOO_TYPE::APPEAR;

	magicPrepareCnt_ = MAGICPRE_CNT_DEFAULT;
}

void Raider::Update(void)
{
	//	�X�V�X�e�b�v
	switch (state_)
	{
	case Raider::STATE::NONE:
		UpdateNone();
		break;
	case Raider::STATE::PLAY:
		UpdatePlay();
		break;
	case Raider::STATE::VICTORY:
		UpdateVictory();
		break;
	case Raider::STATE::DEAD:
		UpdateDead();
		break;
	}

	transform_->headPos = MV1GetFramePosition(transform_->modelId, FRAME_HEAD);
	transform_->midPos = Utility::VDiv(VAdd(transform_->pos, transform_->headPos), 2);
	transform_->Update();

	effectController_->Update();

	//	�A�j���[�V�����Đ�
	animationController_->Update();
}

void Raider::Draw(bool isDrawRaiderWindow, int screenH)
{

	if (isDrawRaiderWindow && IsPeekaboo(PEEKABOO_TYPE::INVISIBLE))
	{
		VECTOR pos = transform_->pos;
		pos.y += 1;
		DrawCone3D(pos, transform_->pos, VIBRATION_RANGE, SEARCH_RANGE, 0xffaabb, 0xffffff, false);
	}

	if (!IsPeekaboo(PEEKABOO_TYPE::INVISIBLE) || isDrawRaiderWindow)
	{
		//	���f���̕`��
		MV1DrawModel(transform_->modelId);
	}

	for (auto& m : magicShots_)
	{
		m->Draw();
	}

	effectController_->Draw();

	//DebugDraw();
}

void Raider::Draw2D(bool isDrawRaiderWindow)
{
	//	MAGIC���ȊO��Draw�����邩��Areturn�͎g��Ȃ�
	if (IsStateInPlay(STATE_INPLAY::MAGIC))
	{
		DrawExtendGraph3D(transform_->headPos.x,
			transform_->headPos.y,
			transform_->headPos.z, MAGIC_GAUGE_SIZE.x, MAGIC_GAUGE_SIZE.y, imgGaugeBaseHdl_, true);

		if (magicPrepareCnt_ < (MAGICPRE_CNT_DEFAULT / MAGICPRE_CNT_DIVNUM) * 4.0f)
		{
			DrawExtendGraph3D(transform_->headPos.x,
				transform_->headPos.y,
				transform_->headPos.z, MAGIC_GAUGE_SIZE.x, MAGIC_GAUGE_SIZE.y, imgGauge1Hdl_, true);
		}
		if (magicPrepareCnt_ < (MAGICPRE_CNT_DEFAULT / MAGICPRE_CNT_DIVNUM) * 3.0f)
		{
			DrawExtendGraph3D(transform_->headPos.x,
				transform_->headPos.y,
				transform_->headPos.z, MAGIC_GAUGE_SIZE.x, MAGIC_GAUGE_SIZE.y, imgGauge2Hdl_, true);
		}
		if (magicPrepareCnt_ < (MAGICPRE_CNT_DEFAULT / MAGICPRE_CNT_DIVNUM) * 2.0f)
		{
			DrawExtendGraph3D(transform_->headPos.x,
				transform_->headPos.y,
				transform_->headPos.z, MAGIC_GAUGE_SIZE.x, MAGIC_GAUGE_SIZE.y, imgGauge3Hdl_, true);
		}
		if (magicPrepareCnt_ < (MAGICPRE_CNT_DEFAULT / MAGICPRE_CNT_DIVNUM) * 1.0f)
		{
			DrawExtendGraph3D(transform_->headPos.x,
				transform_->headPos.y,
				transform_->headPos.z, MAGIC_GAUGE_SIZE.x, MAGIC_GAUGE_SIZE.y, imgGauge4Hdl_, true);
		}
		if (magicPrepareCnt_ < 0.0f)
		{
			DrawExtendGraph3D(transform_->headPos.x,
				transform_->headPos.y,
				transform_->headPos.z, MAGIC_GAUGE_SIZE.x, MAGIC_GAUGE_SIZE.y, imgGauge5Hdl_, true);
			DrawExtendGraph3D(transform_->headPos.x,
				transform_->headPos.y,
				transform_->headPos.z, MAGIC_GAUGE_SIZE.x + (Utility::ScaleDownTen(sinf(magicPrepareCnt_))), MAGIC_GAUGE_SIZE.y + (Utility::ScaleDownTen(sinf(magicPrepareCnt_))), imgGaugeMaxHdl_, true);
		}
	}

}

void Raider::OnCollision(std::weak_ptr<Collider> collider)
{
	switch (collider.lock()->category_)
	{
	case Collider::Category::SURVIVOR:
		if (IsCanCatch() && nowCatchSurvNum_ >= 0)
		{
			animationController_->Play((int)ANIM_TYPE::CATCH, false);
			ChangeStateInPlay(STATE_INPLAY::CATCH);
			ChangePeekaboo(PEEKABOO_TYPE::CATCH);
			if (!CheckSoundMem(sndAttackHdl_))
			{
				PlaySoundMem(sndAttackHdl_, DX_PLAYTYPE_BACK, true);
			}
			if (!CheckSoundMem(sndAttack2Hdl_))
			{
				PlaySoundMem(sndAttack2Hdl_, DX_PLAYTYPE_BACK, true);
			}
			rotRad_ = atan2f(Utility::VNormalize(Utility::DistanceV(transform_->pos, collider.lock()->pos_)).x, Utility::VNormalize(Utility::DistanceV(transform_->pos, collider.lock()->pos_)).z);
			SetGoalRotate(rotRad_);

		}
		break;
	case Collider::Category::RAIDER:
		break;
	case Collider::Category::STAGE:
		transform_->pos = collider.lock()->hitInfo_.movedPos;
		transform_->Update();
		break;
	default:

		break;
	}
}

void Raider::OnCollision(Collider::Category category)
{
	switch (category)
	{
	case Collider::Category::RAIDER:
		break;
	case Collider::Category::SURVIVOR:
		break;
	case Collider::Category::STAGE:
		break;
	case Collider::Category::LIGHT:
		if (!IsStateInPlay(STATE_INPLAY::GETHIT) && !IsStateInPlay(STATE_INPLAY::RUNAWAY))
		{
			evasionCnt_ = GETHIT_CNT_DEFAULT;
			ChangeStateInPlay(Raider::STATE_INPLAY::GETHIT);
			ChangePeekaboo(PEEKABOO_TYPE::APPEAR);
			animationController_->Play((int)ANIM_TYPE::SURPRISED, false);
		}
		if (IsStateInPlay(STATE_INPLAY::RUNAWAY))
		{
			evasionCnt_ = RUNAWAY_CNT_DEFAULT;
		}
		Damage(DAMAGE_POW);
		ControllerVibration(VIBRATION_POW, GETHIT_CNT_DEFAULT);
		break;
	default:
		break;
	}

}

void Raider::DebugDraw(void)
{
	DrawFormatString(0, 0, 0xffffff, "%f", hp_);

	//	capsule_->Draw();
}

bool Raider::IsStateInPlay(STATE_INPLAY state)
{
	return statePlay_ == state;
}


void Raider::SetSurvivor(std::array<std::weak_ptr<Survivor>, SURVIVOR_NUM> surv)
{
	for (int i = 0; i < SURVIVOR_NUM; i++)
	{
		survivor_[i] = surv[i];
	}
	
}

bool Raider::IsCatch(void)
{
	if (IsStateInPlay(STATE_INPLAY::CATCH))
	{
		return true;
	}
	return false;
}

bool Raider::IsCanCatch(void)
{
	if (IsStateInPlay(STATE_INPLAY::CHASE) || IsStateInPlay(STATE_INPLAY::GETHIT) || IsStateInPlay(STATE_INPLAY::RUNAWAY))
	{
		return false;
	}

	return true;
}

void Raider::SetCatchSurvivorNo(int survNum)
{
	if (nowCatchSurvNum_ < 0 || survNum < 0)
	{
		nowCatchSurvNum_ = survNum;
	}
	
	if (survNum < 0)
	{
		ChangeStateInPlay(STATE_INPLAY::IDLE);
		ChangePeekaboo(PEEKABOO_TYPE::INVISIBLE);
	}
}

void Raider::ChangePeekaboo(PEEKABOO_TYPE type, bool operation)
{
	if (peekabooType_ == type)
	{
		return;
	}

	if ((IsPeekaboo(PEEKABOO_TYPE::DAMAGED) || IsPeekaboo(PEEKABOO_TYPE::CATCH)) && operation)
	{
		return;
	}

	effectController_->Stop((int)EFFECT_TYPE::EVAPORATE);
	StartEffect(EFFECT_TYPE::SMOKE);

	peekabooType_ = type;

	switch (peekabooType_)
	{
	case Raider::PEEKABOO_TYPE::INVISIBLE:
		speed_ = SPEED_WALK;
		break;
	case Raider::PEEKABOO_TYPE::APPEAR:
		speed_ = SPEED_RUN;
		break;
	case Raider::PEEKABOO_TYPE::CATCH:
		speed_ = SPEED_RUN;
		break;
	case Raider::PEEKABOO_TYPE::DAMAGED:
		speed_ = SPEED_RUN;
		break;
	default:
		break;
	}
}

bool Raider::IsPeekaboo(PEEKABOO_TYPE type)
{
	return peekabooType_ == type;
}

bool Raider::IsEndGameOverShow(void)
{
	return (isVictoryGameOver_ || isDefeatGameOver_);
}

void Raider::ControllerVibration(int pow, int time)
{
	StartJoypadVibration(DX_INPUT_PAD1, pow, time);
}

void Raider::Magic(void)
{

	for (auto& m : magicShots_)
	{
		if (m == nullptr)
		{
			break;
		}

		m->Update();
	}

	if (!IsStateInPlay(STATE_INPLAY::IDLE) && !IsStateInPlay(STATE_INPLAY::MAGIC))
	{
		magicPrepareCnt_ = MAGICPRE_CNT_DEFAULT;
		return;
	}

	auto& ins = InputManager::GetInstance();

	if (ins.IsPadBtnNew(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::L_TRIGGER) && ins.IsPadBtnNew(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::R_TRIGGER) || ins.IsNew(KEY_INPUT_N))
	{
		//	���Ԍo�߂����āA��莞�Ԃ������甭��
		ChangePeekaboo(PEEKABOO_TYPE::APPEAR, true);
		ChangeStateInPlay(STATE_INPLAY::MAGIC);

		magicPrepareCnt_ -= 2;
	}
	else
	{
		if (magicPrepareCnt_ <= 0.0f)
		{
			//	���@����
			for (auto& s : survivor_)
			{
				//	���@�̍쐬
				for (auto& i : magicShots_)
				{
					//	i��null�Ȃ͖̂��@���쐬���Ă��Ȃ����̂�
					if (i == nullptr)
					{
						break;
					}
					//	���񂾖��@���ė��p(push_back�͏d��)
					if (i->IsAlive() == false)
					{
						i->Init();
						i->SetPos(s.lock()->GetTransform().lock()->pos);
						break;
					}
				}
				//	���@��V�K�쐬
				std::shared_ptr<MagicShot> magic = std::make_shared<MagicShot>();
				magic->Init();
				magic->SetPos(s.lock()->GetTransform().lock()->pos);
				colMng_.Add(magic);
				magicShots_.push_back(magic);
			}

			animationController_->Play((int)ANIM_TYPE::MAGICCHARGE);
		}
		magicPrepareCnt_ = MAGICPRE_CNT_DEFAULT;
		ChangeStateInPlay(STATE_INPLAY::IDLE);

	}
}

void Raider::InitAnimation(void)
{
	std::string path = Application::PATH_MODEL + "Player/Anim/";

	animationController_ = std::make_shared<AnimationController>(transform_->modelId);


	animationController_->Add((int)ANIM_TYPE::IDLE, path + "raidIdle.mv1", ANIM_SPEED_60);
	animationController_->Add((int)ANIM_TYPE::RUN, path + "Run.mv1", ANIM_SPEED_20);
	animationController_->Add((int)ANIM_TYPE::FAST_RUN, path + "FastRun.mv1", ANIM_SPEED_20);
	animationController_->Add((int)ANIM_TYPE::VICTORY_END, path + "Victory.mv1", ANIM_SPEED_13);
	animationController_->Add((int)ANIM_TYPE::VICTORY, path + "fingerGun2.mv1", ANIM_SPEED_60);
	animationController_->Add((int)ANIM_TYPE::RUNAWAY, path + "RunAway.mv1", ANIM_SPEED_60);
	animationController_->Add((int)ANIM_TYPE::DIE, path + "Dying.mv1", ANIM_SPEED_60);
	animationController_->Add((int)ANIM_TYPE::CATCH, path + "Catch.mv1", ANIM_SPEED_60);
	animationController_->Add((int)ANIM_TYPE::SURPRISED, path + "surprised.mv1", ANIM_SPEED_60);
	animationController_->Add((int)ANIM_TYPE::MAGICCHARGE, path + "MagicCharge.mv1", ANIM_SPEED_60);
	animationController_->Add((int)ANIM_TYPE::MAGIC, path + "Spellcast.mv1", ANIM_SPEED_60);


	animationController_->Play((int)ANIM_TYPE::IDLE);

}

void Raider::ChangeStateAnimation(void)
{
	switch (statePlay_)
	{
	case Raider::STATE_INPLAY::NONE:
		break;
	case Raider::STATE_INPLAY::IDLE:
		animationController_->Play((int)ANIM_TYPE::IDLE);
		break;
	case Raider::STATE_INPLAY::CHASE:
		animationController_->Play((int)ANIM_TYPE::IDLE);
		break;
	case Raider::STATE_INPLAY::RUNAWAY:
		animationController_->Play((int)ANIM_TYPE::RUNAWAY);
		break;
	case Raider::STATE_INPLAY::MAGIC:
		animationController_->Play((int)ANIM_TYPE::MAGICCHARGE);
		break;
	default:
		break;

	}

}

void Raider::UpdatePlay(void)
{

	auto& ins = InputManager::GetInstance();

	if (ins.IsNew(KEY_INPUT_SPACE) || ins.IsPadBtnNew(InputManager::JOYPAD_NO::PAD1,InputManager::JOYPAD_BTN::DOWN))
	{
		ChangePeekaboo(PEEKABOO_TYPE::APPEAR, true);
	}
	else
	{
		ChangePeekaboo(PEEKABOO_TYPE::INVISIBLE, true);
	}

	Magic();
	
	CatchUpdate();
	EvasionUpdate();
	bool allCatch = (survivor_[0].lock()->IsStateInPlay(Survivor::STATE_INPLAY::CATCHED) || survivor_[0].lock()->IsStateInPlay(Survivor::STATE_INPLAY::CRAWL)) &&
		(survivor_[1].lock()->IsStateInPlay(Survivor::STATE_INPLAY::CATCHED) || survivor_[1].lock()->IsStateInPlay(Survivor::STATE_INPLAY::CRAWL)) &&
		(survivor_[2].lock()->IsStateInPlay(Survivor::STATE_INPLAY::CATCHED) || survivor_[2].lock()->IsStateInPlay(Survivor::STATE_INPLAY::CRAWL));

	if ((!IsStateInPlay(STATE_INPLAY::GETHIT) && !IsStateInPlay(STATE_INPLAY::CATCH) && !IsStateInPlay(STATE_INPLAY::MAGIC)) && !allCatch)
	{
		ProcessMove(0);
	}
	else
	{
		movePow_ = Utility::VECTOR_ZERO;
	}

	ChangeStateAnimation();

	Rotate();

	//	�Փ˔���
	Collision();

	//	��]������
	transform_->quaRot = playerRotY_;
}

void Raider::UpdateVictory(void)
{
	ChangePeekaboo(PEEKABOO_TYPE::APPEAR);

	if (animationController_->GetPlayType() != (int)ANIM_TYPE::VICTORY_END)
	{
		animationController_->Play((int)ANIM_TYPE::VICTORY, false);
	}
	if (animationController_->IsEnd() && animationController_->GetPlayType() == (int)ANIM_TYPE::VICTORY)
	{
		for (auto& s : survivor_)
		{
			s.lock()->StartEffect(Survivor::EFFECT_TYPE::COSMICSMOKE);
			s.lock()->StartEffect(Survivor::EFFECT_TYPE::BLUEBLOOD);
		}
		animationController_->Play((int)ANIM_TYPE::VICTORY_END, false);
	}
	else if (animationController_->IsEnd() && animationController_->GetPlayType() == (int)ANIM_TYPE::VICTORY_END)
	{
		for (auto& s : survivor_)
		{
			s.lock()->GetTransform().lock()->SetModel(s.lock()->GetDeadModelId());
		}
		isVictoryGameOver_ = true;
	}

	animationController_->Update();
}

void Raider::UpdateDead(void)
{
	ChangePeekaboo(PEEKABOO_TYPE::APPEAR);

	if (animationController_->GetPlayType() != (int)(int)ANIM_TYPE::DIE)
	{
		animationController_->Play((int)ANIM_TYPE::DIE, false);
	}
	else if(animationController_->IsEnd() && transform_->modelId != deadModelId_)
	{
		StartEffect(EFFECT_TYPE::SMOKE);
		transform_->SetModel(deadModelId_);
		transform_->Update();
		isDefeatGameOver_ = true;
	}
}

void Raider::ChangeStateInPlay(STATE_INPLAY state)
{
	statePlay_ = state;
}

void Raider::EffectInit(void)
{
	effectController_ = std::make_shared<EffectController>();

	EffEvaporateId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_EVAPORATE).handleId_;
	EffDarklightId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_DARKLIGHT).handleId_;
	EffSmokeId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_SMOKE).handleId_;

	effectController_->Add((int)EFFECT_TYPE::EVAPORATE, EffEvaporateId_);
	effectController_->Add((int)EFFECT_TYPE::DARKLIGHT, EffDarklightId_);
	effectController_->Add((int)EFFECT_TYPE::SMOKE, EffSmokeId_);
}

void Raider::StartEffect(EFFECT_TYPE type)
{
	switch (type)
	{
	case Raider::EFFECT_TYPE::EVAPORATE:
		effectController_->Play((int)EFFECT_TYPE::EVAPORATE, false);
		effectController_->TransUpdate((int)EFFECT_TYPE::EVAPORATE, transform_->headPos, EFFECT_SIZE_EVAPORATE, { 0,0,0 });
		break;
	case Raider::EFFECT_TYPE::DARKLIGHT:
		effectController_->Play((int)EFFECT_TYPE::DARKLIGHT, false);
		effectController_->TransUpdate((int)EFFECT_TYPE::DARKLIGHT, survivor_[nowCatchSurvNum_].lock()->GetTransform().lock()->pos , EFFECT_SIZE_DARKLIGHT, { 0,0,0 });
		break;
	case Raider::EFFECT_TYPE::SMOKE:
		effectController_->Play((int)EFFECT_TYPE::SMOKE, false);
		effectController_->TransUpdate((int)EFFECT_TYPE::SMOKE, transform_->midPos, EFFECT_SIZE_SMOKE, { 0,0,0 });
		break;
	default:
		break;
	}
}

void Raider::EvasionUpdate(void)
{
	if (!IsStateInPlay(STATE_INPLAY::GETHIT) && !IsStateInPlay(STATE_INPLAY::RUNAWAY))
	{
		return;
	}

	if (evasionCnt_ < 0)
	{
		switch (statePlay_)
		{
		case Raider::STATE_INPLAY::GETHIT:
			//	�~�܂�J�E���g�̊Ԏ~�܂��āA�����A�E�F�C������
			ChangeStateInPlay(STATE_INPLAY::RUNAWAY);
			ChangePeekaboo(PEEKABOO_TYPE::DAMAGED);
			evasionCnt_ = RUNAWAY_CNT_DEFAULT;
			break;
		case Raider::STATE_INPLAY::RUNAWAY:
			ChangeStateInPlay(STATE_INPLAY::IDLE);
			ChangePeekaboo(PEEKABOO_TYPE::INVISIBLE);
			effectController_->Stop((int)EFFECT_TYPE::EVAPORATE);
			break;
		}
	}
	else
	{
		StartEffect(EFFECT_TYPE::EVAPORATE);
		ChangePeekaboo(PEEKABOO_TYPE::DAMAGED);
	}
	if (!CheckSoundMem(sndSurAttackHdl_))
	{
		PlaySoundMem(sndSurAttackHdl_, DX_PLAYTYPE_BACK, true);
	}

	evasionCnt_--;
}

void Raider::CatchUpdate(void)
{
	//	�X�e�[�g���߂܂��Ă��ԂłȂ�������A�߂܂��Ă�T�o�C�o�[�����
	if (!IsStateInPlay(STATE_INPLAY::CATCH) && !IsStateInPlay(STATE_INPLAY::CHASE))
	{
		if (nowCatchSurvNum_ >= 0)
		{
			survivor_[nowCatchSurvNum_].lock()->SetHp(MAX_HP);
			survivor_[nowCatchSurvNum_].lock()->ChangeStateInPlay(Survivor::STATE_INPLAY::IDLE);
			SetCatchSurvivorNo();
			effectController_->Stop((int)EFFECT_TYPE::DARKLIGHT);
		}
		return;
	}

	switch (statePlay_)
	{
	case Raider::STATE_INPLAY::CATCH:
	survivor_[nowCatchSurvNum_].lock()->ChangeStateInPlay(Survivor::STATE_INPLAY::CATCHED);
	survivor_[nowCatchSurvNum_].lock()->SetPlayAnimation((int)Survivor::ANIM_TYPE::FEAR,false,0.0f, ANIM_SPEED_30);
	if (animationController_->IsEnd())
	{
		ChangeStateInPlay(STATE_INPLAY::CHASE);
	}
	ChangePeekaboo(PEEKABOO_TYPE::CATCH);
		break;
	case Raider::STATE_INPLAY::CHASE:
		StartEffect(EFFECT_TYPE::DARKLIGHT);
		ChangePeekaboo(PEEKABOO_TYPE::CATCH);
		break;
	}
}

void Raider::KnockOuted(void)
{
	//	�����T�o�C�o�[�����V�[����
	ChangeState(STATE::DEAD);
}

