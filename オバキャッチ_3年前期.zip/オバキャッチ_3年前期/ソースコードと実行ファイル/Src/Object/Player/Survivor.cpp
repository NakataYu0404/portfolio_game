#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <DxLib.h>
#include "../Library/nlohmann/json.hpp"
#include "../../Application.h"
#include "../../Utility/Utility.h"
#include "../../Manager/InputManager.h"
#include "../../Manager/SceneManager.h"
#include "../../Manager/ResourceManager.h"
#include "../../Manager/Camera.h"
#include "../Common/EffectController.h"
#include "../Common/AnimationController.h"
#include "../Common/Capsule.h"
#include "../Common/Collider.h"
#include "../Common/CollisionManager.h"
#include "Raider.h"
#include "../Mob/FlashLight.h"
#include "Survivor.h"

Survivor::Survivor(int survivorNum, bool IsAI)
{
	SurvNum_ = survivorNum;
	isAi_ = IsAI;
	SetParam();
}

Survivor::~Survivor(void)
{
}

void Survivor::Init(void)
{
	transform_ = std::make_shared<Transform>();
	
	cpuMoveData_ = "Data/JSON/CPUMove.json";

	switch ((SURVIVOR_NUM)SurvNum_)
	{
	case SURVIVOR_NUM::SURV_ONE:
		transform_->SetModel(resMng_.LoadModelDuplicate(
			ResourceManager::SRC::MDL_SURVIVOR_1));
		transform_->pos = INIT_POS_PLAYER1;
		deadModelId_ = resMng_.LoadModelDuplicate(
			ResourceManager::SRC::MDL_SURVIVOR_1_DEAD);
		break;
	case SURVIVOR_NUM::SURV_TWO:
		transform_->SetModel(resMng_.LoadModelDuplicate(
			ResourceManager::SRC::MDL_SURVIVOR_2));
		transform_->pos = INIT_POS_PLAYER2;
		deadModelId_ = resMng_.LoadModelDuplicate(
			ResourceManager::SRC::MDL_SURVIVOR_2_DEAD);
		break;
	case SURVIVOR_NUM::SURV_THREE:
		transform_->SetModel(resMng_.LoadModelDuplicate(
			ResourceManager::SRC::MDL_SURVIVOR_3));
		transform_->pos = INIT_POS_PLAYER3;
		deadModelId_ = resMng_.LoadModelDuplicate(
			ResourceManager::SRC::MDL_SURVIVOR_3_DEAD);
		break;
	}

	//	���f���̊�{�ݒ�
	transform_->scl = Utility::VECTOR_ONE;
	transform_->headPos = MV1GetFramePosition(transform_->modelId, FRAME_HEAD);
	transform_->quaRot = Quaternion();
	transform_->quaRotLocal =
		Quaternion::Euler({ 0.0f, Utility::Deg2RadF(ROT_B), 0.0f });
	transform_->Update();
	//	�A�j���[�V�����̐ݒ�
	InitAnimation();

	transform_->MakeCollider(Collider::Category::SURVIVOR, Collider::TYPE::CAPSULE);
	//	�J�v�Z���R���C�_
	capsule_ = std::make_shared<Capsule>(transform_);
	capsule_->SetLocalPosTop(INIT_CAP_TOP);
	capsule_->SetLocalPosDown(INIT_CAP_DOWN);
	capsule_->SetRadius(INIT_CAP_RADIUS);

	flashLight_ = std::make_shared<FlashLight>(transform_,FRAME_HAND);
	flashLight_->Init();

	//	�ۉe�摜
	imgShadowHdl_ = resMng_.Load(ResourceManager::SRC::IMG_PLAYERSHADOW).handleId_;

	//	�������
	ChangeState(STATE::PLAY);

	//	�G�t�F�N�g�̏�����
	EffectInit();

	//	CPU������
	if (isAi_)
	{
		AiInit();
	}
}

void Survivor::SetParam(void)
{
	ForwardKey_ = KEY_INPUT_W;
	BackKey_ = KEY_INPUT_S;
	RightKey_ = KEY_INPUT_D;
	LeftKey_ = KEY_INPUT_A;

	animationController_ = nullptr;
	state_ = STATE::NONE;
	statePlay_ = STATE_INPLAY::IDLE;

	speed_ = SPEED_RUN;
	moveDir_ = Utility::VECTOR_ZERO;
	movePow_ = Utility::VECTOR_ZERO;
	movedPos_ = Utility::VECTOR_ZERO;

	playerRotY_ = Quaternion();
	goalQuaRot_ = Quaternion();
	stepRotTime_ = 0.0f;

	//	�Փ˃`�F�b�N
	gravHitPosDown_ = Utility::VECTOR_ZERO;
	gravHitPosUp_ = Utility::VECTOR_ZERO;

	imgShadowHdl_ = -1;

	gravityPow_ = DEFAULT_GRAVITY_POW;

	rotRad_ = 0.0f;

	hp_ = MAX_HP;

	reviveTimer_ = 0.0f;

	gotoNum_ = 0;
	alreadyPosNum_ = gotoNum_;

	sndHealIdHdl_ = resMng_.Load(ResourceManager::SRC::SND_HEAL).handleId_;
	sndGetBatteryIdHdl_ = resMng_.Load(ResourceManager::SRC::SND_GETBATTERY).handleId_;

	isInRange_ = false;
}

void Survivor::Update(void)
{

	//	�X�V�X�e�b�v
	switch (state_)
	{
	case Survivor::STATE::NONE:
		UpdateNone();
		break;
	case Survivor::STATE::PLAY:
		UpdatePlay();
		break;
	}

	flashLight_->Update();

	//	���f������X�V
	transform_->headPos = MV1GetFramePosition(transform_->modelId, FRAME_HEAD);

	transform_->Update();

}

void Survivor::Draw(bool isDrawRaiderWindow, int screenH)
{
	//	�A�j���[�V�����Đ�
	animationController_->Update();

	flashLight_->Draw();

	//	�ۉe�`��
	DrawShadow();

	//	���f���̕`��
	MV1DrawModel(transform_->modelId);

	effectController_->Draw();
}

bool Survivor::IsStateInPlay(STATE_INPLAY state)
{
	return statePlay_ == state;
}

void Survivor::SetRaider(std::weak_ptr<Raider> rai)
{
	raider_ = rai;
}

Survivor::STATE_INPLAY Survivor::GetStatePlay(void)
{
	return statePlay_;
}

void Survivor::InitAnimation(void)
{

	std::string path = Application::PATH_MODEL + "Player/Survivor/1.mv1";
	animationController_ = std::make_shared<AnimationController>(transform_->modelId);
	animationController_->Add((int)ANIM_TYPE::IDLE, path, ANIM_SPEED_20, ANIM_NUM_IDLE);
	animationController_->Add((int)ANIM_TYPE::RUN, path, ANIM_SPEED_20, ANIM_NUM_RUN);
	animationController_->Add((int)ANIM_TYPE::WALK, path, ANIM_SPEED_20, ANIM_NUM_WALK);
	animationController_->Add((int)ANIM_TYPE::VICTORY, path, ANIM_SPEED_20, ANIM_NUM_VICTORY);
	animationController_->Add((int)ANIM_TYPE::CRAWL, path, ANIM_SPEED_20, ANIM_NUM_CRAWL);
	animationController_->Add((int)ANIM_TYPE::FEAR, path, ANIM_SPEED_20, ANIM_NUM_FEAR);

	animationController_->Play((int)ANIM_TYPE::IDLE);

}

void Survivor::ChangeStateAnimation(void)
{

		switch (statePlay_)
		{
		case Survivor::STATE_INPLAY::NONE:
			break;
		case Survivor::STATE_INPLAY::IDLE:
			animationController_->Play((int)ANIM_TYPE::IDLE);
			break;
		case Survivor::STATE_INPLAY::MOVE:
			if (speed_ == SPEED_RUN)
			{
				animationController_->Play((int)ANIM_TYPE::RUN);
			}
			else
			{
				animationController_->Play((int)ANIM_TYPE::WALK);
			}
			break;
		case Survivor::STATE_INPLAY::CRAWL:
			animationController_->Play((int)ANIM_TYPE::CRAWL,false);
			break;
		default:
			break;
		}

}

void Survivor::UpdatePlay(void)
{

	auto& ins = InputManager::GetInstance();

	InputManager::JOYPAD_NO no;

	switch ((SURVIVOR_NUM)SurvNum_)
	{
	case SURVIVOR_NUM::SURV_ONE:
		no = InputManager::JOYPAD_NO::PAD2;
		break;
	case SURVIVOR_NUM::SURV_TWO:
		no = InputManager::JOYPAD_NO::PAD3;
		break;
	case SURVIVOR_NUM::SURV_THREE:
		no = InputManager::JOYPAD_NO::PAD4;
		break;
	}

	if (!IsStateInPlay(STATE_INPLAY::CATCHED) && !IsStateInPlay(STATE_INPLAY::CRAWL))
	{
		if (flashLight_->GetState() == FlashLight::STATE::ON)
		{
			speed_ = SPEED_WALK;
		}
		else
		{
			speed_ = SPEED_RUN;
		}

		if (raider_.lock()->GetState() != Raider::STATE::DEAD)
		{
			if (isAi_)
			{
				AiMove();
				flashLight_->SetLightPow(LIGHT_POW_ADD);
			}
			else
			{
				ProcessMove(SurvNum_ + ADD_CONTROLLER_RAIDER);
			}
		}

		if (IsMove())
		{
			ChangeStateInPlay(STATE_INPLAY::MOVE);
		}
		else
		{
			ChangeStateInPlay(STATE_INPLAY::IDLE);
		}
	}
	else
	{
		movePow_ = Utility::VECTOR_ZERO;
	}

	if ((!IsStateInPlay(STATE_INPLAY::CATCHED) && !IsStateInPlay(STATE_INPLAY::CRAWL)) && (ins.IsTrgDown(KEY_INPUT_Z) || ins.IsPadBtnTrgDown(no,InputManager::JOYPAD_BTN::DOWN)))
	{
		flashLight_->SwitchLight();
	}


	CatchedUpdate();

	//	�ړ������ɉ�������]
	Rotate();

	ChangeStateAnimation();

	//	�Փ˔���
	Collision();

	CalcDistance();

	//	��]������
	transform_->quaRot = playerRotY_;

	effectController_->Update();
}

void Survivor::UpdateVictory(void)
{
}

void Survivor::UpdateDead(void)
{
}

void Survivor::CatchedUpdate(void)
{
	if (!IsStateInPlay(STATE_INPLAY::CATCHED))
	{
		return;
	}


	//	�ߊl�����S�J��
	Damage(DAMAGE_POW);
	return;
}

void Survivor::Heal(void)
{
	if (!IsStateInPlay(STATE_INPLAY::CRAWL))
	{
		return;
	}

	reviveTimer_ ++;

	if (reviveTimer_ > MAX_REVIVE_TIMER)
	{
		StartEffect(EFFECT_TYPE::Heal);
		hp_ = MAX_HP;
		flashLight_->SetLightPow(LIGHT_POW_ADD);
		ChangeStateInPlay(STATE_INPLAY::IDLE);
		reviveTimer_ = MIN_REVIVE_TIMER;
		if (!CheckSoundMem(sndHealIdHdl_))
		{
			PlaySoundMem(sndHealIdHdl_, DX_PLAYTYPE_BACK, true);
		}
	}

}

void Survivor::ChangeStateInPlay(STATE_INPLAY state)
{
	statePlay_ = state;
}

void Survivor::OnCollision(std::weak_ptr<Collider> collider)
{
	switch (collider.lock()->category_)
	{
	case Collider::Category::SURVIVOR:
		break;
	case Collider::Category::RAIDER:
		if (IsStateInPlay(STATE_INPLAY::CRAWL) || IsStateInPlay(STATE_INPLAY::CATCHED) || !raider_.lock()->IsCanCatch())
		{
			return;
		}
		raider_.lock()->SetCatchSurvivorNo(SurvNum_);
		flashLight_->SwitchLight(FlashLight::STATE::OFF);
		ControllerVibration(MAX_VIBRATION_POW, VIBRATION_TIME_DEAD);
		break;
	case Collider::Category::BATTERY:
		flashLight_->AddPower(LIGHT_POW_ADD);
		if (!CheckSoundMem(sndGetBatteryIdHdl_))
		{
			PlaySoundMem(sndGetBatteryIdHdl_, DX_PLAYTYPE_BACK, true);
		}
		break;
	case Collider::Category::STAGE:
		transform_->pos = collider.lock()->hitInfo_.movedPos;
		transform_->Update();
		break;
	case Collider::Category::MAGICSHOT:
		flashLight_->AddPower(LIGHT_POW_DECREASE);
		break;
	default:
		break;
	}

}

void Survivor::OnCollision(Collider::Category category)
{
	switch (category)
	{
	case Collider::Category::RAIDER:
		break;
	case Collider::Category::SURVIVOR:
		break;
	case Collider::Category::STAGE:
		break;
	case Collider::Category::LIGHT:
		Heal();
		break;
	default:
		break;
	}
}

void Survivor::AiInit(void)
{
	//	CPU���i�H��ύX����n�_�ƁA���̒n�_����s����ꏊ�̓o�^
	std::ifstream file(cpuMoveData_);
	if (!file.is_open()) {
		std::cerr << "Failed to open the JSON file!" << std::endl;
		return;
	}
	nlohmann::json jsonData;
	file >> jsonData;

	// CPU�����񂷂�n�_�̓ǂݍ���
	for (const auto& pos : jsonData["AiGotoPos"]) {
		aiGotoPos_.push_back({ pos["x"], pos["y"], pos["z"] });
	}

	// CPU���������n�_����A�ŒZ�Ō}����n�_�̓ǂݍ���
	for (const auto& anchor : jsonData["Anchors"]) {
		Anchor temp;
		temp.pos = aiGotoPos_[anchor["pos"]]; // �C���f�b�N�X���g���č��W���擾
		for (const auto& no : anchor["canGoNo"]) {
			temp.canGoNo.push_back(no);
		}
		anchors_.push_back(temp);
	}
}

void Survivor::AiMove(void)
{
	//	TODO:4�l�p�Q�[���Ƃ��č�������߁A�}�����炦��1�l�p���ƂĂ����e���Ȃ��̂ɂȂ��Ă��܂��Ă���B�G���߂����□�������񂾂Ƃ��́A�����ƃ{�N�c�ݹ����ցc���Ċ����̑������������悤�ɂ�����
	bool pushForward = false;
	bool pushBack = false;
	bool pushLeft = false;
	bool pushRight = false;

	if (transform_->pos.x > anchors_[gotoNum_].pos.x + SPEED_RUN)
	{
		pushLeft = true;
	}
	else if (transform_->pos.x < anchors_[gotoNum_].pos.x - SPEED_RUN)
	{
		pushRight = true;
	}
	else if (transform_->pos.z > anchors_[gotoNum_].pos.z + SPEED_RUN)
	{
		pushBack = true;
	}
	else if (transform_->pos.z < anchors_[gotoNum_].pos.z - SPEED_RUN)
	{
		pushForward = true;
	}
	else
	{
		int newGotoNum;
		do
		{
			newGotoNum = anchors_[gotoNum_].canGoNo[Application::GetInstance().GetRandomNum((int)anchors_[gotoNum_].canGoNo.size() - 1)];
		} while (newGotoNum == alreadyPosNum_);

		// �ړ��悪���肵����alreadyPosNum_���X�V
		alreadyPosNum_ = gotoNum_;
		gotoNum_ = newGotoNum;
	}

	//	�ړ��ʂ��[��
	movePow_ = Utility::VECTOR_ZERO;

	//	X����]���������A�d�͕����ɐ����ȃJ�����p�x(XZ����)���擾
	Quaternion cameraRot = SceneManager::GetInstance().GetCamera()->GetQuaRotOutX();

	VECTOR dir = Utility::VECTOR_ZERO;

	//	�i�݂��������̃L�[��������Ă��邩

	//	�J���������ɑO�i������
	if (pushForward)
	{
		rotRad_ = Utility::Deg2RadF(ROT_F);
		dir = DIR_F;
	}
	//	�J�������������ނ�����
	if (pushBack)
	{
		rotRad_ = Utility::Deg2RadF(ROT_B);
		dir = DIR_B;
	}
	//	�J������������E���ֈړ�������
	if (pushRight)
	{
		rotRad_ = Utility::Deg2RadF(ROT_R);
		dir = DIR_R;
	}
	//	�J�����������獶���ֈړ�������
	if (pushLeft)
	{
		rotRad_ = Utility::Deg2RadF(ROT_L);
		dir = DIR_L;
	}

	if (!Utility::EqualsVZero(dir)) {

		moveDir_ = dir;
		movePow_ = VScale(dir, speed_);

		//	��]����
		SetGoalRotate(rotRad_);

	}
	else
	{
	}

}

void Survivor::EffectInit(void)
{
	effectController_ = std::make_shared<EffectController>();

	EffCosmicsmokeId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_COSMICSMOKE).handleId_;
	EffBluebloodId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_BLUEBLOOD).handleId_;
	EffHealId_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::EFF_HEAL).handleId_;

	effectController_->Add((int)EFFECT_TYPE::COSMICSMOKE, EffCosmicsmokeId_);
	effectController_->Add((int)EFFECT_TYPE::BLUEBLOOD, EffBluebloodId_);
	effectController_->Add((int)EFFECT_TYPE::Heal, EffHealId_);
}

void Survivor::StartEffect(EFFECT_TYPE type)
{
	switch (type)
	{
	case Survivor::EFFECT_TYPE::COSMICSMOKE:
		effectController_->Play((int)EFFECT_TYPE::COSMICSMOKE, false);
		effectController_->TransUpdate((int)EFFECT_TYPE::COSMICSMOKE, transform_->headPos, EFFECT_SIZE, Utility::VECTOR_ZERO);
		break;
	case Survivor::EFFECT_TYPE::BLUEBLOOD:
		effectController_->Play((int)EFFECT_TYPE::BLUEBLOOD, false);
		effectController_->TransUpdate((int)EFFECT_TYPE::BLUEBLOOD, transform_->headPos, EFFECT_SIZE, Utility::VECTOR_ZERO);
		break;
	case Survivor::EFFECT_TYPE::Heal:
		effectController_->Play((int)EFFECT_TYPE::Heal, false);
		effectController_->TransUpdate((int)EFFECT_TYPE::Heal, transform_->pos, EFFECT_SIZE, Utility::VECTOR_ZERO);
		break;
	default:
		break;
	}
}

int Survivor::GetDeadModelId(void)
{
	return deadModelId_;
}

int Survivor::GetLightPow(void)
{
	return flashLight_->GetLightPow();
}

void Survivor::ControllerVibration(int pow,int time)
{
	switch ((SURVIVOR_NUM)SurvNum_)
	{
	case SURVIVOR_NUM::SURV_ONE:
		StartJoypadVibration(DX_INPUT_PAD2, pow, time);
		break;
	case SURVIVOR_NUM::SURV_TWO:
		StartJoypadVibration(DX_INPUT_PAD3, pow, time);
		break;
	case SURVIVOR_NUM::SURV_THREE:
		StartJoypadVibration(DX_INPUT_PAD4, pow, time);
		break;
	}
}

float Survivor::GetReviveTimer(void)
{
	return reviveTimer_;
}

float Survivor::GetMaxReviveTimer(void)
{
	return MAX_REVIVE_TIMER;
}

void Survivor::SetHp(int hp)
{
	hp_ = hp;
}

bool Survivor::IsInRaiderRange(void)
{
	return isInRange_;
}

void Survivor::KnockOuted(void)
{
	raider_.lock()->SetCatchSurvivorNo();
	ChangeStateInPlay(STATE_INPLAY::CRAWL);
}

void Survivor::CalcDistance(void)
{
	if (IsStateInPlay(STATE_INPLAY::CRAWL))
	{
		return;
	}

	float range = Myself2OtherDistance2D(raider_.lock()->GetTransform());

	if (range < Raider::VIBRATION_RANGE)
	{
		ControllerVibration(HALF_VIBRATION_POW - (int)range, VIBRATION_CNT_60);
		isInRange_ = true;
	}
	else
	{
		isInRange_ = false;
	}
}
