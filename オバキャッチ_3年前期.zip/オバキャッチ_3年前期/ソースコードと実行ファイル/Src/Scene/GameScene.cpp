#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <DxLib.h>
#include "../Library/nlohmann/json.hpp"
#include "../Application.h"
#include "../Utility/Utility.h"
#include "../Manager/SceneManager.h"
#include "../Manager/Camera.h"
#include "../Manager/InputManager.h"
#include "../Manager/ResourceManager.h"
#include "../Render/PSMaterial.h"
#include "../Render/PSMeshRenderer.h"
#include "../Object/Common/Capsule.h"
#include "../Object/Common/Collider.h"
#include "../Object/Common/CollisionManager.h"
#include "../Object/SkyDome.h"
#include "../Object/Stage.h"
#include "../Object/Player/PlayerBase.h"
#include "../Object/Player/Raider.h"
#include "../Object/Player/Survivor.h"
#include "../Object/Mob/Victim.h"
#include "../Object/Mob/FlashLight.h"
#include "GameScene.h"

GameScene::GameScene(void) : colMng_(CollisionManager::GetInstance()), skyDome_(nullptr), stage_(nullptr), raider_(nullptr), survivors_({nullptr,nullptr,nullptr}), batterys_(0),
							ScreenMainHdl_(-1), Screen3DHdl_(-1), Screen2DHdl_(-1), ScreenUIHdl_(-1), raiderOpeImgHdl_(-1), survivorOpeImgHdl_(-1),
							imgHeartpinkIdHdl_(-1), imgHeartgrayIdHdl_(-1), imgBatteryIdHdl_(-1), imgBatteryredIdHdl_(-1), imgBatteryemptyIdHdl_(-1),
							imgAlreadyRaiHdl_(-1), imgAlreadySurHdl_(-1), imgAlreadyOkHdl_(-1), imgUiframeHdl_(-1), imgWinRaiHdl_(-1), imgWinSurHdl_(-1),
							imgWinDraHdl_(-1), imgRaiderHdl_(-1), imgSurHatenaHdl_(-1), imgSurBikkuriHdl_(-1), imgSurBikkuri2Hdl_(-1), wait2gameTimer_(-1), 
							imgsNumberEnemyHdl_(nullptr), imgsNumberTimeHdl_(nullptr), sndBgmHdl_(-1), sndWinRaiderHdl_(-1), sndWinSurvivorHdl_(-1),
							sndWinDrawHdl_(-1), isP1Already_(false), isP2Already_(false), isP3Already_(false), isP4Already_(false), BatteryBornPos_(0),
							postEffectScreenMonoHdl_(-1), postEffectScreenScanLineHdl_(-1), monoShaderHdl_(-1), scanLineShaderHdl_(-1), timeBuf_(-1), 
							totalTime_(-1), GameTimer_(-1), stopGameTimer_(false), psScanMaterial_(nullptr), psScanRenderer_(nullptr), psMonoMaterial_(nullptr),
							psMonoRenderer_(nullptr), wintype_(), inSceneType_(), isMakedBatteryMinits_({false,false,false})
{

}

GameScene::~GameScene(void)
{
	CollisionManager::GetInstance().ClearCollider();
	DeleteGraph(postEffectScreenMonoHdl_);
	DeleteGraph(postEffectScreenScanLineHdl_);
	DeleteShader(scanLineShaderHdl_);
	DeleteShader(monoShaderHdl_);
	DeleteShaderConstantBuffer(timeBuf_);
	
}

void GameScene::Init(void)
{
	GameTimer_ = TIME_FPS * TIME_FPS * 5;
	inSceneType_ = InGameSceneType::START;

	//	���C�_�[
	raider_ = std::make_shared<Raider>();
	raider_->Init();

	//	�T�o�C�o�[�쐬
	std::array<std::weak_ptr<Survivor>, SURVIVOR_NUM> surviveWeakArray;

	for (int i = 0; i < survivors_.size(); i++)
	{
		if (plNum_ == SceneManager::PLNUM::SOLO)
		{
			survivors_[i] = std::make_shared<Survivor>(i,true);
		}
		else
		{
			survivors_[i] = std::make_shared<Survivor>(i);
		}
		survivors_[i]->SetRaider(raider_);
		survivors_[i]->Init();
		surviveWeakArray[i] = survivors_[i];
	}

	//	���C�_�[�ɃT�o�C�o�[����n��
	raider_->SetSurvivor(surviveWeakArray);

	//	�X�e�[�W
	stage_ = std::make_shared<Stage>();

	//	�X�e�[�W�ɑ΂��ē����蔻��t����I�u�W�F�N�g��n���񂾂��ǁAsharedptr��z��ɂ����Ⴄ�ƁA�n���Ƃ������weakptr�ɕϊ����Ă���Ȃ��Ȃ����Ⴄ�݂����B
	//	�Ȃ̂ŁA��������weak�^�̔z��Ɉڂ��ւ��āA�����n�����Ƃɂ���
	std::array<std::weak_ptr<Survivor>, SURVIVOR_NUM> tmpSurvivor;
	for (int i = 0; i < survivors_.size(); i++)
	{
		tmpSurvivor[i] = survivors_[i];
	}
	stage_->SetObject(raider_, tmpSurvivor);
	stage_->Init();

	for (int i = 0; i < survivors_.size(); i++)
	{
		survivors_[i]->AddCollider(stage_->GetTransform().lock()->collider_);
	}

	//	�X�J�C�h�[��
	skyDome_ = std::make_unique<SkyDome>();
	skyDome_->Init();
	skyDome_->SetPlayer(raider_);

	colMng_.Init();

	colMng_.Add(raider_);
	colMng_.Add(survivors_[0]);
	colMng_.Add(survivors_[1]);
	colMng_.Add(survivors_[2]);
	colMng_.Add(stage_);

	SceneManager::GetInstance().GetCamera()->SetFollow(raider_->GetTransform().lock().get());
	SceneManager::GetInstance().GetCamera()->ChangeMode(Camera::MODE::FIXED_POINT);


	ScreenMainHdl_ = MakeScreen(Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, true);
	Screen3DHdl_ = MakeScreen(Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, true);
	ScreenUIHdl_ = MakeScreen(Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, true);
	Screen2DHdl_ = MakeScreen(Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, true);

#pragma region InitResource

	raiderOpeImgHdl_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::IMG_RAIDER_OPERATE).handleId_;
	survivorOpeImgHdl_ = ResourceManager::GetInstance().Load(ResourceManager::SRC::IMG_SURVIVOR_OPERATE).handleId_;

	imgHeartpinkIdHdl_ = resMng_.Load(ResourceManager::SRC::IMG_HEART_PINK).handleId_;
	imgHeartgrayIdHdl_ = resMng_.Load(ResourceManager::SRC::IMG_HEART_GRAY).handleId_;

	imgBatteryIdHdl_ = resMng_.Load(ResourceManager::SRC::IMG_BATTERY).handleId_;
	imgBatteryredIdHdl_ = resMng_.Load(ResourceManager::SRC::IMG_BATTERY_RED).handleId_;
	imgBatteryemptyIdHdl_ = resMng_.Load(ResourceManager::SRC::IMG_BATTERY_EMPTY).handleId_;

	imgUiframeHdl_ = resMng_.Load(ResourceManager::SRC::IMG_UI_FRAME).handleId_;

	imgsNumberEnemyHdl_ = resMng_.Load(ResourceManager::SRC::imgSHdl_NUM_ENEMY).handleIds_;
	imgsNumberTimeHdl_ = resMng_.Load(ResourceManager::SRC::imgSHdl_NUM_TIME).handleIds_;

	imgAlreadyRaiHdl_ = resMng_.Load(ResourceManager::SRC::IMG_ALREADY_RAIDER).handleId_;
	imgAlreadySurHdl_ = resMng_.Load(ResourceManager::SRC::IMG_ALREADY_SURVIVOR).handleId_;
	imgAlreadyOkHdl_ = resMng_.Load(ResourceManager::SRC::IMG_OK).handleId_;

	imgWinRaiHdl_ = resMng_.Load(ResourceManager::SRC::IMG_WIN_RAIDER).handleId_;
	imgWinSurHdl_ = resMng_.Load(ResourceManager::SRC::IMG_WIN_SURVIVOR).handleId_;
	imgWinDraHdl_ = resMng_.Load(ResourceManager::SRC::IMG_WIN_DRAW).handleId_;

	imgRaiderHdl_ = resMng_.Load(ResourceManager::SRC::IMG_RAIDER).handleId_;

	imgSurHatenaHdl_ = resMng_.Load(ResourceManager::SRC::IMG_SURVIVOR_HATENA).handleId_;
	imgSurBikkuriHdl_ = resMng_.Load(ResourceManager::SRC::IMG_SURVIVOR_BIKKURI).handleId_;
	imgSurBikkuri2Hdl_ = resMng_.Load(ResourceManager::SRC::IMG_SURVIVOR_BIKKURI2).handleId_;

	sndBgmHdl_ = resMng_.Load(ResourceManager::SRC::SND_BGM).handleId_;
	sndWinRaiderHdl_ = resMng_.Load(ResourceManager::SRC::SND_WIN_RAIDER).handleId_;
	sndWinSurvivorHdl_ = resMng_.Load(ResourceManager::SRC::SND_WIN_SURVIVOR).handleId_;
	sndWinDrawHdl_ = resMng_.Load(ResourceManager::SRC::SND_WIN_DRAW).handleId_;

#pragma endregion

#pragma region InitBattery
	// JSON�t�@�C���̓ǂݍ���
	BatteryBornData_ = "Data/JSON/BatteryBorn.json";
	std::ifstream file(BatteryBornData_);
	if (!file.is_open()) {
		std::cerr << "Failed to open the JSON file!" << std::endl;
		return;
	}

	nlohmann::json jsonData;
	file >> jsonData;

	// BatteryBornPos�̓ǂݍ���
	for (const auto& pos : jsonData["BatteryBornPos"]) {
		BatteryBornPos_.push_back({ pos["x"], pos["y"], pos["z"] });
	}
#pragma endregion

	totalTime_ = 1.0f;

	isP1Already_ = false;
	isP2Already_ = false;
	isP3Already_ = false;
	isP4Already_ = false;

	postEffectScreenMonoHdl_ = MakeScreen(Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, true);
	postEffectScreenScanLineHdl_ = MakeScreen(Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, true);

	//	��Z�F
	FLOAT4 multColor = { 0.8f,1.0f,0.8f,1.0f };
	
	//	���m�g�[��
	psMonoMaterial_ = std::make_shared<PSMaterial>("Monotone.cso", 1);
	psMonoRenderer_ = std::make_shared<PSMeshRenderer>(psMonoMaterial_);
	psMonoMaterial_->AddConstBuffer(multColor);
	psMonoMaterial_->AddTexture(Screen3DHdl_);

	//	������
	psScanMaterial_ = std::make_shared<PSMaterial>("ScanLine.cso", 1);
	psScanRenderer_ = std::make_shared<PSMeshRenderer>(psScanMaterial_);
	psScanMaterial_->AddConstBuffer(totalTime_);
	psScanMaterial_->AddTexture(postEffectScreenMonoHdl_);

	timeBuf_ = CreateShaderConstantBuffer(sizeof(FLOAT4) * 1);

	wait2gameTimer_ = TIME_FPS * 6;
}

void GameScene::Update(void)
{
	switch (inSceneType_)
	{
	case GameScene::InGameSceneType::START:
		StartUpdate();
		break;
	case GameScene::InGameSceneType::GAME:
		GameUpdate();
		break;
	case GameScene::InGameSceneType::OVER:
		OverUpdate();
		break;
	}
}

void GameScene::Draw(bool isDrawRaiderview)
{
	//	3D�`��p�X�N���[����`��Ώۂ�
	SetDrawScreen(Screen3DHdl_);
	ClsDrawScreen();

	//	3D�`��
	Draw3D(isDrawRaiderview);

	//	2D�`��p�X�N���[����`��Ώۂ�
	SetDrawScreen(Screen2DHdl_);
	ClsDrawScreen();

	//	2D�`��
	Draw2D(isDrawRaiderview);

	//	UI�`��p�X�N���[����`��Ώۂ�
	SetDrawScreen(ScreenUIHdl_);
	ClsDrawScreen();

	//	UI�`��
	DrawUI(isDrawRaiderview);

	//	���̗p�X�N���[����`��Ώۂ�
	SetDrawScreen(ScreenMainHdl_);
	ClsDrawScreen();

	//	�e�X�N���[���`��
	DrawGraph(0, 0, Screen3DHdl_, false);
	DrawGraph(0, 0, Screen2DHdl_, true);
	DrawGraph(0, 0, ScreenUIHdl_, true);

	SetDrawScreen(DX_SCREEN_BACK);
	ClsDrawScreen();

	DrawGraph(0, 0, ScreenMainHdl_, false);


	//// �w���v
	//DrawFormatString(840, 50, 0x000000, "plPos1:x(%.0f)y(%.0f)z(%.0f)", survivors_[0]->GetTransform().lock()->pos.x, survivors_[0]->GetTransform().lock()->pos.y, survivors_[0]->GetTransform().lock()->pos.z);
}
void GameScene::StartUpdate(void)
{
	InputManager& ins = InputManager::GetInstance();
	
	//	�e�v���C���[���Ƃ̏��������m�F
	if (ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::DOWN) || ins.IsTrgDown(KEY_INPUT_SPACE))
	{
		isP1Already_ = true;
		StartJoypadVibration(DX_INPUT_PAD1, VIBRATION_POWER, TIME_FPS);
	}
	if (ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD2, InputManager::JOYPAD_BTN::DOWN) || ins.IsTrgDown(KEY_INPUT_SPACE))
	{
		isP2Already_ = true;
		StartJoypadVibration(DX_INPUT_PAD2, VIBRATION_POWER, TIME_FPS);
	}
	if (ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD3, InputManager::JOYPAD_BTN::DOWN) || ins.IsTrgDown(KEY_INPUT_SPACE))
	{
		isP3Already_ = true;
		StartJoypadVibration(DX_INPUT_PAD3, VIBRATION_POWER, TIME_FPS);
	}
	if (ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD4, InputManager::JOYPAD_BTN::DOWN) || ins.IsTrgDown(KEY_INPUT_SPACE))
	{
		isP4Already_ = true;
		StartJoypadVibration(DX_INPUT_PAD4, VIBRATION_POWER, TIME_FPS);
	}

	//	�Q�[���J�n�܂ł̃J�E���g�_�E��
	if ((isP1Already_ && plNum_ == SceneManager::PLNUM::SOLO) || isP1Already_ && isP2Already_ && isP3Already_ && isP4Already_)
	{
		if (wait2gameTimer_ < 0)
		{
			wait2gameTimer_ = TIME_FPS * 5;
			ChangeInGameType(InGameSceneType::GAME);
			PlaySoundMem(sndBgmHdl_, DX_PLAYTYPE_LOOP, true);
		}
		wait2gameTimer_ -= 2;
	}
}

void GameScene::GameUpdate(void)
{

	//	�V�[���J��
	InputManager& ins = InputManager::GetInstance();

	if (survivors_[0]->IsStateInPlay(Survivor::STATE_INPLAY::CRAWL) &&
		survivors_[1]->IsStateInPlay(Survivor::STATE_INPLAY::CRAWL) &&
		survivors_[2]->IsStateInPlay(Survivor::STATE_INPLAY::CRAWL) &&
		!raider_->IsEndGameOverShow())
	{
		//	�Q�[���I�[�o�[
		raider_->ChangeState(Raider::STATE::VICTORY);
		ElapseGameTimer(true);
	}
	else if (survivors_[0]->IsStateInPlay(Survivor::STATE_INPLAY::CRAWL) &&
			survivors_[1]->IsStateInPlay(Survivor::STATE_INPLAY::CRAWL) &&
			survivors_[2]->IsStateInPlay(Survivor::STATE_INPLAY::CRAWL) &&
			raider_->IsEndGameOverShow())
	{
		//	�Q�[���I���
		GameOver(WinType::RAIDER);
		return;
	}

	if (raider_->GetState() == Raider::STATE::DEAD)
	{
		ElapseGameTimer(true);
		if (raider_->IsEndGameOverShow())
		{
			GameOver(WinType::SURVIVOR);
		}
	}

	if (GameTimer_ <= 0)
	{
		GameOver(WinType::DRAW);
	}

	skyDome_->Update();

	stage_->Update();
	stage_->SetTimer(totalTime_);

	raider_->Update();

	if (!raider_->IsStateInPlay(Raider::STATE_INPLAY::CATCH))
	{
		for (auto& s : survivors_)
		{
			if (s == nullptr)
			{
				break;
			}
			s->Update();
		}

		for (auto& v : batterys_)
		{
			if (v == nullptr)
			{
				break;
			}
			v->Update();
		}
	}


	colMng_.Update();

	auto cam = SceneManager::GetInstance().GetCamera();

	if (raider_->IsStateInPlay(Raider::STATE_INPLAY::CATCH))
	{
		cam->ChangeMode(Camera::MODE::FOLLOW_ZOOMIN);
	}
	else if (raider_->IsStateInPlay(Raider::STATE_INPLAY::CHASE) && cam->GetMode() != Camera::MODE::FIXED_POINT)
	{
		cam->ChangeMode(Camera::MODE::FOLLOW_ZOOMOUT);
	}
	else
	{
		cam->ChangeMode(Camera::MODE::FIXED_POINT);
	}

	MakeBattery();

	AddTotalTime();

	ElapseGameTimer();
}

void GameScene::OverUpdate(void)
{
	InputManager& ins = InputManager::GetInstance();

	switch (wintype_)
	{
	case GameScene::WinType::RAIDER:
		break;
	case GameScene::WinType::SURVIVOR:
		break;
	case GameScene::WinType::DRAW:
		break;
	default:
		break;
	}
	
	if (ins.IsTrgDown(KEY_INPUT_SPACE) ||
		ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::DOWN) ||
		ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD2, InputManager::JOYPAD_BTN::DOWN) ||
		ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD3, InputManager::JOYPAD_BTN::DOWN) ||
		ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD4, InputManager::JOYPAD_BTN::DOWN))
	{
		SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::TITLE);
	}
}

void GameScene::ChangeInGameType(InGameSceneType type)
{
	inSceneType_ = type;
}

void GameScene::MakeBattery(void)
{
	int gameTimerInt = (int)GameTimer_;
	for (int s = 0; s < survivors_.size(); s++)
	{
		bool isMaked_ = false;
		if (survivors_[s]->GetLightPow() <= 70)
		{
			if (gameTimerInt / TIME_FPS % TIME_FPS / 10 == 0)
			{
				if (isMakedBatteryMinits_[s])
				{
					return;
				}

				isMakedBatteryMinits_[s] = true;

				//	�e�̍쐬
				for (auto& i : batterys_)
				{
					//	i��null�Ȃ̂͒e���쐬���Ă��Ȃ����̂�
					if (i == nullptr)
					{
						break;
					}
					//	���񂾒e���ė��p(push_back�͏d��)
					if (i->IsAlive() == false)
					{
						i->Init();
						i->SetPos(BatteryBornPos_[Application::GetInstance().GetRandomNum((int)BatteryBornPos_.size() - 1)]);
						//	���dHit��h�����ߓ���������R���C�_�͏�����悤�ɂ��Ă���̂ŁA�ēx�o�^
						colMng_.Add(i);
						isMaked_ = true;
						break;
					}
				}
				if (isMaked_)
				{
					continue;
				}
				//	�e��V�K�쐬
				std::shared_ptr<Battery> vic = std::make_shared<Battery>();
				vic->Init();
				vic->SetPos(BatteryBornPos_[Application::GetInstance().GetRandomNum((int)BatteryBornPos_.size() - 1)]);
				batterys_.push_back(vic);
				colMng_.Add(vic);
			}
			else
			{
				isMakedBatteryMinits_[s] = false;
			}
		}
	}
}

void GameScene::Draw3D(bool isDrawRaiderview)
{
	SceneManager::GetInstance().GetCamera()->SetBeforeDraw();

	// �w�i
	skyDome_->Draw();
	stage_->Draw(isDrawRaiderview, Screen3DHdl_);

	raider_->Draw(isDrawRaiderview);

	if (isDrawRaiderview && raider_->IsPeekaboo(Raider::PEEKABOO_TYPE::INVISIBLE))
	{
		// �|�X�g�G�t�F�N�g��K�p����
		psMonoRenderer_->Draw(postEffectScreenMonoHdl_);
		psScanMaterial_->ChangeConstBuffer(0, totalTime_);
		psScanRenderer_->Draw(postEffectScreenScanLineHdl_);

		// �|�X�g�G�t�F�N�g�K�p��̃X�N���[���ɕ`�悷��
		SetDrawScreen(Screen3DHdl_);
		DrawGraph(0, 0, postEffectScreenMonoHdl_, false);
		DrawGraph(0, 0, postEffectScreenScanLineHdl_, false);
	}

	SceneManager::GetInstance().GetCamera()->SetBeforeDraw();

	// �|�X�g�G�t�F�N�g�K�p��� survivor ��`��
	for (auto& s : survivors_)
	{
		if (s == nullptr)
		{
			break;
		}
		s->Draw();
	}

	for (auto& v : batterys_)
	{
		if (v == nullptr)
		{
			break;
		}
		v->Draw();
	}

}

void GameScene::Draw2D(bool isDrawRaiderview)
{
	SceneManager::GetInstance().GetCamera()->SetBeforeDraw();

	if (inSceneType_ != InGameSceneType::OVER)
	{

		if (survivors_[0]->GetStatePlay() == Survivor::STATE_INPLAY::CRAWL)
		{
			float timer = survivors_[0]->GetReviveTimer();

			float scale = timer / survivors_[0]->GetMaxReviveTimer();

			DrawExtendGraph3D(survivors_[0]->GetTransform().lock()->headPos.x,
				survivors_[0]->GetTransform().lock()->headPos.y,
				survivors_[0]->GetTransform().lock()->headPos.z, 1.0f, 1.0f, imgHeartgrayIdHdl_, true);

			DrawExtendGraph3D(survivors_[0]->GetTransform().lock()->headPos.x,
				survivors_[0]->GetTransform().lock()->headPos.y,
				survivors_[0]->GetTransform().lock()->headPos.z, scale, scale, imgHeartpinkIdHdl_, true);
		}
		else if (isDrawRaiderview == true)
		{
			if (!raider_->IsPeekaboo(Raider::PEEKABOO_TYPE::INVISIBLE))
			{
				DrawExtendGraph3D(survivors_[0]->GetTransform().lock()->headPos.x,
					survivors_[0]->GetTransform().lock()->headPos.y,
					survivors_[0]->GetTransform().lock()->headPos.z+100.0f, 1.0f, 1.0f, imgSurBikkuri2Hdl_, true);
			}
			else
			{
				if (survivors_[0]->IsInRaiderRange())
				{
					DrawExtendGraph3D(survivors_[0]->GetTransform().lock()->headPos.x,
						survivors_[0]->GetTransform().lock()->headPos.y,
						survivors_[0]->GetTransform().lock()->headPos.z + 100.0f, 1.0f, 1.0f, imgSurBikkuriHdl_, true);
				}
				else
				{
					DrawExtendGraph3D(survivors_[0]->GetTransform().lock()->headPos.x,
						survivors_[0]->GetTransform().lock()->headPos.y,
						survivors_[0]->GetTransform().lock()->headPos.z + 100.0f, 1.0f, 1.0f, imgSurHatenaHdl_, true);
				}
			}
		}

		if (survivors_[1]->GetStatePlay() == Survivor::STATE_INPLAY::CRAWL)
		{
			float timer = survivors_[1]->GetReviveTimer();

			float scale = timer / survivors_[1]->GetMaxReviveTimer();

			DrawExtendGraph3D(survivors_[1]->GetTransform().lock()->headPos.x,
				survivors_[1]->GetTransform().lock()->headPos.y,
				survivors_[1]->GetTransform().lock()->headPos.z, 1.0f, 1.0f, imgHeartgrayIdHdl_, true);
			DrawExtendGraph3D(survivors_[1]->GetTransform().lock()->headPos.x,
				survivors_[1]->GetTransform().lock()->headPos.y,
				survivors_[1]->GetTransform().lock()->headPos.z, scale, scale, imgHeartpinkIdHdl_, true);

		}
		else if (isDrawRaiderview == true)
		{
			if (!raider_->IsPeekaboo(Raider::PEEKABOO_TYPE::INVISIBLE))
			{
				DrawExtendGraph3D(survivors_[1]->GetTransform().lock()->headPos.x,
					survivors_[1]->GetTransform().lock()->headPos.y,
					survivors_[1]->GetTransform().lock()->headPos.z + 100.0f, 1.0f, 1.0f, imgSurBikkuri2Hdl_, true);
			}
			else
			{
				if (survivors_[1]->IsInRaiderRange())
				{
					DrawExtendGraph3D(survivors_[1]->GetTransform().lock()->headPos.x,
						survivors_[1]->GetTransform().lock()->headPos.y,
						survivors_[1]->GetTransform().lock()->headPos.z + 100.0f, 1.0f, 1.0f, imgSurBikkuriHdl_, true);
				}
				else
				{
					DrawExtendGraph3D(survivors_[1]->GetTransform().lock()->headPos.x,
						survivors_[1]->GetTransform().lock()->headPos.y,
						survivors_[1]->GetTransform().lock()->headPos.z + 100.0f, 1.0f, 1.0f, imgSurHatenaHdl_, true);
				}
			}
		}

		if (survivors_[2]->GetStatePlay() == Survivor::STATE_INPLAY::CRAWL)
		{
			float timer = survivors_[2]->GetReviveTimer();

			float scale = timer / survivors_[2]->GetMaxReviveTimer();

			DrawExtendGraph3D(survivors_[2]->GetTransform().lock()->headPos.x,
				survivors_[2]->GetTransform().lock()->headPos.y,
				survivors_[2]->GetTransform().lock()->headPos.z, 1.0f, 1.0f, imgHeartgrayIdHdl_, true);
			DrawExtendGraph3D(survivors_[2]->GetTransform().lock()->headPos.x,
				survivors_[2]->GetTransform().lock()->headPos.y,
				survivors_[2]->GetTransform().lock()->headPos.z, scale, scale, imgHeartpinkIdHdl_, true);

		}
		else if (isDrawRaiderview == true)
		{
			if (!raider_->IsPeekaboo(Raider::PEEKABOO_TYPE::INVISIBLE))
			{
				DrawExtendGraph3D(survivors_[2]->GetTransform().lock()->headPos.x,
					survivors_[2]->GetTransform().lock()->headPos.y,
					survivors_[2]->GetTransform().lock()->headPos.z + 100.0f, 1.0f, 1.0f, imgSurBikkuri2Hdl_, true);
			}
			else
			{
				if (survivors_[2]->IsInRaiderRange())
				{
					DrawExtendGraph3D(survivors_[2]->GetTransform().lock()->headPos.x,
						survivors_[2]->GetTransform().lock()->headPos.y,
						survivors_[2]->GetTransform().lock()->headPos.z + 100.0f, 1.0f, 1.0f, imgSurBikkuriHdl_, true);
				}
				else
				{
					DrawExtendGraph3D(survivors_[2]->GetTransform().lock()->headPos.x,
						survivors_[2]->GetTransform().lock()->headPos.y,
						survivors_[2]->GetTransform().lock()->headPos.z + 100.0f, 1.0f, 1.0f, imgSurHatenaHdl_, true);
				}
			}
		}

		if (survivors_[0]->GetLightPow() <= 70 && survivors_[0]->GetLightPow() > 0)
		{
			DrawExtendGraph3D(survivors_[0]->GetTransform().lock()->pos.x,
				survivors_[0]->GetTransform().lock()->pos.y,
				survivors_[0]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryIdHdl_, true);
			DrawExtendGraph3D(survivors_[0]->GetTransform().lock()->pos.x,
				survivors_[0]->GetTransform().lock()->pos.y,
				survivors_[0]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryredIdHdl_, true);
		}
		else if (survivors_[0]->GetLightPow() <= 0)
		{
			DrawExtendGraph3D(survivors_[0]->GetTransform().lock()->pos.x,
				survivors_[0]->GetTransform().lock()->pos.y,
				survivors_[0]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryIdHdl_, true);
			DrawExtendGraph3D(survivors_[0]->GetTransform().lock()->pos.x,
				survivors_[0]->GetTransform().lock()->pos.y,
				survivors_[0]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryemptyIdHdl_, true);
		}

		if (survivors_[1]->GetLightPow() <= 70 && survivors_[1]->GetLightPow() > 0)
		{
			DrawExtendGraph3D(survivors_[1]->GetTransform().lock()->pos.x,
				survivors_[1]->GetTransform().lock()->pos.y,
				survivors_[1]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryIdHdl_, true);
			DrawExtendGraph3D(survivors_[1]->GetTransform().lock()->pos.x,
				survivors_[1]->GetTransform().lock()->pos.y,
				survivors_[1]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryredIdHdl_, true);
		}
		else if (survivors_[1]->GetLightPow() <= 0)
		{
			DrawExtendGraph3D(survivors_[1]->GetTransform().lock()->pos.x,
				survivors_[1]->GetTransform().lock()->pos.y,
				survivors_[1]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryIdHdl_, true);
			DrawExtendGraph3D(survivors_[1]->GetTransform().lock()->pos.x,
				survivors_[1]->GetTransform().lock()->pos.y,
				survivors_[1]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryemptyIdHdl_, true);
		}

		if (survivors_[2]->GetLightPow() <= 70 && survivors_[2]->GetLightPow() > 0)
		{
			DrawExtendGraph3D(survivors_[2]->GetTransform().lock()->pos.x,
				survivors_[2]->GetTransform().lock()->pos.y,
				survivors_[2]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryIdHdl_, true);
			DrawExtendGraph3D(survivors_[2]->GetTransform().lock()->pos.x,
				survivors_[2]->GetTransform().lock()->pos.y,
				survivors_[2]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryredIdHdl_, true);
		}
		else if (survivors_[2]->GetLightPow() <= 0)
		{
			DrawExtendGraph3D(survivors_[2]->GetTransform().lock()->pos.x,
				survivors_[2]->GetTransform().lock()->pos.y,
				survivors_[2]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryIdHdl_, true);
			DrawExtendGraph3D(survivors_[2]->GetTransform().lock()->pos.x,
				survivors_[2]->GetTransform().lock()->pos.y,
				survivors_[2]->GetTransform().lock()->pos.z, 1.0f, 1.0f, imgBatteryemptyIdHdl_, true);
		}

		raider_->Draw2D();
	}

}

void GameScene::DrawUI(bool isDrawRaiderview)
{
	if (inSceneType_ == InGameSceneType::START)
	{

		if (isDrawRaiderview)
		{
			DrawGraph(0, 0, imgAlreadyRaiHdl_, true);
		}
		else
		{
			DrawGraph(0, 0, imgAlreadySurHdl_, true);
		}

		if (isP1Already_)
		{
			DrawGraph(IMAGE_POS_PL1.x, IMAGE_POS_PL1.y, imgAlreadyOkHdl_, true);
		}
		if ((isP1Already_ && plNum_ == SceneManager::PLNUM::SOLO) || isP2Already_)
		{
			DrawGraph(IMAGE_POS_PL2.x, IMAGE_POS_PL2.y, imgAlreadyOkHdl_, true);
		}
		if ((isP1Already_ && plNum_ == SceneManager::PLNUM::SOLO) || isP3Already_)
		{
			DrawGraph(IMAGE_POS_PL3.x, IMAGE_POS_PL3.y, imgAlreadyOkHdl_, true);
		}
		if ((isP1Already_ && plNum_ == SceneManager::PLNUM::SOLO) || isP4Already_)
		{
			DrawGraph(IMAGE_POS_PL4.x, IMAGE_POS_PL4.y, imgAlreadyOkHdl_, true);
		}

		if ((isP1Already_ && plNum_ == SceneManager::PLNUM::SOLO) || isP1Already_ && isP2Already_ && isP3Already_ && isP4Already_)
		{
			DrawExtendGraph((Application::SCREEN_SIZE_X / 2) - (65 * 3), (Application::SCREEN_SIZE_Y / 2) - 300, (Application::SCREEN_SIZE_X / 2) + (65 * 3), (Application::SCREEN_SIZE_Y / 2)+300, imgsNumberTimeHdl_[wait2gameTimer_ / TIME_FPS], true);
			
		}

	}
	if (inSceneType_ == InGameSceneType::GAME)
	{
		if (isDrawRaiderview)
		{
			DrawGraph(0, 0, raiderOpeImgHdl_, true);
		}
		else
		{
			DrawGraph(0, 0, survivorOpeImgHdl_, true);
		}

		int hp = raider_->GetHp();
		int hpOne = hp % 10;
		int hpTen = (hp / 10) % 10;
		int hpHundred = (hp / 100) % 10;

		DrawExtendGraph(-200, 20, 290, 30 + 73, imgUiframeHdl_, true);


		DrawExtendGraph(0, 10, 98, 98, imgRaiderHdl_, true);
		DrawGraph(IMAGE_POS_HPNUM100.x, IMAGE_POS_HPNUM100.y, imgsNumberEnemyHdl_[hpHundred], true);
		DrawGraph(IMAGE_POS_HPNUM10.x, IMAGE_POS_HPNUM10.y, imgsNumberEnemyHdl_[hpTen], true);
		DrawGraph(IMAGE_POS_HPNUM1.x, IMAGE_POS_HPNUM1.y, imgsNumberEnemyHdl_[hpOne], true);

		int gameTimeInt = (int)GameTimer_;

		DrawExtendGraph((Application::SCREEN_SIZE_X / 2) - (75 * 2), 20, (Application::SCREEN_SIZE_X / 2) + (75 * 2), 30 + 73, imgUiframeHdl_, true);

		DrawGraph((Application::SCREEN_SIZE_X / 2) - (65 * 2), 35, imgsNumberTimeHdl_[gameTimeInt / TIME_FPS / TIME_FPS], true);
		DrawGraph((Application::SCREEN_SIZE_X / 2) - 65, 35, imgsNumberTimeHdl_[10], true);

		DrawGraph((Application::SCREEN_SIZE_X / 2), 35, imgsNumberTimeHdl_[gameTimeInt / TIME_FPS % TIME_FPS / 10], true);
		DrawGraph((Application::SCREEN_SIZE_X / 2) + 65, 35, imgsNumberTimeHdl_[gameTimeInt/ TIME_FPS % TIME_FPS % 10], true);
	}
	if (inSceneType_ == InGameSceneType::OVER)
	{
		switch (wintype_)
		{
		case GameScene::WinType::RAIDER:
			DrawGraph(0, 0, imgWinRaiHdl_,true);
			break;
		case GameScene::WinType::SURVIVOR:
			DrawGraph(0, 0, imgWinSurHdl_, true);
			break;
		case GameScene::WinType::DRAW:
			DrawGraph(0, 0, imgWinDraHdl_, true);
			break;
		default:
			break;
		}
	}
}

void GameScene::AddTotalTime(void)
{
	totalTime_ += 0.01f;
}

void GameScene::ElapseGameTimer(bool force)
{
	if (force)
	{
		stopGameTimer_ = true;
	}

	if (stopGameTimer_)
	{
		return;
	}

	GameTimer_ -= 2;
}

void GameScene::GameOver(WinType type)
{
	wintype_ = type;
	ChangeInGameType(InGameSceneType::OVER);
	StopSoundMem(sndBgmHdl_);

	switch (wintype_)
	{
	case GameScene::WinType::RAIDER:
		PlaySoundMem(sndWinRaiderHdl_, DX_PLAYTYPE_LOOP);
		break;
	case GameScene::WinType::SURVIVOR:
		PlaySoundMem(sndWinSurvivorHdl_, DX_PLAYTYPE_LOOP);
		break;
	case GameScene::WinType::DRAW:
		PlaySoundMem(sndWinDrawHdl_, DX_PLAYTYPE_LOOP);
		break;
	}

}
