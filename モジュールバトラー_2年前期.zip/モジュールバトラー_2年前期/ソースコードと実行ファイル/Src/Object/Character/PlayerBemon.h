#pragma once
#include "../PlayerBase.h"

class PlayerBemon : public PlayerBase
{
public:
	void SetParam(void) override;

protected:

private:
};
