#pragma once
#include "../PlayerBase.h"

class PlayerBirb : public PlayerBase
{
public:
	void SetParam(void) override;

protected:

private:
};

