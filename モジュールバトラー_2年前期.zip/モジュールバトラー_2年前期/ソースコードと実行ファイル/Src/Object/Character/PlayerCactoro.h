#pragma once
#include "../PlayerBase.h"

class PlayerCactoro : public PlayerBase
{
public:
	void SetParam(void) override;

protected:

private:
};
