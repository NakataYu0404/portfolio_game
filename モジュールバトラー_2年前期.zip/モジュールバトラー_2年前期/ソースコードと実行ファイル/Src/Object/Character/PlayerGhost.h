#pragma once
#include "../PlayerBase.h"

class PlayerGhost : public PlayerBase
{
public:
	void SetParam(void) override;

protected:

private:
};

