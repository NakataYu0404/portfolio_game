#pragma once
#include "../PlayerBase.h"

class PlayerYeti : public PlayerBase
{
public:
	void SetParam(void) override;

protected:

private:
};

